//============================================================================
// Name        : VeaRideRequestPlugin.cpp
// Author      : Battelle Memorial Institute - Ben Paselsky (paselsky@battelle.org)
// Version     :
// Copyright   : Copyright (c) 2014 Battelle Memorial Institute. All rights reserved.
// Description : Plugin that monitors DSRC traffic and the Azure database to see
//               if new rides have been requested and responds to requests
//============================================================================

#include <atomic>
#include <thread>
#include <queue>
#include <curl/curl.h>
#include <boost/regex.hpp>
#include <boost/lockfree/spsc_queue.hpp>

#include "PluginClient.h"
#include <LocationMessage.h>
#include <PmmRequestMessage.h>
#include <cpprest/http_client.h>
#include <tmx/j2735_messages/PersonalMobilityMessage.hpp>
#include <tmx/messages/message_document.hpp>
#include <asn_j2735_r41/DFullTime.h>
#include <asn_j2735_r41/DestinationType.h>
#include <asn_j2735_r41/MobilityNeedsList.h>
#include <asn_j2735_r41/MobilityNeeds.h>
#include <GeoVector.h>

using namespace std;
using namespace tmx;
using namespace tmx::utils;
using namespace tmx::messages;
using namespace tmx::messages::pmmrequestmessage;
using namespace std;
using namespace web;
using namespace utility;
using namespace http;
using namespace http::client;

namespace VeaRideRequestPlugin
{

#define THREADSLEEPTIMEMS 100
#define TRANSITDATASLEEPTIMEMS 5000
#define TRANSITSTOPPROXIMITYDISTANCEINMETERS 1


/*
 * Struct for holding DSRC PMM
 */

struct DSRCPMMDataStruct
{
	string groupId;
	RequestID_t requestId;
	PersonalMobilityMessageStatusType_t pmmStatus;
	double pickupLatitude;
	double pickupLongitude;
	struct DFullTime requestDate;
	struct DFullTime pickupDate;
	double destinationLatitude;
	double destinationLongitude;
	uint32_t regularSeats;
	uint32_t handicappedSeats;
	SeatCount_t seatCount;
	ModeOfTransportType_t modeOfTransport;
	EstimatedTimeType_t	eta;
	DSRCEquippedType_t	isDSRCEquipped;
};

/*
 * Struct for holding PMM messages and the time they were received, used for FIFO queue
 */
struct PmmMsgQueueStruct
{
	uint64_t pmmMsgTime;
	DSRCPMMDataStruct pmmMsg;
};

/*
 * Struct for holding accepted pickups
 * Check pmmMsgCloud to determine if we saved DSRC or Cloud PMM
 * If pmmMsgCloud is empty string then pmmMsgDSRC is valid otherwise pmmMsgCloud contains json from web request
 */
struct AcceptedPickupsStruct
{
	string groupId;
	RequestID_t requestId;
	PersonalMobilityMessageStatusType_t status;
	ModeOfTransportType_t modeOfTransport;
	DSRCPMMDataStruct pmmMsgDSRC;
	string pmmMsgCloud;
	uint32_t transitStopPickupId;
	uint32_t transitStopDropoffId;
};

/*
 * Struct for holding transit stop date for the configured route
 * Read in from database and modify counts as needed
 */
struct TransitStopStruct
{
	uint32_t id;
	string transitPickupStop;
	uint32_t transitStopBearing;
	double pickupLat;
	double pickupLong;
	double destLat;
	double destLong;
	string transitStopOrder;
	uint32_t totalRegularPickups;
	uint32_t totalRegularDropoffs;
	uint32_t totalHandicappedPickups;
	uint32_t totalHandicappedDropoffs;
};

//application mode
enum VEAMode
{
	VEATransit = 0,
	VEATaxi = 1
}VEAMode_t;

/**
 * This plugin monitors DSRC traffic and the Azure database to see
 * if new rides have been requested and responds to requests
 */
class VeaRideRequestPlugin: public PluginClient
{
public:
	VeaRideRequestPlugin(std::string);
	virtual ~VeaRideRequestPlugin();
	int Main();
protected:
	void UpdateConfigSettings();
	// Virtual method overrides.
	void OnConfigChanged(const char *key, const char *value);
	void OnStateChange(IvpPluginState state);
	uint64_t GetMsTimeSinceEpoch();
	void HandlePmmMessage(PmmMessage &msg, routeable_message &routeableMsg);
	void HandleLocationMessage(LocationMessage &msg, routeable_message &routeableMsg);
	void SendPmmMessage(string &groupId, RequestID_t requestId,
			PersonalMobilityMessageStatusType_t status, string vehicleDescription, DSRCPMMDataStruct requestMessage);
	void SendPmmMessage(string &groupId, RequestID_t requestId,
			PersonalMobilityMessageStatusType_t status, string vehicleDescription, string requestMessageCloud);
	SeatCount_t GetTotalSeatCount(PmmMessage &msg);
	SeatCount_t GetRegularSeatCount(PmmMessage &msg);
	SeatCount_t GetHandicappedSeatCount(PmmMessage &msg);
	uint32_t GetTransitStopId(double lat, double lon, double radiusInMeters);
	uint32_t GetTransitStopId(double lat, double lon, double radiusInMeters, uint32_t bearing);
	uint32_t GetRegularSeats(AcceptedPickupsStruct acceptedPickup);
	uint32_t GetHandicappedSeats(AcceptedPickupsStruct acceptedPickup);

	void CloudThread();
	void NextDestinationThreadTaxi();
	void ArrivedThreadTaxi();
	void NextDestinationThreadTransit();
	void ArrivedThreadTransit();

	static size_t HandleResponseOutput(void *buffer, size_t size, size_t nmemb, void *userp);

private:
	// locks
	//mutex _pmmLock;
	mutex _locationLock;
	mutex _apiUrlLock;
	mutex _vehicleDescriptionLock;
	mutex _modeLock;
	mutex _transitRouteLock;
	mutex _acceptedPickupsLock;
	mutex _setContentsLock;
	mutex _startThreadsLock;
	mutex _transitStopsLock;

	atomic<bool> _newConfigValues{false};
	atomic<bool> _startThreads{true};
	atomic<uint64_t> _cloudFrequency{3000};
	atomic<uint64_t> _nextDestinationFrequency{3000};
	atomic<uint64_t> _arrivedFrequency{3000};
	atomic<uint64_t> _arrivedRadius{10};
	atomic<uint64_t> _locationMsgExpireMs{5000};
	string _mobileDevicesApiUrl = "http://mobiledeviceswebapidev.azurewebsites.net";
	string _vehicleDescription = "Vehicle";
	atomic<bool> _cancelAllRequests{false};
	atomic<double> _stoppedThresholdSpeed{1.0};
	atomic<uint64_t> _mode{VEATransit};
	string _transitRoute = "Battelle Parking Lot";
	atomic<bool> _haveTransitStopList{false};
	std::atomic<uint64_t> _pmmMsgQueueSize{0};

	LocationMessage _locationMsg;
	uint64_t _locationMsgTime{0};
	//std::queue<PmmMsgQueueStruct> _pmmMsgQueue;
	boost::lockfree::spsc_queue<PmmMsgQueueStruct, boost::lockfree::capacity<1024> > _pmmMsgQueue;
	std::unordered_map<string, AcceptedPickupsStruct> _acceptedPickups;
	std::vector<string> _acceptedPickupsOrder;
	std::unordered_map<uint32_t, TransitStopStruct> _transitStops;
	std::unordered_map<uint32_t, uint32_t> _transitStopOrder;
	uint32_t _transitStopCount = 0;
	uint32_t _transitStopOrderCount = 0;
	uint32_t _lastVisitedTransitStop = 1;
	uint32_t _currentTransitStopId = 0;

	thread _cloudThread;
	thread _nextDestinationThread;
	thread _arrivedThread;
	atomic<bool> _stopThreads{false};

};

/**
 * Construct a new VeaRideRequestPlugin with the given name.
 *
 * @param name The name to give the plugin for identification purposes
 */
VeaRideRequestPlugin::VeaRideRequestPlugin(string name) : PluginClient(name)
{

	// Add a message filter and handler for each message this plugin wants to receive.
	AddMessageFilter<PmmMessage>(this, &VeaRideRequestPlugin::HandlePmmMessage);
	AddMessageFilter<LocationMessage>(this, &VeaRideRequestPlugin::HandleLocationMessage);

	// Subscribe to all messages specified by the filters above.
	SubscribeToMessages();

}

VeaRideRequestPlugin::~VeaRideRequestPlugin()
{
	//stop threads cleanly and wait for them to die
	_stopThreads = true;
	_cloudThread.join();
	_nextDestinationThread.join();
	_arrivedThread.join();
}

void VeaRideRequestPlugin::UpdateConfigSettings()
{
	string mobileDevicesApiUrl;
	string vehicleDescription;
	string mode;
	string transitRoute;
	GetConfigValue("CloudFrequency", _cloudFrequency);
	GetConfigValue("NextDestinationFrequency", _nextDestinationFrequency);
	GetConfigValue("ArrivedFrequency", _arrivedFrequency);
	GetConfigValue("ArrivedRadius", _arrivedRadius);
	GetConfigValue("LocationMsgExpiration", _locationMsgExpireMs);
	{
		lock_guard<mutex> lock(_apiUrlLock);
		GetConfigValue("MobileDevicesApiUrl", _mobileDevicesApiUrl);
		mobileDevicesApiUrl = _mobileDevicesApiUrl;
	}
	{
		lock_guard<mutex> lock(_vehicleDescriptionLock);
		GetConfigValue("VehicleDescription", _vehicleDescription);
		vehicleDescription = _vehicleDescription;
	}
	GetConfigValue("CancelAllRequests",_cancelAllRequests);
	GetConfigValue("StoppedThresholdSpeed",_stoppedThresholdSpeed);
	GetConfigValue("Mode", mode);
	if (mode == "Transit")
		_mode = VEATransit;
	else if (mode == "Taxi")
		_mode = VEATaxi;

	{
		lock_guard<mutex> lock(_transitRouteLock);
		GetConfigValue("TransitRoute", _transitRoute);
		transitRoute = _transitRoute;
	}

	PLOG(logDEBUG) << "    Config data - CloudFrequency: " << _cloudFrequency <<
			", NextDestinationFrequency: " << _nextDestinationFrequency << ", ArrivedFrequency: " <<
			_arrivedFrequency << ", ArrivedRadius: " << _arrivedRadius << ", LocationMsgExpiration: " << _locationMsgExpireMs <<
			", URL: " << mobileDevicesApiUrl << ", VehicleDescription: " << vehicleDescription << ", CancelAllRequests: " <<
			_cancelAllRequests << ", StoppedThresholdSpeed: " << _stoppedThresholdSpeed << ", Mode: " <<
			mode << ", TransitRoute: " << transitRoute;

	_newConfigValues = true;
}

void VeaRideRequestPlugin::OnConfigChanged(const char *key, const char *value)
{
	PluginClient::OnConfigChanged(key, value);
	UpdateConfigSettings();
}


void VeaRideRequestPlugin::OnStateChange(IvpPluginState state)
{
	PluginClient::OnStateChange(state);

	if (state == IvpPluginState_registered)
	{
		UpdateConfigSettings();

		//start proper threads
		{
			lock_guard<mutex> lock(_startThreadsLock);
			if (_startThreads)
			{
				//check mode
				if (_mode == VEATransit)
				{

					{
						lock_guard<mutex> lock(_transitRouteLock);
						PLOG(logDEBUG) << "Starting in Transit mode, transit route = " << _transitRoute;
					}
					// Start threads
					_cloudThread = thread(&VeaRideRequestPlugin::CloudThread, this);
					_nextDestinationThread = thread(&VeaRideRequestPlugin::NextDestinationThreadTransit, this);
					_arrivedThread = thread(&VeaRideRequestPlugin::ArrivedThreadTransit, this);
				}
				else
				{
					PLOG(logDEBUG) << "Starting in Taxi mode";
					// Start threads
					_cloudThread = thread(&VeaRideRequestPlugin::CloudThread, this);
					_nextDestinationThread = thread(&VeaRideRequestPlugin::NextDestinationThreadTaxi, this);
					_arrivedThread = thread(&VeaRideRequestPlugin::ArrivedThreadTaxi, this);
				}
				_startThreads = false;
			}
		}
	}
}

uint64_t VeaRideRequestPlugin::GetMsTimeSinceEpoch()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return (uint64_t) ((double) (tv.tv_sec) * 1000
			+ (double) (tv.tv_usec) / 1000);
}

int VeaRideRequestPlugin::Main()
{
	PLOG(logINFO) << "Starting plugin.";
	//bool havePmmData;
	DSRCPMMDataStruct pmmCopy;
	//uint64_t currentPmmMessageTime;
	ModeOfTransportType_t modeOfTransport;
	string groupId;
	RequestID_t requestId;
	PersonalMobilityMessageStatusType_t pmmStatus;
	bool processPMMRequest;
	bool sendResponse;
	uint32_t regularSeats;
	uint32_t handicappedSeats;
	uint32_t oldRegularSeats;
	uint32_t oldHandicappedSeats;
	SeatCount_t seatCount;
	bool pickupFound;
	bool isApiUrlValid;
	string mobileDevicesApiUrl;
	string transitRoute;
	http_response response;
	string body;
	utility::string_t address;
	status_code responseCode;
	size_t pos, nextPos;
	string responseArray;
	string transitRoutePath = "";
	http::uri uri;
	boost::smatch m;
	vector<string> orders;
	uint32_t order;
	uint32_t i;
	uint32_t transitStopPickupId;
	uint32_t transitStopDropoffId;
	PmmMsgQueueStruct pmmQeueItem;

	curl_global_init(CURL_GLOBAL_SSL);

	while (_plugin->state != IvpPluginState_error)
	{
		if (_newConfigValues)
		{
			if (_mode == VEATransit && !_haveTransitStopList)
			{
				//get transit stop list
				{
					//copy URL
					lock_guard<mutex> lock(_apiUrlLock);
					mobileDevicesApiUrl = _mobileDevicesApiUrl;
				}
				{
					//add transit route to URI
					lock_guard<mutex> lock(_transitRouteLock);
					transitRoute = _transitRoute;
				}
				std::replace(transitRoute.begin(), transitRoute.end(), ' ', '+');
				transitRoutePath = "/api/BusRoute?transitRoute=";
				transitRoutePath.append(transitRoute);
				isApiUrlValid = !mobileDevicesApiUrl.empty();
				if (isApiUrlValid)
				{
					body = "";
					responseCode = 0;
					try
					{
						address = U(mobileDevicesApiUrl);
						uri = http::uri(address);
						http_client rideRequester(http::uri_builder(uri).append_path(U(transitRoutePath)).to_uri());
						response = rideRequester.request(methods::GET).get();
						//PLOG(logDEBUG) << "HTTP Response: " << response.to_string();
						responseCode = response.status_code();
						body = response.extract_string().get();
						//PLOG(logDEBUG) << "HTTP Response - Code: " << responseCode << ", Body: " << body;
					}
					catch (exception &ex)
					{
						PLOG(logDEBUG) << "Exception getting transit stops: " << ex.what();
					}
					if (responseCode < 200 || responseCode >= 300)
					{
						PLOG(logDEBUG) << "HTTP Error, Response Code: " << responseCode;
					}
					//parse arrays out and process
					if (responseCode >= 200 && responseCode < 300 && body.length() > 2)
					{
						lock_guard<mutex> lock(_transitStopsLock);
						_transitStopCount = 0;
						_transitStopOrderCount = 0;
						_transitStops.clear();
						_transitStopOrder.clear();
						body = body.substr(1, body.length() - 2);
						pos = body.find("{\"Id\":", 0);
						while (pos != string::npos)
						{
							nextPos = body.find("{\"Id\":", pos + 1);
							if (nextPos == string::npos)
							{
								//last array
								responseArray = body.substr(pos, body.length() - pos);
							}
							else
							{
								//not last array
								responseArray = body.substr(pos, nextPos - pos - 1);
							}
							PLOG(logDEBUG) << "TransitStopResponseArray: " << responseArray;
							//parse json
							TransitStopStruct transitStop;
							if (boost::regex_search(responseArray, m, boost::regex("\"Id\":([^,}]+)(,|\\})")))
								transitStop.id = stoi(m[1]);
							else
								transitStop.id = 0;
							if (boost::regex_search(responseArray, m, boost::regex("\"TransitPickupStop\":\"([^\"]+)\"")))
								transitStop.transitPickupStop = m[1];
							else
								transitStop.transitPickupStop = "";
							if (boost::regex_search(responseArray, m, boost::regex("\"TransitStopBearing\":([^,}]+)(,|\\})")))
								transitStop.transitStopBearing = stoi(m[1]);
							else
								transitStop.transitStopBearing = 0;
							if (boost::regex_search(responseArray, m, boost::regex("\"PickupLat\":([^,}]+)(,|\\})")))
								transitStop.pickupLat = stod(m[1]);
							else
								transitStop.pickupLat = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"PickupLong\":([^,}]+)(,|\\})")))
								transitStop.pickupLong = stod(m[1]);
							else
								transitStop.pickupLong = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"DestLat\":([^,}]+)(,|\\})")))
								transitStop.destLat = stod(m[1]);
							else
								transitStop.destLat = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"DestLong\":([^,}]+)(,|\\})")))
								transitStop.destLong = stod(m[1]);
							else
								transitStop.destLong = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"TransitStopOrder\":\"([^\"]+)\"")))
								transitStop.transitStopOrder = m[1];
							else
								transitStop.transitStopOrder = "0";

							transitStop.totalRegularPickups = 0;
							transitStop.totalRegularDropoffs = 0;
							transitStop.totalHandicappedPickups = 0;
							transitStop.totalHandicappedDropoffs = 0;

							//add stop to stop map
							_transitStops[transitStop.id] = transitStop;
							_transitStopCount++;

							//add id to order map for each order number
							boost::split(orders, transitStop.transitStopOrder, boost::is_any_of(","));
							for (auto it = orders.begin();it != orders.end();++it)
							{
								if (boost::regex_match(*it, boost::regex("[0-9]+")))
								{
									order = stoi(*it);
									_transitStopOrder[order] = transitStop.id;
									_transitStopOrderCount++;
								}
							}

							pos = nextPos;
						}
						if (_transitStopOrderCount > 0)
						{
							_haveTransitStopList = true;
							//check that we have correct count and the order numbers are sequential starting at 1
							for (i=1;i<=_transitStopOrderCount;i++)
							{
								if (_transitStopOrder.find(i) == _transitStopOrder.end())
								{
									_haveTransitStopList = false;
									PLOG(logDEBUG) << "Error verifying transit stop order";
								}
							}
						}
					}
				}
				if (!_haveTransitStopList)
				{
					//sleep before trying to get stop list again
					this_thread::sleep_for(chrono::milliseconds(TRANSITDATASLEEPTIMEMS));
				}
			}
			//loop through all messages in queue
			while (_pmmMsgQueue.pop(pmmQeueItem) && (_mode == VEATaxi || (_mode == VEATransit && _haveTransitStopList)))
			{
//				//get PMM message off queue
//				{
//					lock_guard<mutex> lock(_pmmLock);
//					//PLOG(logDEBUG) << "Have PMM data, queue length: " << _pmmMsgQueue.size();
//					//currentPmmMessageTime = _pmmMsgQueue.front().pmmMsgTime;
//					pmmCopy = _pmmMsgQueue.front().pmmMsg;
//					_pmmMsgQueue.pop();
//				}

				_pmmMsgQueueSize--;
				pmmCopy = pmmQeueItem.pmmMsg;

				//get PMM fields

				modeOfTransport = pmmCopy.modeOfTransport;

				if ((_mode == VEATaxi && (modeOfTransport == ModeOfTransportType::ModeOfTransportType_taxi || modeOfTransport == ModeOfTransportType::ModeOfTransportType_rideShare)) ||
						(_mode == VEATransit && modeOfTransport == ModeOfTransportType::ModeOfTransportType_transit))
				{
					groupId = pmmCopy.groupId;
					requestId = pmmCopy.requestId;
					pmmStatus = pmmCopy.pmmStatus;
					regularSeats = pmmCopy.regularSeats;
					handicappedSeats = pmmCopy.handicappedSeats;
					seatCount = pmmCopy.seatCount;

					PLOG(logDEBUG) << "PMM data: groupId: " << groupId << ", requestId: " << requestId << ", pmmStatus: " << pmmStatus;
					PLOG(logDEBUG) << "          regularSeats: " << regularSeats << ", handicappedSeats: " << handicappedSeats << ", seatCount: " << seatCount;

					processPMMRequest = true;
					sendResponse = false;
					transitStopPickupId = 0;
					transitStopDropoffId = 0;
					if (_mode == VEATransit)
					{
						//get transit stops
						transitStopPickupId = GetTransitStopId(pmmCopy.pickupLatitude, pmmCopy.pickupLongitude, TRANSITSTOPPROXIMITYDISTANCEINMETERS);
						transitStopDropoffId = GetTransitStopId(pmmCopy.destinationLatitude, pmmCopy.destinationLongitude, TRANSITSTOPPROXIMITYDISTANCEINMETERS);
					}
					if (_mode == VEATaxi || (_mode == VEATransit && transitStopPickupId != 0))
					{
						// lock accepted pickups map in this block
						lock_guard<mutex> lock(_acceptedPickupsLock);

						//check is we have a saved request
						//if we do then process new request only if requestId > saved requestId
						pickupFound = false;
						if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
						{
							pickupFound = true;
							if (_acceptedPickups[groupId].requestId >= requestId)
							{
								//process request if new request id
								processPMMRequest = false;
							}
							if (_acceptedPickups[groupId].requestId == requestId)
							{
								//just send response if this request id already processed
								sendResponse = true;
							}
						}

						//process request into accepted pickups map, dont send response just yet
						if (processPMMRequest)
						{
							//process pmm
							if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_new)
							{
								sendResponse = true;
								if (seatCount > 0)
								{
									PLOG(logDEBUG) << "Add (DSRC), groupId: " << groupId << "  requestId: " << requestId;
									//new
									AcceptedPickupsStruct acceptedPickup;
									acceptedPickup.groupId = groupId;
									acceptedPickup.requestId = requestId;
									acceptedPickup.status = pmmStatus;
									acceptedPickup.pmmMsgDSRC = pmmCopy;
									acceptedPickup.pmmMsgCloud = "";
									//update total seat count for transit
									if (_mode == VEATransit)
									{
										lock_guard<mutex> lock(_transitStopsLock);
										acceptedPickup.transitStopPickupId = transitStopPickupId;
										if (transitStopPickupId != 0)
										{
											_transitStops[transitStopPickupId].totalRegularPickups += regularSeats;
											_transitStops[transitStopPickupId].totalHandicappedPickups += handicappedSeats;
										}
										acceptedPickup.transitStopDropoffId = transitStopDropoffId;
										if (transitStopDropoffId != 0)
										{
											_transitStops[transitStopDropoffId].totalRegularDropoffs += regularSeats;
											_transitStops[transitStopDropoffId].totalHandicappedDropoffs += handicappedSeats;
										}
									}
									_acceptedPickups[groupId] = acceptedPickup;
									if (!pickupFound &&_mode == VEATaxi)
									{
										//add groupId to end of order vector
										_acceptedPickupsOrder.push_back(groupId);
									}
								}
								else
								{
									//cancel because requested seat count = 0
									if (pickupFound)
									{
										PLOG(logDEBUG) << "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request cancelled";
										if (_mode == VEATransit)
										{
											lock_guard<mutex> lock(_transitStopsLock);
											oldRegularSeats = GetRegularSeats(_acceptedPickups[groupId]);
											oldHandicappedSeats = GetHandicappedSeats(_acceptedPickups[groupId]);
											if (transitStopPickupId != 0)
											{
												_transitStops[transitStopPickupId].totalRegularPickups -= oldRegularSeats;
												_transitStops[transitStopPickupId].totalHandicappedPickups -= oldHandicappedSeats;
											}
											if (transitStopDropoffId != 0)
											{
												_transitStops[transitStopDropoffId].totalRegularDropoffs -= oldRegularSeats;
												_transitStops[transitStopDropoffId].totalHandicappedDropoffs -= oldHandicappedSeats;
											}
										}
										_acceptedPickups.erase(groupId);
									}
									else
									{
										PLOG(logDEBUG)<< "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request not found!";
									}
								}
							}
							else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
							{
								sendResponse = true;
								if (seatCount > 0)
								{
									PLOG(logDEBUG) << "Update (DSRC), groupId: " << groupId << "  requestId: " << requestId;
									//update
									AcceptedPickupsStruct acceptedPickup;
									acceptedPickup.groupId = groupId;
									acceptedPickup.requestId = requestId;
									acceptedPickup.status = pmmStatus;
									acceptedPickup.pmmMsgDSRC = pmmCopy;
									acceptedPickup.pmmMsgCloud = "";
									//update total seat count for transit
									if (_mode == VEATransit)
									{
										lock_guard<mutex> lock(_transitStopsLock);
										oldRegularSeats = GetRegularSeats(_acceptedPickups[groupId]);
										oldHandicappedSeats = GetHandicappedSeats(_acceptedPickups[groupId]);
										acceptedPickup.transitStopPickupId = transitStopPickupId;
										if (transitStopPickupId != 0)
										{
											_transitStops[transitStopPickupId].totalRegularPickups -= oldRegularSeats;
											_transitStops[transitStopPickupId].totalHandicappedPickups -= oldHandicappedSeats;
											_transitStops[transitStopPickupId].totalRegularPickups += regularSeats;
											_transitStops[transitStopPickupId].totalHandicappedPickups += handicappedSeats;
										}
										acceptedPickup.transitStopDropoffId = transitStopDropoffId;
										if (transitStopDropoffId != 0)
										{
											_transitStops[transitStopDropoffId].totalRegularDropoffs -= oldRegularSeats;
											_transitStops[transitStopDropoffId].totalHandicappedDropoffs -= oldHandicappedSeats;
											_transitStops[transitStopDropoffId].totalRegularDropoffs += regularSeats;
											_transitStops[transitStopDropoffId].totalHandicappedDropoffs += handicappedSeats;
										}
									}
									_acceptedPickups[groupId] = acceptedPickup;
									if (!pickupFound &&_mode == VEATaxi)
									{
										//add groupId to end of order vector
										_acceptedPickupsOrder.push_back(groupId);
									}
								}
								else
								{
									//cancel because requested seat count = 0
									if (pickupFound)
									{
										PLOG(logDEBUG) << "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request cancelled";
										if (_mode == VEATransit)
										{
											lock_guard<mutex> lock(_transitStopsLock);
											oldRegularSeats = GetRegularSeats(_acceptedPickups[groupId]);
											oldHandicappedSeats = GetHandicappedSeats(_acceptedPickups[groupId]);
											if (transitStopPickupId != 0)
											{
												_transitStops[transitStopPickupId].totalRegularPickups -= oldRegularSeats;
												_transitStops[transitStopPickupId].totalHandicappedPickups -= oldHandicappedSeats;
											}
											if (transitStopDropoffId != 0)
											{
												_transitStops[transitStopDropoffId].totalRegularDropoffs -= oldRegularSeats;
												_transitStops[transitStopDropoffId].totalHandicappedDropoffs -= oldHandicappedSeats;
											}
										}
										_acceptedPickups.erase(groupId);
									}
									else
									{
										PLOG(logDEBUG)<< "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request not found!";
									}
								}
							}
							else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_cancel)
							{
								sendResponse = true;
								//cancel
								if (pickupFound)
								{
									PLOG(logDEBUG) << "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request cancelled";
									if (_mode == VEATransit)
									{
										lock_guard<mutex> lock(_transitStopsLock);
										oldRegularSeats = GetRegularSeats(_acceptedPickups[groupId]);
										oldHandicappedSeats = GetHandicappedSeats(_acceptedPickups[groupId]);
										if (transitStopPickupId != 0)
										{
											_transitStops[transitStopPickupId].totalRegularPickups -= oldRegularSeats;
											_transitStops[transitStopPickupId].totalHandicappedPickups -= oldHandicappedSeats;
										}
										if (transitStopDropoffId != 0)
										{
											_transitStops[transitStopDropoffId].totalRegularDropoffs -= oldRegularSeats;
											_transitStops[transitStopDropoffId].totalHandicappedDropoffs -= oldHandicappedSeats;
										}
									}
									_acceptedPickups.erase(groupId);
									_acceptedPickups.erase(groupId);
								}
								else
								{
									PLOG(logDEBUG) << "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request not found!";
								}
							}
							else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_completed)
							{
								//completed
								//PLOG(logDEBUG) << "Ignore (DSRC) 'Completed' message, groupId: " << groupId << "  requestId: " << requestId;
							}
							else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
							{
								//arrival
								//PLOG(logDEBUG) << "Ignore (DSRC) 'Arrival' message, groupId: " << groupId << "  requestId: " << requestId;
							}
							else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_response)
							{
								//response
								//PLOG(logDEBUG) << "Ignore (DSRC) 'Response' message, groupId: " << groupId << "  requestId: " << requestId;
							}
							else
							{
								//PLOG(logDEBUG) << "Ignore (DSRC) unknown status message, groupId: " << groupId << "  requestId: " << requestId << "  status: " << pmmStatus;
							}
						}
					}

					if (sendResponse)
					{
						//send response
						if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_new)
						{
							//new
							SendPmmMessage(groupId, requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_response,
									_vehicleDescription, pmmCopy);
							PLOG(logDEBUG) << "Send PMM (DSRC) response";
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
						{
							//update
							SendPmmMessage(groupId, requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_response,
									_vehicleDescription, pmmCopy);
							PLOG(logDEBUG) << "Send PMM (DSRC) response";
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_cancel)
						{
							//cancel
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_completed)
						{
							//completed
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
						{
							//arrival
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_response)
						{
							//response
						}
						else
						{
							//unknown status
						}
					}

//					{
//						//check PMM queue
//						lock_guard<mutex> lock(_pmmLock);
//						havePmmData = !_pmmMsgQueue.empty();
//					}
				}
			}
		}

		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}

	curl_global_cleanup();

	return (EXIT_SUCCESS);
}

uint32_t VeaRideRequestPlugin::GetTransitStopId(double lat, double lon, double radiusInMeters)
{
	WGS84Point p1;
	WGS84Point p2;
	double distance;

	p1.Latitude = lat;
	p1.Longitude = lon;
	{
		lock_guard<mutex> lock(_transitStopsLock);
		for (auto it = _transitStops.begin();it != _transitStops.end();++it)
		{
			p2.Latitude = it->second.pickupLat;
			p2.Longitude = it->second.pickupLong;
			distance = GeoVector::DistanceInMeters(p1, p2);
			if (distance < radiusInMeters)
				return it->second.id;
		}
	}
	return 0;
}

uint32_t VeaRideRequestPlugin::GetRegularSeats(AcceptedPickupsStruct acceptedPickup)
{
	boost::smatch m;
	uint32_t seats;
	if (acceptedPickup.pmmMsgCloud.empty())
	{
		//DSRC data
		return acceptedPickup.pmmMsgDSRC.regularSeats;
	}
	else
	{
		//Cloud data
		if (boost::regex_search(acceptedPickup.pmmMsgCloud, m, boost::regex("\"RegularSeats\":([^,}]+)(,|\\})")))
			seats = stoi(m[1]);
		else
			seats = 0;
		return seats;
	}
}

uint32_t VeaRideRequestPlugin::GetHandicappedSeats(AcceptedPickupsStruct acceptedPickup)
{
	boost::smatch m;
	uint32_t seats;
	if (acceptedPickup.pmmMsgCloud.empty())
	{
		//DSRC data
		return acceptedPickup.pmmMsgDSRC.handicappedSeats;
	}
	else
	{
		//Cloud data
		if (boost::regex_search(acceptedPickup.pmmMsgCloud, m, boost::regex("\"HandicappedSeats\":([^,}]+)(,|\\})")))
			seats = stoi(m[1]);
		else
			seats = 0;
		return seats;
	}
}

uint32_t VeaRideRequestPlugin::GetTransitStopId(double lat, double lon, double radiusInMeters, uint32_t bearing)
{
	WGS84Point p1;
	WGS84Point p2;
	double distance;
	uint32_t stopId = 0;
	uint32_t angle;
	uint32_t smallestAngle;

	p1.Latitude = lat;
	p1.Longitude = lon;

	{
		lock_guard<mutex> lock(_transitStopsLock);
		for (auto it = _transitStops.begin();it != _transitStops.end();++it)
		{
			p2.Latitude = it->second.pickupLat;
			p2.Longitude = it->second.pickupLong;
			distance = GeoVector::DistanceInMeters(p1, p2);
			if (distance < radiusInMeters)
			{
				//check for smallest bearing difference
				angle = abs(bearing - it->second.transitStopBearing);
				if (angle > 180)
					angle = 360 - angle;
				if (stopId == 0)
				{
					stopId = it->second.id;
					smallestAngle = angle;
				}
				else
				{
					if (angle < smallestAngle)
					{
						stopId = it->second.id;
						smallestAngle = angle;
					}
				}
			}
		}
	}
	return stopId;
}

void VeaRideRequestPlugin::HandlePmmMessage(PmmMessage &msg, routeable_message &routeableMsg)
{
	PmmMsgQueueStruct pmmQeueItem;
	PersonalMobilityMessage *pmm;
	DSRCPMMDataStruct pmmData;
	// Must be in the registered state in order to know the parameter values
	if (_plugin->state != IvpPluginState_registered)
		return;
	pmm = msg.get_j2735_data();

	if (pmm->position.lat == 0 && pmm->position.Long == 0)
		return;

	{
		//lock_guard<mutex> lock(_pmmLock);
		//Save the timestamp of this message.
		pmmQeueItem.pmmMsgTime = routeableMsg.get_timestamp();
		//extract and save all the data we need
		pmmData.groupId = string((const char*)pmm->groupId.buf, pmm->groupId.size);
		pmmData.requestId = pmm->requestId;
		pmmData.pmmStatus = pmm->status;
		pmmData.pickupLatitude = pmm->position.lat / 10000000.0;
		pmmData.pickupLongitude = pmm->position.Long / 10000000.0;
		if (pmm->requestDate != NULL)
			pmmData.requestDate = *(pmm->requestDate);
		else
			pmmData.requestDate.year = 0;
		if (pmm->pickupDate != NULL)
			pmmData.pickupDate = *(pmm->pickupDate);
		else
			pmmData.pickupDate.year = 0;
		if (pmm->destination != NULL)
		{
			pmmData.destinationLatitude = pmm->destination->lat / 10000000.0;
			pmmData.destinationLongitude = pmm->destination->lon / 10000000.0;
		}
		else
		{
			pmmData.destinationLatitude = 0.0;
			pmmData.destinationLongitude = 0.0;
		}
		pmmData.regularSeats = 0;
		pmmData.handicappedSeats = 0;
		pmmData.seatCount = 0;
		if (pmm->mobilityNeeds != NULL)
		{
			if (pmm->mobilityNeeds->list.count > 0)
			{
				for (int i = 0;i < pmm->mobilityNeeds->list.count;i++)
				{
					if (pmm->mobilityNeeds->list.array[i]->type == MobilityNeedsType_noSpecialNeeds)
						pmmData.regularSeats += pmm->mobilityNeeds->list.array[i]->count;
					if (pmm->mobilityNeeds->list.array[i]->type == MobilityNeedsType_wheelchair)
						pmmData.handicappedSeats += pmm->mobilityNeeds->list.array[i]->count;
					pmmData.seatCount += pmm->mobilityNeeds->list.array[i]->count;
				}
			}
		}

		if (pmm->modeOfTransport == NULL)
		{
			pmmData.modeOfTransport = ModeOfTransportType::ModeOfTransportType_transit;
			if (_mode == VEATaxi)
				pmmData.modeOfTransport = ModeOfTransportType::ModeOfTransportType_taxi;
			PLOG(logDEBUG) << "DSRC PMM ModeOfTransport is NULL, defaulting to " << pmmData.modeOfTransport;
		}
		else
			pmmData.modeOfTransport = *(pmm->modeOfTransport);

		if (pmm->eta != NULL)
			pmmData.eta = *(pmm->eta);
		else
			pmmData.eta = 0;

		if (pmm->isDSRCEquipped != NULL)
			pmmData.isDSRCEquipped = *(pmm->isDSRCEquipped);
		else
			pmmData.isDSRCEquipped = 0;

		pmmQeueItem.pmmMsg = pmmData;

		if (_pmmMsgQueue.push(pmmQeueItem))
			_pmmMsgQueueSize++;
		else
			PLOG(logDEBUG) << "HandlePmmMessage: _pmmMsgQueue push failed";

	}

	PLOG(logDEBUG) << "HandlePmmMessage receiving DSRC PmmMessage from TMX Core, received on: " << GetMsTimeSinceEpoch();
	//PLOG(logDEBUG) << "Got PMM";
}

void VeaRideRequestPlugin::HandleLocationMessage(LocationMessage &msg, routeable_message &routeableMsg)
{
	// Must be in the registered state in order to know the parameter values
	if (_plugin->state != IvpPluginState_registered)
		return;

	if (msg.get_Latitude() == 0 && msg.get_Longitude() == 0)
		return;

	//Save to member variable for later use.
	{
		lock_guard<mutex> lock(_locationLock);
		_locationMsgTime = routeableMsg.get_timestamp();
		_locationMsg = msg;
	}
}

/*
 * This method is used to send the PMM response to the passed in request. The response
 * body is filled in with information from the DSRC request (most of which is not needed) which
 * insures that the message successfully builds from the XML.
 */
void VeaRideRequestPlugin::SendPmmMessage(string &groupId, RequestID_t requestId,
		PersonalMobilityMessageStatusType_t status, string vehicleDescription, DSRCPMMDataStruct requestMessage)
{
	stringstream ss;
	string currentWeather;
	PmmMessage pmmMsg;
	message_container_type xmlDoc;
	PmmEncodedMessage encMsg;
	string accuracy;
	string vehicleDesc;

	PLOG(logDEBUG) << "Send PMM (for DSRC request), Status: " << status;


	ss.clear();
	ss.str(string());
	ss << "<PersonalMobilityMessage>";
	ss << "<groupId>" << groupId << "</groupId>";
	ss << "<requestId>" << requestId << "</requestId>";
	ss << "<status>" << status << "</status>";
	ss << "<position>" <<
			"<lat>" << (long)(requestMessage.pickupLatitude * 10000000) << "</lat>" <<
			"<long>" << (long)(requestMessage.pickupLongitude * 10000000) << "</long>" <<
			"</position>";

/*  adding accuracy throws an exception

	if (requestMessage.get_j2735_data()->accuracy != NULL)
	{
		accuracy = string((const char*)requestMessage.get_j2735_data()->accuracy->buf,
				requestMessage.get_j2735_data()->accuracy->size);
		ss << "<accuracy>" << accuracy << "</accuracy>";
	}
	else
	{
		ss << "<accuracy></accuracy>";
	}
*/

	if (requestMessage.requestDate.year != 0)
	{
		ss << "<requestDate>" <<
				"<year>" << requestMessage.requestDate.year << "</year>" <<
				"<month>" << requestMessage.requestDate.month << "</month>" <<
				"<day>" << requestMessage.requestDate.day << "</day>" <<
				"<hour>" << requestMessage.requestDate.hour << "</hour>" <<
				"<minute>" << requestMessage.requestDate.minute << "</minute>" <<
				"</requestDate>";
	}
	else
	{
		ss << "<requestDate></requestDate>";
	}

	if (requestMessage.pickupDate.year != 0)
	{
		ss << "<pickupDate>" <<
				"<year>" << requestMessage.pickupDate.year << "</year>" <<
				"<month>" << requestMessage.pickupDate.month << "</month>" <<
				"<day>" << requestMessage.pickupDate.day << "</day>" <<
				"<hour>" << requestMessage.pickupDate.hour << "</hour>" <<
				"<minute>" << requestMessage.pickupDate.minute << "</minute>" <<
				"</pickupDate>";
	}
	else
	{
		ss << "<pickupDate></pickupDate>";
	}

	if (requestMessage.destinationLatitude != 0.0 && requestMessage.destinationLongitude != 0.0)
	{
		ss << "<destination>" <<
				"<lon>" << (long)(requestMessage.destinationLongitude * 10000000) << "</lon>" <<
				"<lat>" << (long)(requestMessage.destinationLatitude * 10000000) << "</lat>" <<
				"</destination>";
	}
	else
	{
		ss << "<destination></destination>";
	}

	ss << "<mobilityNeeds>";
	ss << "<MobilityNeeds>" <<
			"<type>" << MobilityNeedsType_noSpecialNeeds << "</type>" <<
			"<count>" << requestMessage.regularSeats << "</count>" <<
			"</MobilityNeeds>";
	ss << "<MobilityNeeds>" <<
			"<type>" << MobilityNeedsType_wheelchair << "</type>" <<
			"<count>" << requestMessage.handicappedSeats << "</count>" <<
			"</MobilityNeeds>";

	ss << "</mobilityNeeds>";

	ss << "<modeOfTransport>" << requestMessage.modeOfTransport << "</modeOfTransport>";

	ss << "<eta>" << requestMessage.eta << "</eta>";

	if (requestMessage.isDSRCEquipped == 0)
	{
		ss << "<isDSRCEquipped><false/></isDSRCEquipped>";
	}
	else
	{
		ss << "<isDSRCEquipped><true/></isDSRCEquipped>";
	}
/*
 	if (requestMessage.get_j2735_data()->vehicleDesc != NULL)
	{
		vehicleDesc = string((const char*)requestMessage.get_j2735_data()->vehicleDesc->buf,
				requestMessage.get_j2735_data()->vehicleDesc->size);
		ss << "<vehicleDesc>" << vehicleDesc << "</vehicleDesc>";
	}
	else
	{
		ss << "<vehicleDesc></vehicleDesc>";
	}
*/

	//use this vehicles description
	//dont allow empty string (causes exception)
	if (vehicleDescription.length() == 0)
	{
		ss << "<vehicleDesc>Vehicle</vehicleDesc>";
	}
	else
	{
		ss << "<vehicleDesc>" << vehicleDescription << "</vehicleDesc>";
	}

	ss << "<regional></regional>";

	ss << "</PersonalMobilityMessage>";

	PLOG(logDEBUG) << "PMM XML: " << ss.str();

	try
	{
		xmlDoc.load<XML>(ss);
		{
			lock_guard<mutex> lock(_setContentsLock);
			pmmMsg.set_contents(xmlDoc);
			encMsg.initialize(pmmMsg);
		}
		encMsg.set_flags(IvpMsgFlags_RouteDSRC);
		encMsg.addDsrcMetadata(172, 0x8031);
		BroadcastMessage(static_cast<routeable_message &>(encMsg));
		PLOG(logDEBUG) << "SendPmmMessage sending DSRC Pmm Message to TMX Core (for DSRC request), sent on: " << GetMsTimeSinceEpoch() << " - PMM fields: " << pmmMsg.to_string();
	}
	catch (exception &ex)
	{
		PLOG(logERROR) << "Exception thrown in VeaRideRequestPlugin::SendPmmMessage: " << ex.what();
	}
}

/*
 * This method is used to send the PMM response to the passed in request. The response
 * body is filled in with information from the Cloud request (most of which is not needed) which
 * insures that the message successfully builds from the XML.
 */
void VeaRideRequestPlugin::SendPmmMessage(string &groupId, RequestID_t requestId,
		PersonalMobilityMessageStatusType_t status, string vehicleDescription, string requestMessage)
{
	stringstream ss;
	string currentWeather;
	PmmMessage pmmMsg;
	message_container_type xmlDoc;
	PmmEncodedMessage encMsg;
	string accuracy;
	string vehicleDesc;
	//tmx::message bodyTMX;
	boost::regex r("^(2[0-9][0-9][0-9])-([0-1][0-9])-([0-3][0-9])T([0-2][0-9]):([0-5][0-9])");
	boost::smatch m;
	double latitude;
	double longitude;
	string requestDate;
	string pickupDate;
	int seats;
	int modeOfTransport;

	PLOG(logDEBUG) << "Send PMM (for Cloud request), Status: " << status;

	//parse json
	//bodyTMX.clear();
	//{
	//	lock_guard<mutex> lock(_setContentsLock);
	//	bodyTMX.set_contents(requestMessage);
	//}

	if (boost::regex_search(requestMessage, m, boost::regex("\"PickupLatitude\":([^,}]+)(,|\\})")))
		latitude = stod(m[1]);
	else
		latitude = 0.0;
	if (boost::regex_search(requestMessage, m, boost::regex("\"PickupLongitude\":([^,}]+)(,|\\})")))
		longitude = stod(m[1]);
	else
		longitude = 0.0;

	ss.clear();
	ss.str(string());
	ss << "<PersonalMobilityMessage>";
	ss << "<groupId>" << groupId << "</groupId>";
	ss << "<requestId>" << requestId << "</requestId>";
	ss << "<status>" << status << "</status>";
	ss << "<position>" <<
			"<lat>" << (long)(latitude * 10000000.0) << "</lat>" <<
			"<long>" << (long)(longitude * 10000000.0) << "</long>" <<
			"</position>";

/*  adding accuracy throws an exception

	if (requestMessage.get_j2735_data()->accuracy != NULL)
	{
		accuracy = string((const char*)requestMessage.get_j2735_data()->accuracy->buf,
				requestMessage.get_j2735_data()->accuracy->size);
		ss << "<accuracy>" << accuracy << "</accuracy>";
	}
	else
	{
		ss << "<accuracy></accuracy>";
	}
*/

	if (boost::regex_search(requestMessage, m, boost::regex("\"RequestDate\":\"([^\"]+)\"")))
		requestDate = m[1];
	else
		requestDate = "";
	if (boost::regex_search(requestDate, m, r))
	{
		ss << "<requestDate>" <<
				"<year>" << m[1] << "</year>" <<
				"<month>" << m[2] << "</month>" <<
				"<day>" << m[3] << "</day>" <<
				"<hour>" << m[4] << "</hour>" <<
				"<minute>" << m[5] << "</minute>" <<
				"</requestDate>";
	}
	else
	{
		ss << "<requestDate></requestDate>";
	}

	if (boost::regex_search(requestMessage, m, boost::regex("\"PickupDate\":\"([^\"]+)\"")))
		pickupDate = m[1];
	else
		pickupDate = "";
	if (boost::regex_search(pickupDate, m, r))
	{
		ss << "<pickupDate>" <<
				"<year>" << m[1] << "</year>" <<
				"<month>" << m[2] << "</month>" <<
				"<day>" << m[3] << "</day>" <<
				"<hour>" << m[4] << "</hour>" <<
				"<minute>" << m[5] << "</minute>" <<
				"</pickupDate>";
	}
	else
	{
		ss << "<pickupDate></pickupDate>";
	}

	if (boost::regex_search(requestMessage, m, boost::regex("\"DestLatitude\":([^,}]+)(,|\\})")))
		latitude = stod(m[1]);
	else
		latitude = 0.0;
	if (boost::regex_search(requestMessage, m, boost::regex("\"DestLongitude\":([^,}]+)(,|\\})")))
		longitude = stod(m[1]);
	else
		longitude = 0.0;

	ss << "<destination>" <<
			"<lon>" << (long)(longitude * 10000000.0) << "</lon>" <<
			"<lat>" << (long)(latitude * 10000000.0) << "</lat>" <<
			"</destination>";

	ss << "<mobilityNeeds>";

	if (boost::regex_search(requestMessage, m, boost::regex("\"RegularSeats\":([^,}]+)(,|\\})")))
		seats = stoi(m[1]);
	else
		seats = 0;
	if (seats > 0)
	{
		ss << "<MobilityNeeds>" <<
				"<type>" << MobilityNeedsType::MobilityNeedsType_noSpecialNeeds << "</type>" <<
				"<count>" << seats << "</count>" <<
				"</MobilityNeeds>";
	}
	if (boost::regex_search(requestMessage, m, boost::regex("\"HadicappedSeats\":([^,}]+)(,|\\})")))
		seats = stoi(m[1]);
	else
		seats = 0;
	if (seats > 0)
	{
		ss << "<MobilityNeeds>" <<
				"<type>" << MobilityNeedsType::MobilityNeedsType_wheelchair << "</type>" <<
				"<count>" << seats << "</count>" <<
				"</MobilityNeeds>";
	}
	ss << "</mobilityNeeds>";

	if (boost::regex_search(requestMessage, m, boost::regex("\"ModeOfTransport\":([^,}]+)(,|\\})")))
		modeOfTransport = stoi(m[1]);
	else
		modeOfTransport = transit;
	ss << "<modeOfTransport>" << modeOfTransport << "</modeOfTransport>";

	// no eta field to copy, pass it in?
	//default to 0
	ss << "<eta>0</eta>";

	// no isDSRC field to copy
	//default to false
	ss << "<isDSRCEquipped><false/></isDSRCEquipped>";

	//use this vehicles description
	//dont allow empty string (causes exception)
	if (vehicleDescription.length() == 0)
	{
		ss << "<vehicleDesc>Vehicle</vehicleDesc>";
	}
	else
	{
		ss << "<vehicleDesc>" << vehicleDescription << "</vehicleDesc>";
	}

	ss << "<regional></regional>";

	ss << "</PersonalMobilityMessage>";

	PLOG(logDEBUG) << "PMM XML: " << ss.str();

	try
	{
		{
			lock_guard<mutex> lock(_setContentsLock);
			xmlDoc.load<XML>(ss);
			pmmMsg.set_contents(xmlDoc);
		}
		encMsg.initialize(pmmMsg);
		BroadcastMessage(static_cast<routeable_message &>(encMsg));
		PLOG(logDEBUG) << "SendPmmMessage sending DSRC Pmm Message to TMX Core (for Cloud request), sent on: " << GetMsTimeSinceEpoch() << " - PMM fields: " << pmmMsg.to_string();
	}
	catch (exception &ex)
	{
		PLOG(logERROR) << "Exception thrown in VeaRideRequestPlugin::SendPmmMessage: " << ex.what();
	}
}

void VeaRideRequestPlugin::CloudThread()
{
	bool isApiUrlValid;
	uint64_t lastSendTime = 0;
	bool MessageNotShown = true;
	utility::string_t address;
	http::uri uri;
	uint64_t time;
	http_response response;
	string body;
	status_code responseCode;
	size_t pos, nextPos;
	string responseArray;
	ostringstream oss;
	CURL *curlHandle;
	CURLcode curlRC = CURLE_OK;
	string curlResponse;
	string curlURL = "";
	string postData;
	struct curl_slist *headerList = NULL;
	string bodyLength;
	bool processPMMRequest;
	string mobileDevicesApiUrl;
	bool pickupFound;
	ModeOfTransportTypes modeOfTransport;
	uint32_t transitStopPickupId;
	uint32_t transitStopDropoffId;
	string groupIdent;
	uint32_t requestId;
	uint32_t status;
	uint32_t isDSRCEquipped = 1;
	uint32_t eta = 30;
	uint32_t regularSeats;
	uint32_t handicappedSeats;
	uint32_t oldRegularSeats;
	uint32_t oldHandicappedSeats;
	uint32_t seatCount;
	double pickupLatitude = 0.0;
	double pickupLongitude = 0.0;
	double destLatitude = 0.0;
	double destLongitude = 0.0;
	double elevation = 0.0;
	double posAccuracy = 1.0;
	boost::smatch m;
	bool sendResponse;

	while (_plugin->state != IvpPluginState_error && !_stopThreads)
	{
		time = GetMsTimeSinceEpoch();
		if (_newConfigValues && _cloudFrequency > 0 && (time - lastSendTime) > _cloudFrequency &&
				(_mode == VEATaxi || (_mode == VEATransit && _haveTransitStopList)))
		{
			//get cloud requests
			{
				//copy URL
				lock_guard<mutex> lock(_apiUrlLock);
				mobileDevicesApiUrl = _mobileDevicesApiUrl;
			}
			isApiUrlValid = !mobileDevicesApiUrl.empty();
			if (isApiUrlValid)
			{
				MessageNotShown = true;
				body = "";
				responseCode = 0;
				try
				{
					address = U(mobileDevicesApiUrl);
					uri = http::uri(address);
					http_client rideRequester(http::uri_builder(uri).append_path(U("/api/PmmRequest")).to_uri());
					lastSendTime = time;
					response = rideRequester.request(methods::GET).get();
					//PLOG(logDEBUG) << "HTTP Response: " << response.to_string();
					responseCode = response.status_code();
					body = response.extract_string().get();
					//PLOG(logDEBUG) << "HTTP Response - Code: " << responseCode << ", Body: " << body;
				}
				catch (exception &ex)
				{
					PLOG(logDEBUG) << "Exception getting cloud requests: " << ex.what();
				}
				if (responseCode < 200 || responseCode >= 300)
				{
					PLOG(logDEBUG) << "HTTP Error, Response Code: " << responseCode;
				}
				//parse arrays out and process
				if (responseCode >= 200 && responseCode < 300 && body.length() > 2)
				{
					body = body.substr(1, body.length() - 2);
					pos = body.find("{\"Id\":", 0);
					while (pos != string::npos)
					{
						nextPos = body.find("{\"Id\":", pos + 1);
						if (nextPos == string::npos)
						{
							//last array
							responseArray = body.substr(pos, body.length() - pos);
						}
						else
						{
							//not last array
							responseArray = body.substr(pos, nextPos - pos - 1);
						}
						//parse json
						//tmx::message bodyTMX;
						//bodyTMX.clear();
						//{
						//	lock_guard<mutex> lock(_setContentsLock);
						//	bodyTMX.set_contents(responseArray);
						//}

						modeOfTransport = noPreference;
						if (boost::regex_search(responseArray, m, boost::regex("\"ModeofTransport\":([^,}]+)(,|\\})")))
						{
							if (stoi(m[1]) == rideShare)
								modeOfTransport = rideShare;
							else if (stoi(m[1]) == taxi)
								modeOfTransport = taxi;
							else if (stoi(m[1]) == transit)
								modeOfTransport = transit;
						}
						if ((_mode == VEATaxi && (modeOfTransport == taxi || modeOfTransport == rideShare)) ||
												(_mode == VEATransit && modeOfTransport == transit))
						{
							PLOG(logDEBUG) << "CloudThread receiving PmmRequest from the Cloud API, received on: " << GetMsTimeSinceEpoch(); // << " - PMM fields: " << bodyTMX.to_string();
							PLOG(logDEBUG) << "responseArray: " << responseArray;
							sendResponse = false;
							//groupIdent = bodyTMX.get<string>("GroupIdent", "");
							if (boost::regex_search(responseArray, m, boost::regex("\"GroupIdent\":\"([^\"]+)\"")))
								groupIdent = m[1];
							else
								groupIdent = "";
							//PLOG(logDEBUG) << "GroupIdent: " << groupIdent;


							//requestId = bodyTMX.get<uint32_t>("RequestId", 0);
							if (boost::regex_search(responseArray, m, boost::regex("\"RequestId\":([^,}]+)(,|\\})")))
								requestId = stoi(m[1]);
							else
								requestId = 0;
							//status = bodyTMX.get<uint32_t>("Status", 0);
							if (boost::regex_search(responseArray, m, boost::regex("\"Status\":([^,}]+)(,|\\})")))
								status = stoi(m[1]);
							else
								status = 0;
							//regularSeats = bodyTMX.get<uint32_t>("RegularSeats", 0);
							if (boost::regex_search(responseArray, m, boost::regex("\"RegularSeats\":([^,}]+)(,|\\})")))
								regularSeats = stoi(m[1]);
							else
								regularSeats = 0;
							//handicappedSeats = bodyTMX.get<uint32_t>("HandicappedSeats", 0);
							if (boost::regex_search(responseArray, m, boost::regex("\"HandicappedSeats\":([^,}]+)(,|\\})")))
								handicappedSeats = stoi(m[1]);
							else
								handicappedSeats = 0;
							seatCount = regularSeats + handicappedSeats;
							if (boost::regex_search(responseArray, m, boost::regex("\"PickupLatitude\":([^,}]+)(,|\\})")))
								pickupLatitude = stod(m[1]);
							else
								pickupLatitude = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"PickupLongitude\":([^,}]+)(,|\\})")))
								pickupLongitude = stod(m[1]);
							else
								pickupLongitude = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"DestLatitude\":([^,}]+)(,|\\})")))
								destLatitude = stod(m[1]);
							else
								destLatitude = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"DestLongitude\":([^,}]+)(,|\\})")))
								destLongitude = stod(m[1]);
							else
								destLongitude = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"Elevation\":([^,}]+)(,|\\})")))
								elevation = stod(m[1]);
							else
								elevation = 0.0;
							if (boost::regex_search(responseArray, m, boost::regex("\"PosAccuracy\":([^,}]+)(,|\\})")))
								posAccuracy = stod(m[1]);
							else
								posAccuracy = 0.0;

							processPMMRequest = true;

							transitStopPickupId = 0;
							transitStopDropoffId = 0;
							if (_mode == VEATransit)
							{
								//get transit stops
								transitStopPickupId = GetTransitStopId(pickupLatitude, pickupLongitude, TRANSITSTOPPROXIMITYDISTANCEINMETERS);
								transitStopDropoffId = GetTransitStopId(destLatitude, destLongitude, TRANSITSTOPPROXIMITYDISTANCEINMETERS);
							}
							sendResponse = false;
							if (_mode == VEATaxi || (_mode == VEATransit && transitStopPickupId != 0))
							{
								sendResponse = true;
								// lock accepted pickups map in this block
								lock_guard<mutex> lock(_acceptedPickupsLock);

								//check is we have a saved request
								//if we do then process new request only if requestId > saved requestId
								pickupFound = false;
								if (_acceptedPickups.find(groupIdent) != _acceptedPickups.end())
								{
									pickupFound = true;
									if (_acceptedPickups[groupIdent].requestId >= requestId)
									{
										processPMMRequest = false;
									}
								}

								//process request into accepted pickups map, dont send response just yet
								if (processPMMRequest)
								{
									//process pmm
									if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_new)
									{
										if (seatCount > 0)
										{
											PLOG(logDEBUG) << "Add (Cloud), groupId: " << groupIdent << "  requestId: " << requestId;
											//new
											AcceptedPickupsStruct acceptedPickup;
											acceptedPickup.groupId = groupIdent;
											acceptedPickup.requestId = requestId;
											acceptedPickup.status = status;
											acceptedPickup.pmmMsgCloud = responseArray;
											//update total seat count for transit
											if (_mode == VEATransit)
											{
												lock_guard<mutex> lock(_transitStopsLock);
												acceptedPickup.transitStopPickupId = transitStopPickupId;
												if (transitStopPickupId != 0)
												{
													_transitStops[transitStopPickupId].totalRegularPickups += regularSeats;
													_transitStops[transitStopPickupId].totalHandicappedPickups += handicappedSeats;
												}
												acceptedPickup.transitStopDropoffId = transitStopDropoffId;
												if (transitStopDropoffId != 0)
												{
													_transitStops[transitStopDropoffId].totalRegularDropoffs += regularSeats;
													_transitStops[transitStopDropoffId].totalHandicappedDropoffs += handicappedSeats;
												}
											}
											_acceptedPickups[groupIdent] = acceptedPickup;
											if (!pickupFound &&_mode == VEATaxi)
											{
												//add groupId to end of order vector
												_acceptedPickupsOrder.push_back(groupIdent);
											}
										}
										else
										{
											//cancel because requested seat count = 0
											if (pickupFound)
											{
												PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request cancelled";
												if (_mode == VEATransit)
												{
													lock_guard<mutex> lock(_transitStopsLock);
													oldRegularSeats = GetRegularSeats(_acceptedPickups[groupIdent]);
													oldHandicappedSeats = GetHandicappedSeats(_acceptedPickups[groupIdent]);
													if (transitStopPickupId != 0)
													{
														_transitStops[transitStopPickupId].totalRegularPickups -= oldRegularSeats;
														_transitStops[transitStopPickupId].totalHandicappedPickups -= oldHandicappedSeats;
													}
													if (transitStopDropoffId != 0)
													{
														_transitStops[transitStopDropoffId].totalRegularDropoffs -= oldRegularSeats;
														_transitStops[transitStopDropoffId].totalHandicappedDropoffs -= oldHandicappedSeats;
													}
												}
												_acceptedPickups.erase(groupIdent);
											}
											else
											{
												PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request not found!";
											}
										}
									}
									else if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
									{
										if (seatCount > 0)
										{
											PLOG(logDEBUG) << "Update (Cloud), groupId: " << groupIdent << "  requestId: " << requestId;
											//update
											AcceptedPickupsStruct acceptedPickup;
											acceptedPickup.groupId = groupIdent;
											acceptedPickup.requestId = requestId;
											acceptedPickup.status = status;
											acceptedPickup.pmmMsgCloud = responseArray;
											//update total seat count for transit
											if (_mode == VEATransit)
											{
												lock_guard<mutex> lock(_transitStopsLock);
												oldRegularSeats = GetRegularSeats(_acceptedPickups[groupIdent]);
												oldHandicappedSeats = GetHandicappedSeats(_acceptedPickups[groupIdent]);
												acceptedPickup.transitStopPickupId = transitStopPickupId;
												if (transitStopPickupId != 0)
												{
													_transitStops[transitStopPickupId].totalRegularPickups -= oldRegularSeats;
													_transitStops[transitStopPickupId].totalHandicappedPickups -= oldHandicappedSeats;
													_transitStops[transitStopPickupId].totalRegularPickups += regularSeats;
													_transitStops[transitStopPickupId].totalHandicappedPickups += handicappedSeats;
												}
												acceptedPickup.transitStopDropoffId = transitStopDropoffId;
												if (transitStopDropoffId != 0)
												{
													_transitStops[transitStopDropoffId].totalRegularDropoffs -= oldRegularSeats;
													_transitStops[transitStopDropoffId].totalHandicappedDropoffs -= oldHandicappedSeats;
													_transitStops[transitStopDropoffId].totalRegularDropoffs += regularSeats;
													_transitStops[transitStopDropoffId].totalHandicappedDropoffs += handicappedSeats;
												}
											}
											_acceptedPickups[groupIdent] = acceptedPickup;
											if (!pickupFound &&_mode == VEATaxi)
											{
												//add groupId to end of order vector
												_acceptedPickupsOrder.push_back(groupIdent);
											}
										}
										else
										{
											//cancel because requested seat count = 0
											if (pickupFound)
											{
												PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request cancelled";
												if (_mode == VEATransit)
												{
													lock_guard<mutex> lock(_transitStopsLock);
													oldRegularSeats = GetRegularSeats(_acceptedPickups[groupIdent]);
													oldHandicappedSeats = GetHandicappedSeats(_acceptedPickups[groupIdent]);
													if (transitStopPickupId != 0)
													{
														_transitStops[transitStopPickupId].totalRegularPickups -= oldRegularSeats;
														_transitStops[transitStopPickupId].totalHandicappedPickups -= oldHandicappedSeats;
													}
													if (transitStopDropoffId != 0)
													{
														_transitStops[transitStopDropoffId].totalRegularDropoffs -= oldRegularSeats;
														_transitStops[transitStopDropoffId].totalHandicappedDropoffs -= oldHandicappedSeats;
													}
												}
												_acceptedPickups.erase(groupIdent);
											}
											else
											{
												PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request not found!";
											}
										}
									}
									else if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_cancel)
									{
										//cancel
										if (pickupFound)
										{
											PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request cancelled";
											if (_mode == VEATransit)
											{
												lock_guard<mutex> lock(_transitStopsLock);
												oldRegularSeats = GetRegularSeats(_acceptedPickups[groupIdent]);
												oldHandicappedSeats = GetHandicappedSeats(_acceptedPickups[groupIdent]);
												if (transitStopPickupId != 0)
												{
													_transitStops[transitStopPickupId].totalRegularPickups -= oldRegularSeats;
													_transitStops[transitStopPickupId].totalHandicappedPickups -= oldHandicappedSeats;
												}
												if (transitStopDropoffId != 0)
												{
													_transitStops[transitStopDropoffId].totalRegularDropoffs -= oldRegularSeats;
													_transitStops[transitStopDropoffId].totalHandicappedDropoffs -= oldHandicappedSeats;
												}
											}
											_acceptedPickups.erase(groupIdent);
										}
										else
										{
											PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request not found!";
										}
									}
									else if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_completed)
									{
										//completed
									}
									else if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
									{
										//arrival
									}
								}
							}

							if (sendResponse)
							{
								//build response
								oss.clear();
								oss.str(string());
								oss << "{\"GroupId\":\"" << groupIdent << "\",";
								oss << "\"RequestId\":" << requestId << ",";
								//oss << "\"Latitude\":" << setprecision(8) << bodyTMX.get<double>("Latitude", 0.0) << ",";
								//oss << "\"Longitude\":" << setprecision(8) << bodyTMX.get<double>("Longitude", 0.0) << ",";
								//oss << "\"Elevation\":" << setprecision(8) << bodyTMX.get<double>("Elevation", 0.0) << ",";
								//oss << "\"PosAccuracy\":" << setprecision(8) << bodyTMX.get<double>("PosAccuracy", 0.0) << ",";
								oss << "\"Latitude\":" << setprecision(8) << pickupLatitude << ",";
								oss << "\"Longitude\":" << setprecision(8) << pickupLongitude << ",";
								oss << "\"Elevation\":" << setprecision(8) << elevation << ",";
								oss << "\"PosAccuracy\":" << setprecision(8) << posAccuracy << ",";
								oss << "\"IsDSRCEquipped\":" << isDSRCEquipped << ",";
								oss << "\"ETA\":" << eta << ",";
								oss << "\"TotalRegSeatsAccepted\":" << regularSeats << ",";
								oss << "\"TotalMobilityNeedsSeatsAccepted\":" << handicappedSeats << "}";

								postData = oss.str();

								//PLOG(logDEBUG) << "Response: " << postData;
								PLOG(logDEBUG) << "Send PMM (Cloud) response";

								//always send response

								curlHandle = curl_easy_init();
								if (curlHandle)
								{
									curlResponse = "";
									//build URL
									curlURL = mobileDevicesApiUrl;
									curlURL.append("/api/PmmResponse");
									curl_easy_setopt(curlHandle, CURLOPT_URL, curlURL.c_str());
									curl_easy_setopt(curlHandle, CURLOPT_WRITEFUNCTION, HandleResponseOutput);
									curl_easy_setopt(curlHandle, CURLOPT_WRITEDATA, &curlResponse);
									curl_easy_setopt(curlHandle, CURLOPT_POSTFIELDS, postData.c_str());
									curl_easy_setopt(curlHandle, CURLOPT_POSTFIELDSIZE, postData.length());
									//modify header
									headerList = NULL;
									//headerList = curl_slist_append(headerList, "Host: mobiledeviceswebapidev.azurewebsites.net");
									headerList = curl_slist_append(headerList, "Content-Type: application/json");
									//oss.clear();
									//oss.str(string());
									//oss << "Content-Length: " << postData.length();
									//bodyLength = oss.str();
									//headerList = curl_slist_append(headerList, bodyLength.c_str());
									curl_easy_setopt(curlHandle, CURLOPT_HTTPHEADER, headerList);

									//send response
									curlRC = curl_easy_perform(curlHandle);
									curl_slist_free_all(headerList);
									if (curlRC == CURLE_OK)
									{
										//PLOG(logDEBUG) << "Curl response: " << curlResponse;
									}
									else
									{
										PLOG(logDEBUG) << "Curl error: " << curlRC;
									}
									PLOG(logDEBUG) << "CloudThread sending PmmResponse to the Cloud API, sent on: " << GetMsTimeSinceEpoch() << " - PMM fields: " << postData;
									curl_easy_cleanup(curlHandle);
								}
								else
								{
									PLOG(logDEBUG) << "curl_easy_init failed";
								}
							}
						}
						pos = nextPos;
					}

				}
			}
			else
			{
				if (MessageNotShown)
				{
					MessageNotShown = false;
					PLOG(logWARNING)
							<< "Invalid Mobile Devices WebApi URL configuration.  Mobile_Devices_Api_Url is empty or incorrect.";
				}
			}
		}
		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}
}

size_t VeaRideRequestPlugin::HandleResponseOutput(void *buffer, size_t size, size_t nmemb, void *userp)
{
	string *response = (string*)userp;
	response->append((const char *)buffer, size * nmemb);
	return size * nmemb;
}

void VeaRideRequestPlugin::NextDestinationThreadTaxi()
{
	uint64_t lastSendTime = 0;
	uint64_t currentTime;
	AcceptedPickupsStruct pickup;
	string groupId;
	PmmRequestMessage message;
	bool sendMessage;
	ostringstream oss;
	StatusTypes status;
	ModeOfTransportTypes modeOfTransport;
	PmmRequestMessage::SeatsByType seats;
	boost::smatch m;
	string pmmMsgCloudCopy;

	while (_plugin->state != IvpPluginState_error && !_stopThreads)
	{
		currentTime = GetMsTimeSinceEpoch();
		if (_newConfigValues && _nextDestinationFrequency > 0 && (currentTime - lastSendTime) > _nextDestinationFrequency)
		{
			sendMessage = false;
			//check queue
			{
				lock_guard<mutex> lock(_acceptedPickupsLock);
				while (!_acceptedPickupsOrder.empty() && !sendMessage)
				{
					groupId = _acceptedPickupsOrder.front();
					if (_cancelAllRequests)
					{
						//config parameter indicates we should cancel all requests
						_acceptedPickupsOrder.erase(_acceptedPickupsOrder.begin());
						if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
						{
							_acceptedPickups.erase(groupId);
						}
					}
					else if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
					{
						//found destination
						pickup = _acceptedPickups[groupId];
						pmmMsgCloudCopy = pickup.pmmMsgCloud;
						sendMessage = true;
					}
					else
					{
						//cant find destination, remove from order list
						_acceptedPickupsOrder.erase(_acceptedPickupsOrder.begin());
					}
				}
			}
			if (sendMessage)
			{
				try
				{

					//build message
					if (pmmMsgCloudCopy.empty())
					{
						//use DSRC message
						message.set_Id(NewGuid());
						message.set_GroupId(groupId);
						message.set_RequestId(pickup.requestId);
						//use ISO 8601 YYYY-MM-DD
						if (pickup.pmmMsgDSRC.requestDate.year != 0)
						{
							oss.clear();
							oss.str(string());
							oss << pickup.pmmMsgDSRC.requestDate.year << "-";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.requestDate.month << "-";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.requestDate.day << "T";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.requestDate.hour << ":";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.requestDate.minute;
							message.set_RequestDate(oss.str());
						}
						if (pickup.pmmMsgDSRC.pickupDate.year != 0)
						{
							oss.clear();
							oss.str(string());
							oss << pickup.pmmMsgDSRC.pickupDate.year << "-";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.pickupDate.month << "-";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.pickupDate.day << "T";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.pickupDate.hour << ":";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.pickupDate.minute;
							message.set_PickupDate(oss.str());
						}
						status = New;
						if (pickup.status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
							status = Updated;
						else if (pickup.status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
							status = Arrive;
						message.set_Status(status);
						modeOfTransport = noPreference;
						if (pickup.pmmMsgDSRC.modeOfTransport == ModeOfTransportType::ModeOfTransportType_rideShare)
							modeOfTransport = rideShare;
						else if (pickup.pmmMsgDSRC.modeOfTransport == ModeOfTransportType::ModeOfTransportType_taxi)
							modeOfTransport = taxi;
						else if (pickup.pmmMsgDSRC.modeOfTransport == ModeOfTransportType::ModeOfTransportType_transit)
							modeOfTransport = transit;
						message.set_ModeOfTransport(modeOfTransport);
						message.set_PickupLatitude((long)(pickup.pmmMsgDSRC.pickupLatitude * 10000000));
						message.set_PickupLongitude((long)(pickup.pmmMsgDSRC.pickupLongitude * 10000000));
						//set elevation to 0 since not found in DSRC message
						message.set_PickupElevation(0);
						if (pickup.pmmMsgDSRC.destinationLatitude != 0.0 && pickup.pmmMsgDSRC.destinationLongitude != 0.0)
						{
							message.set_DestLatitude((long)(pickup.pmmMsgDSRC.destinationLatitude * 10000000));
							message.set_DestLongitude((long)(pickup.pmmMsgDSRC.destinationLongitude * 10000000));
						}
						//set elevation to 0 since not found in DSRC message
						message.set_DestElevation(0);
						//set seat counts
						message.erase_SeatsByTypes();
						seats.Type = 0;
						seats.Count = pickup.pmmMsgDSRC.regularSeats;
						message.add_to_SeatsByTypes(seats);
						seats.Type = 1;
						seats.Count = pickup.pmmMsgDSRC.handicappedSeats;
						message.add_to_SeatsByTypes(seats);
						PLOG(logDEBUG) << "Send Next Destination TMXPmm (for DSRC request)";
					}
					else
					{
						//use Cloud message
						//parse json
						//PLOG(logDEBUG) << "NextDestinationThread use cloud before set_contents";
						//tmx::message bodyTMX;
						//{
						//	lock_guard<mutex> lock(_setContentsLock);
						//	bodyTMX.set_contents(pickup.pmmMsgCloud);
						//}
						//PLOG(logDEBUG) << "NextDestinationThread use cloud after set_contents";
						//set fields
						message.set_Id(NewGuid());
						message.set_GroupId(groupId);
						message.set_RequestId(pickup.requestId);
						//message.set_GroupId(bodyTMX.get<string>("GroupIdent", ""));
						//if (boost::regex_search(pickup.pmmMsgCloud, m, boost::regex("\"GroupIdent\":\"([^\"]+)\"")))
							//message.set_GroupId(m[1]);
						//message.set_RequestId((int)bodyTMX.get<uint32_t>("RequestId", 0));
						//if (boost::regex_search(pickup.pmmMsgCloud, m, boost::regex("\"RequestId\":([^,}]+)(,|\\})")))
							//message.set_RequestId(stoi(m[1]));
						//message.set_RequestDate(bodyTMX.get<string>("RequestDate", ""));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"RequestDate\":\"([^\"]+)\"")))
							message.set_RequestDate(m[1]);
						else
							message.set_RequestDate("");
						//message.set_PickupDate(bodyTMX.get<string>("PickupDate", ""));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupDate\":\"([^\"]+)\"")))
							message.set_PickupDate(m[1]);
						else
							message.set_PickupDate("");
						status = New;
						if (pickup.status == Updated)
							status = Updated;
						else if (pickup.status == Arrive)
							status = Arrive;
						message.set_Status(status);
						modeOfTransport = noPreference;
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"ModeofTransport\":([^,}]+)(,|\\})")))
						{
							if (stoi(m[1]) == rideShare)
								modeOfTransport = rideShare;
							else if (stoi(m[1]) == taxi)
								modeOfTransport = taxi;
							else if (stoi(m[1]) == transit)
								modeOfTransport = transit;
						}
						//f (bodyTMX.get<uint32_t>("ModeofTransport", 0) == rideShare)
						//	modeOfTransport = rideShare;
						//else if (bodyTMX.get<uint32_t>("ModeofTransport", 0) == taxi)
						//	modeOfTransport = taxi;
						//else if (bodyTMX.get<uint32_t>("ModeofTransport", 0) == transit)
						//	modeOfTransport = transit;
						message.set_ModeOfTransport(modeOfTransport);
						//message.set_PickupLatitude(bodyTMX.get<double>("PickupLatitude", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLatitude\":([^,}]+)(,|\\})")))
							message.set_PickupLatitude(stod(m[1]));
						else
							message.set_PickupLatitude(0.0);
						//message.set_PickupLongitude(bodyTMX.get<double>("PickupLongitude", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLongitude\":([^,}]+)(,|\\})")))
							message.set_PickupLongitude(stod(m[1]));
						else
							message.set_PickupLongitude(0.0);
						//message.set_PickupElevation(bodyTMX.get<double>("Elevation", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"Elevation\":([^,}]+)(,|\\})")))
							message.set_PickupElevation(stod(m[1]));
						else
							message.set_PickupElevation(0.0);
						//message.set_DestLatitude(bodyTMX.get<double>("DestLatitude", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLatitude\":([^,}]+)(,|\\})")))
							message.set_DestLatitude(stod(m[1]));
						else
							message.set_DestLatitude(0.0);
						//message.set_DestLongitude(bodyTMX.get<double>("DestLongitude", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLongitude\":([^,}]+)(,|\\})")))
							message.set_DestLongitude(stod(m[1]));
						else
							message.set_DestLongitude(0.0);
						//currently dont get DestElevation
						//message.set_DestElevation(bodyTMX.get<double>("DestElevation", 0));
						message.set_DestElevation(0.0);
						//set seat counts
						message.erase_SeatsByTypes();
						seats.Type = 0;
						//seats.Count = bodyTMX.get<uint32_t>("RegularSeats", 0);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"RegularSeats\":([^,}]+)(,|\\})")))
							seats.Count = stoi(m[1]);
						else
							seats.Count = 0;
						message.add_to_SeatsByTypes(seats);
						seats.Type = 1;
						//seats.Count = bodyTMX.get<uint32_t>("HandicappedSeats", 0);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"HandicappedSeats\":([^,}]+)(,|\\})")))
							seats.Count = stoi(m[1]);
						else
							seats.Count = 0;
						message.add_to_SeatsByTypes(seats);
						PLOG(logDEBUG) << "Send Next Destination TMXPmm (for Cloud request)";
					}
					PLOG(logDEBUG) << "TMXPmm contents: " << message.to_string();
					//send message
					lastSendTime = currentTime;
					BroadcastMessage(message);
					PLOG(logDEBUG) << "Next Destination Thread sending TMX Pmm Message to TMX Core, sent on: " << currentTime;
				}
				catch (exception &ex)
				{
					PLOG(logERROR) << "Exception thrown in VeaRideRequestPlugin::NextDestinationThread: " << ex.what();
				}
			}
		}
		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}
}

void VeaRideRequestPlugin::ArrivedThreadTaxi()
{
	uint64_t lastSendTime = 0;
	uint64_t currentTime;
	LocationMessage location;
	AcceptedPickupsStruct pickup;
	string groupId;
	bool haveDestination;
	LocationMessage locationCopy;
	uint64_t locationMsgTime;
	WGS84Point destinationLoc;
	WGS84Point pickupLoc;
	WGS84Point vehicleLoc;
	double distanceToDestination;
	double distanceToPickup;
	double vehicleSpeed;
	boost::smatch m;
	string pmmMsgCloudCopy;

	while (_plugin->state != IvpPluginState_error && !_stopThreads)
	{
		currentTime = GetMsTimeSinceEpoch();
		//get location message
		{
			lock_guard<mutex> lock(_locationLock);
			locationMsgTime = _locationMsgTime;
			locationCopy = _locationMsg;
		}
		if (_newConfigValues && _arrivedFrequency > 0 && (currentTime - lastSendTime) > _arrivedFrequency &&
				currentTime - locationMsgTime < _locationMsgExpireMs)
		{
			haveDestination = false;
			//check queue
			{
				lock_guard<mutex> lock(_acceptedPickupsLock);
				while (!_acceptedPickupsOrder.empty() && !haveDestination)
				{
					groupId = _acceptedPickupsOrder.front();
					if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
					{
						//have next destination
						pickup = _acceptedPickups[groupId];
						pmmMsgCloudCopy = pickup.pmmMsgCloud;
						haveDestination = true;
					}
					else
					{
						//cant find destination, remove from order list
						_acceptedPickupsOrder.erase(_acceptedPickupsOrder.begin());
					}
				}
			}

			//if have pickup or destination compare location with PMM location
			if (haveDestination)
			{
				vehicleLoc.Latitude = locationCopy.get_Latitude();
				vehicleLoc.Longitude = locationCopy.get_Longitude();
				vehicleSpeed = locationCopy.get_Speed_mph();
				if (pmmMsgCloudCopy.empty())
				{
					//use saved DSRC
					destinationLoc.Latitude = pickup.pmmMsgDSRC.destinationLatitude;
					destinationLoc.Longitude = pickup.pmmMsgDSRC.destinationLongitude;
					distanceToDestination = GeoVector::DistanceInMeters(vehicleLoc, destinationLoc);
					//check if at destination first
					if (distanceToDestination <= _arrivedRadius && vehicleSpeed <= _stoppedThresholdSpeed)
					{
						//we have arrived at destination, remove request
						lock_guard<mutex> lock(_acceptedPickupsLock);
						if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
						{
							_acceptedPickups.erase(groupId);
						}
					}
					else
					{
						//check if at pickup
						pickupLoc.Latitude = pickup.pmmMsgDSRC.pickupLatitude;
						pickupLoc.Longitude = pickup.pmmMsgDSRC.pickupLongitude;
						distanceToPickup = GeoVector::DistanceInMeters(vehicleLoc, pickupLoc);
						//we have arrived at pickup, send message
						if (distanceToPickup <= _arrivedRadius)
						{
							lastSendTime = currentTime;
							SendPmmMessage(groupId, pickup.requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival,
									_vehicleDescription, pickup.pmmMsgDSRC);
						}
					}
				}
				else
				{
					//use saved Cloud
					//parse json
					//tmx::message bodyTMX;
					//bodyTMX.clear();
					//{
					//	lock_guard<mutex> lock(_setContentsLock);
					//	bodyTMX.set_contents(pickup.pmmMsgCloud);
					//}

					//destinationLoc.Latitude = bodyTMX.get<double>("DestLatitude", 0);
					//destinationLoc.Longitude = bodyTMX.get<double>("DestLongitude", 0);
					if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLatitude\":([^,}]+)(,|\\})")))
						destinationLoc.Latitude = stod(m[1]);
					else
						destinationLoc.Latitude = 0.0;
					if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLongitude\":([^,}]+)(,|\\})")))
						destinationLoc.Longitude = stod(m[1]);
					else
						destinationLoc.Longitude = 0.0;
					distanceToDestination = GeoVector::DistanceInMeters(vehicleLoc, destinationLoc);
					//check if at destination first
					if (distanceToDestination <= _arrivedRadius)
					{
						//we have arrived at destination, remove request
						lock_guard<mutex> lock(_acceptedPickupsLock);
						if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
						{
							_acceptedPickups.erase(groupId);
						}
					}
					else
					{
						//check if at pickup
						//pickupLoc.Latitude = bodyTMX.get<double>("PickupLatitude", 0);
						//pickupLoc.Longitude = bodyTMX.get<double>("PickupLongitude", 0);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLatitude\":([^,}]+)(,|\\})")))
							pickupLoc.Latitude = stod(m[1]);
						else
							pickupLoc.Latitude = 0.0;
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLongitude\":([^,}]+)(,|\\})")))
							pickupLoc.Longitude = stod(m[1]);
						else
							pickupLoc.Longitude = 0.0;
						distanceToPickup = GeoVector::DistanceInMeters(vehicleLoc, pickupLoc);
						//we have arrived at pickup, send message
						if (distanceToPickup <= _arrivedRadius)
						{
							lastSendTime = currentTime;
							SendPmmMessage(groupId, pickup.requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival,
									_vehicleDescription, pmmMsgCloudCopy);
						}
					}
				}
			}
		}

		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}
}

void VeaRideRequestPlugin::NextDestinationThreadTransit()
{
	uint64_t lastSendTime = 0;
	uint64_t currentTime;
	AcceptedPickupsStruct pickup;
	string groupId;
	PmmRequestMessage message;
	bool sendMessage;
	ostringstream oss;
	StatusTypes status;
	ModeOfTransportTypes modeOfTransport;
	PmmRequestMessage::SeatsByType seats;
	boost::smatch m;
	string pmmMsgCloudCopy;
	uint32_t nextTransitStop;
	uint32_t nextTransitStopId;
	bool found;
	uint32_t totalRegularPickups;
	//uint32_t totalRegularDropoffs;
	uint32_t totalHandicappedPickups;
	//uint32_t totalHandicappedDropoffs;

	while (_plugin->state != IvpPluginState_error && !_stopThreads)
	{
		currentTime = GetMsTimeSinceEpoch();
		if (_newConfigValues && _nextDestinationFrequency > 0 &&
				(currentTime - lastSendTime) > _nextDestinationFrequency && _haveTransitStopList)
		{
			sendMessage = false;

			//get next pickup stop order number
			{
				lock_guard<mutex> lock1(_acceptedPickupsLock);
				lock_guard<mutex> lock2(_transitStopsLock);
				nextTransitStop = _lastVisitedTransitStop;
				found = false;
				do
				{
					nextTransitStop += 1;
					if (nextTransitStop > _transitStopCount)
						nextTransitStop = 1;
					if (_cancelAllRequests)
					{
						//if canceling set all totals to 0
						_transitStops[_transitStopOrder[nextTransitStop]].totalRegularPickups = 0;
						_transitStops[_transitStopOrder[nextTransitStop]].totalRegularDropoffs = 0;
						_transitStops[_transitStopOrder[nextTransitStop]].totalHandicappedPickups = 0;
						_transitStops[_transitStopOrder[nextTransitStop]].totalHandicappedDropoffs = 0;
					}
					else if (_transitStops[_transitStopOrder[nextTransitStop]].totalRegularPickups > 0 ||
							_transitStops[_transitStopOrder[nextTransitStop]].totalHandicappedPickups > 0) //checking only pickups for now
					{
						nextTransitStopId = _transitStopOrder[nextTransitStop];
						//get one associated pickup for this stop
						for (auto it = _acceptedPickups.begin();it != _acceptedPickups.end() && !found;++it)
						{
							if (it->second.transitStopPickupId == nextTransitStopId)
							{
								found = true;
								sendMessage = true;
								pickup = it->second;
								groupId = pickup.groupId;
								pmmMsgCloudCopy = pickup.pmmMsgCloud;
								totalRegularPickups = _transitStops[_transitStopOrder[nextTransitStop]].totalRegularPickups;
								//totalRegularDropoffs = _transitStops[_transitStopOrder[nextTransitStop]].totalRegularDropoffs;
								totalHandicappedPickups = _transitStops[_transitStopOrder[nextTransitStop]].totalHandicappedPickups;
								//totalHandicappedDropoffs = _transitStops[_transitStopOrder[nextTransitStop]].totalHandicappedDropoffs;
							}
						}
					}
				}
				while (nextTransitStop != _lastVisitedTransitStop && !found);
				//if canceling clear out all pickups
				if (_cancelAllRequests)
					_acceptedPickups.clear();
			}

			if (sendMessage)
			{
				try
				{

					//build message
					if (pmmMsgCloudCopy.empty())
					{
						//use DSRC message

						message.set_Id(NewGuid());
						message.set_GroupId(groupId);
						message.set_RequestId(pickup.requestId);
						//use ISO 8601 YYYY-MM-DD
						if (pickup.pmmMsgDSRC.requestDate.year != 0)
						{
							oss.clear();
							oss.str(string());
							oss << pickup.pmmMsgDSRC.requestDate.year << "-";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.requestDate.month << "-";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.requestDate.day << "T";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.requestDate.hour << ":";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.requestDate.minute;
							message.set_RequestDate(oss.str());
						}
						if (pickup.pmmMsgDSRC.pickupDate.year != 0)
						{
							oss.clear();
							oss.str(string());
							oss << pickup.pmmMsgDSRC.pickupDate.year << "-";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.pickupDate.month << "-";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.pickupDate.day << "T";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.pickupDate.hour << ":";
							oss << left << setfill('0') << setw(2) << pickup.pmmMsgDSRC.pickupDate.minute;
							message.set_PickupDate(oss.str());
						}
						status = New;
						if (pickup.status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
							status = Updated;
						else if (pickup.status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
							status = Arrive;
						message.set_Status(status);
						modeOfTransport = noPreference;
						if (pickup.pmmMsgDSRC.modeOfTransport == ModeOfTransportType::ModeOfTransportType_rideShare)
							modeOfTransport = rideShare;
						else if (pickup.pmmMsgDSRC.modeOfTransport == ModeOfTransportType::ModeOfTransportType_taxi)
							modeOfTransport = taxi;
						else if (pickup.pmmMsgDSRC.modeOfTransport == ModeOfTransportType::ModeOfTransportType_transit)
							modeOfTransport = transit;
						message.set_ModeOfTransport(modeOfTransport);
						message.set_PickupLatitude((long)(pickup.pmmMsgDSRC.pickupLatitude * 10000000));
						message.set_PickupLongitude((long)(pickup.pmmMsgDSRC.pickupLongitude * 10000000));
						message.set_DestLatitude((long)(pickup.pmmMsgDSRC.pickupLatitude * 10000000));
						message.set_DestLongitude((long)(pickup.pmmMsgDSRC.pickupLongitude * 10000000));

						//set elevation to 0 since not found in DSRC message
						message.set_PickupElevation(0);

						//set destination to pickup above for now
//							if (pmm->destination != NULL)
//							{
//								message.set_DestLatitude(pmm->destination->lat);
//								message.set_DestLongitude(pmm->destination->lon);
//							}
						//set elevation to 0 since not found in DSRC message
						message.set_DestElevation(0);
						//set seat counts
						message.erase_SeatsByTypes();
						seats.Type = 0;
						seats.Count = totalRegularPickups;
						message.add_to_SeatsByTypes(seats);
						seats.Type = 1;
						seats.Count = totalHandicappedPickups;
						message.add_to_SeatsByTypes(seats);
						PLOG(logDEBUG) << "Send Next Destination TMXPmm (for DSRC request)";
					}
					else
					{
						//use Cloud message
						//parse json
						//PLOG(logDEBUG) << "NextDestinationThread use cloud before set_contents";
						//set fields
						message.set_Id(NewGuid());
						message.set_GroupId(groupId);
						message.set_RequestId(pickup.requestId);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"RequestDate\":\"([^\"]+)\"")))
							message.set_RequestDate(m[1]);
						else
							message.set_RequestDate("");
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupDate\":\"([^\"]+)\"")))
							message.set_PickupDate(m[1]);
						else
							message.set_PickupDate("");
						status = New;
						if (pickup.status == Updated)
							status = Updated;
						else if (pickup.status == Arrive)
							status = Arrive;
						message.set_Status(status);
						modeOfTransport = noPreference;
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"ModeofTransport\":([^,}]+)(,|\\})")))
						{
							if (stoi(m[1]) == rideShare)
								modeOfTransport = rideShare;
							else if (stoi(m[1]) == taxi)
								modeOfTransport = taxi;
							else if (stoi(m[1]) == transit)
								modeOfTransport = transit;
						}
						message.set_ModeOfTransport(modeOfTransport);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLatitude\":([^,}]+)(,|\\})")))
						{
							message.set_PickupLatitude(stod(m[1]));
							message.set_DestLatitude(stod(m[1]));
						}
						else
						{
							message.set_PickupLatitude(0.0);
							message.set_DestLatitude(0.0);
						}
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLongitude\":([^,}]+)(,|\\})")))
						{
							message.set_PickupLongitude(stod(m[1]));
							message.set_DestLongitude(stod(m[1]));
						}
						else
						{
							message.set_PickupLongitude(0.0);
							message.set_DestLongitude(0.0);
						}
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"Elevation\":([^,}]+)(,|\\})")))
							message.set_PickupElevation(stod(m[1]));
						else
							message.set_PickupElevation(0.0);
						//set destination to pickup above for now
//						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLatitude\":([^,}]+)(,|\\})")))
//							message.set_DestLatitude(stod(m[1]));
//						else
//							message.set_DestLatitude(0.0);
//						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLongitude\":([^,}]+)(,|\\})")))
//							message.set_DestLongitude(stod(m[1]));
//						else
//							message.set_DestLongitude(0.0);
						//currently dont get DestElevation
						message.set_DestElevation(0.0);
						//set seat counts
						message.erase_SeatsByTypes();
						seats.Type = 0;
						seats.Count = totalRegularPickups;
						message.add_to_SeatsByTypes(seats);
						seats.Type = 1;
						seats.Count = totalHandicappedPickups;
						message.add_to_SeatsByTypes(seats);
						PLOG(logDEBUG) << "Send Next Destination TMXPmm (for Cloud request)";
					}
					PLOG(logDEBUG) << "TMXPmm contents: " << message.to_string();
					//send message
					lastSendTime = currentTime;
					BroadcastMessage(message);
					PLOG(logDEBUG) << "Next Destination Thread sending TMX Pmm Message to TMX Core, sent on: " << currentTime;
				}
				catch (exception &ex)
				{
					PLOG(logERROR) << "Exception thrown in VeaRideRequestPlugin::NextDestinationThread: " << ex.what();
				}
			}
		}
		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}
}

void VeaRideRequestPlugin::ArrivedThreadTransit()
{
	uint64_t lastSendTime = 0;
	uint64_t currentTime;
	LocationMessage location;
	AcceptedPickupsStruct pickup;
	bool haveArrived;
	LocationMessage locationCopy;
	uint64_t locationMsgTime;
	string pmmMsgCloudCopy;
	uint32_t transitStopId;
	uint32_t nextTransitStop;
	bool found;

	while (_plugin->state != IvpPluginState_error && !_stopThreads)
	{
		currentTime = GetMsTimeSinceEpoch();
		//get location message
		{
			lock_guard<mutex> lock(_locationLock);
			locationMsgTime = _locationMsgTime;
			locationCopy = _locationMsg;
		}
		if (_newConfigValues && _arrivedFrequency > 0 && (currentTime - lastSendTime) > _arrivedFrequency &&
				currentTime - locationMsgTime < _locationMsgExpireMs && _haveTransitStopList)
		{
			haveArrived = false;

			//get arrived transit stop
			transitStopId = GetTransitStopId(locationCopy.get_Latitude(), locationCopy.get_Longitude(), _arrivedRadius, locationCopy.get_Heading());

			if (transitStopId > 0 && locationCopy.get_Speed_mph() <= _stoppedThresholdSpeed)
			{
				//we are stopped at a transit stop
				_currentTransitStopId = transitStopId;
				haveArrived = true;
			}
			else
			{
				//we are not stopped at a transit stop
				if (_currentTransitStopId != 0)
				{
					//we have just departed a transit stop
					//find next transit stop
					{
						lock_guard<mutex> lock(_transitStopsLock);
						nextTransitStop = _lastVisitedTransitStop;
						found = false;
						do
						{
							nextTransitStop += 1;
							if (nextTransitStop > _transitStopCount)
								nextTransitStop = 1;

							if (_transitStopOrder[nextTransitStop] == _currentTransitStopId)
							{
								_lastVisitedTransitStop = nextTransitStop;
								found = true;
							}
						}
						while (nextTransitStop != _lastVisitedTransitStop && !found);
					}
					//clear pickup and dropoff counts of stop we left
					_transitStops[_currentTransitStopId].totalRegularPickups = 0;
					_transitStops[_currentTransitStopId].totalRegularDropoffs = 0;
					_transitStops[_currentTransitStopId].totalHandicappedPickups = 0;
					_transitStops[_currentTransitStopId].totalHandicappedDropoffs = 0;
					//remove all accepted pickups
					auto it = _acceptedPickups.begin();
					while (it != _acceptedPickups.end())
					{
						//delete accepted pickup if pickup id matches stop we left
						if (it->second.transitStopPickupId == _currentTransitStopId)
							it = _acceptedPickups.erase(it);
						else
							it++;
					}
					_currentTransitStopId = 0;
				}
			}

			if (haveArrived)
			{
				//we are at a transit stop, send arrived messages for all pickups (not dropoffs)
				for (auto it = _acceptedPickups.begin();it != _acceptedPickups.end();++it)
				{
					if (it->second.transitStopPickupId == _currentTransitStopId)
					{
						pickup = it->second;
						pmmMsgCloudCopy = pickup.pmmMsgCloud;
						if (pmmMsgCloudCopy.empty())
						{
							//use saved DSRC message
							lastSendTime = currentTime;
							SendPmmMessage(pickup.groupId, pickup.requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival,
									_vehicleDescription, pickup.pmmMsgDSRC);
						}
						else
						{
							//use saved Cloud message
							lastSendTime = currentTime;
							SendPmmMessage(pickup.groupId, pickup.requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival,
									_vehicleDescription, pmmMsgCloudCopy);
						}
					}
				}
			}
		}


		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}
}

} /* namespace VeaRideRequestPlugin */

int main(int argc, char *argv[])
{
	return run_plugin<VeaRideRequestPlugin::VeaRideRequestPlugin>("VeaRideRequestPlugin", argc, argv);
}
