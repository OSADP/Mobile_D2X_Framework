﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android;
using HockeyApp.Android;
using Android.Support.V4.App;
using Android.Content;

namespace MobileDevicesExperimentalApplication.Droid
{
    [Activity(Label = "MobileDevicesExperimentalApplication", Icon = "@drawable/icon", Theme = "@style/MainTheme", MainLauncher = true, ScreenOrientation = ScreenOrientation.Portrait, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity, ActivityCompat.IOnRequestPermissionsResultCallback
    {
        readonly string[] PermissionsLocation =
        {
          Manifest.Permission.AccessCoarseLocation,
          Manifest.Permission.AccessFineLocation
        };

        const int RequestLocationId = 0;


        readonly string[] PermissionsStorage =
        {
          Manifest.Permission.WriteExternalStorage
        };

        const int RequestStorageId = 1;


        readonly string[] PermissionsActivityDetection =
        {
           "ACTIVITY_RECOGNITION"//Manifest.Permission.ActivityRecognition
        };

        const int RequestActDetId = 2;

        Intent ServiceIntent;

        protected override void OnCreate(Bundle bundle)
        {
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;

            base.OnCreate(bundle);

            global::Xamarin.Forms.Forms.Init(this, bundle);
            SharedData.MainApp = new App();
            LoadApplication(SharedData.MainApp);

            ServiceIntent = new Intent(this, typeof(TaskRemoveService));
            StartService(ServiceIntent);

            CrashManager.Register(this, "70d210b1f0624c118123c6a6411c4748");

            if ((int)Build.VERSION.SdkInt >= 23)
            {
                const string permission = Manifest.Permission.AccessFineLocation;
                if (CheckSelfPermission(permission) != (int)Permission.Granted)
                {
                    RequestPermissions(PermissionsLocation, RequestLocationId);
                }

                const string storagepermission = Manifest.Permission.WriteExternalStorage;
                if (CheckSelfPermission(storagepermission) != (int)Permission.Granted)
                {
                    RequestPermissions(PermissionsStorage, RequestStorageId);
                }

                //const string activityDetectPermission = "ACTIVITY_RECOGNITION";// Manifest.Permission.ActivityRecognition;
                //if (CheckSelfPermission(activityDetectPermission) != (int)Permission.Granted)
                //{
                //    RequestPermissions(PermissionsActivityDetection, RequestActDetId);
                //}
            }
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            switch (requestCode)
            {
                case RequestLocationId:
                    {
                        if (grantResults[0] == Permission.Granted)
                        {

                        }
                        else
                        {

                        }
                    }
                    break;
            }
        }

        protected override void OnDestroy()
        {
            HomePage hp;
            hp = (HomePage)SharedData.MainApp.MainPage;
            hp.OnActivityDestroy();
            base.OnDestroy();
            this.Dispose();
        }

    }

    [Service]
    public class TaskRemoveService : Service
    {
        public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
        {
            return StartCommandResult.Sticky;
        }

        public override IBinder OnBind(Intent intent)
        {
            return null;
        }
        public override void OnTaskRemoved(Intent intent)
        {
            HomePage hp;
            try
            {
                hp = (HomePage)SharedData.MainApp.MainPage;
                hp.OnActivityDestroy();
                StopSelf();
            }
            catch
            {
            }
        }
    }

    public class SharedData
    {
        public static Xamarin.Forms.Application MainApp = null;
    }
}

