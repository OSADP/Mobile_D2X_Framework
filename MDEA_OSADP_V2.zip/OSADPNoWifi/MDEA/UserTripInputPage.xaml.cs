﻿using CITOMobileCommon.J2735.Ext;
using CITOMobileCommon.Logging;
using CITOMobileCommon.Models;
using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Maps;

namespace MobileDevicesExperimentalApplication
{
    public class UserTripInput
    {
        public UserTripInput(Coordinates destination, int regSeats, int handSeats, string mode)
        {
            HandicapSeats = handSeats;
            RegularSeats = regSeats;
            Destination = destination;
            ModeOfTransport = mode;
        }

        public UserTripInput(int regSeats, int handSeats, string mode, string transitRoute, string transitPickupStop)
        {
            HandicapSeats = handSeats;
            RegularSeats = regSeats;
            Destination = new Coordinates(0, 0);
            ModeOfTransport = mode;
            TransitRoute = transitRoute;
            TransitPickupStop = transitPickupStop;
        }

        public int HandicapSeats { get; private set; }
        public int RegularSeats { get; private set; }
        public Coordinates Destination { get; private set; }
        public string ModeOfTransport { get; private set; }
        public string TransitRoute { get; private set; }
        public string TransitPickupStop { get; private set; }
    }

    public partial class UserTripInputPage : PopupPage
    {

        private Coordinates LastSelectedCoordinates;

        public event EventHandler<UserTripInput> UserTripInputRequested;
        public event EventHandler UserTripCanceled;

        public UserTripInputPage(Coordinates currentLocation)
        {
            InitializeComponent();

            for (int i = 0; i <= 10; i++)
            {
                RegularSeatPicker.Items.Add((i).ToString());
                HandicapSeatPicker.Items.Add((i).ToString());
            }

            HandicapSeatPicker.SelectedIndex = 0;
            RegularSeatPicker.SelectedIndex = 1;

            CustomMapView.MoveToRegion(MapSpan.FromCenterAndRadius(new Position(currentLocation.Latitude, currentLocation.Longitude), Distance.FromKilometers(.15)));
            CustomMapView.MapClicked += CustomMapView_MapClicked;
        }

        private void CustomMapView_MapClicked(object sender, Coordinates e)
        {
            LastSelectedCoordinates = e;
            Logger.Debug("MDEA", "Map Clicked: " + e.Latitude.ToString() + ", " + e.Longitude.ToString());
        }

        private async void RequestButton_Clicked(object sender, EventArgs e)
        {
            if (LastSelectedCoordinates != null)
            {
                UserTripInputRequested?.Invoke(this, new UserTripInput(LastSelectedCoordinates, RegularSeatPicker.SelectedIndex, HandicapSeatPicker.SelectedIndex, "taxi"));
             //   await Task.Delay(500);
                await PopupNavigation.PopAsync().ConfigureAwait(false);
            }

        }

        private async void CancelButton_Clicked(object sender, EventArgs e)
        {
            UserTripCanceled?.Invoke(this, e);
            await PopupNavigation.PopAsync().ConfigureAwait(false);
        }

    }
}
