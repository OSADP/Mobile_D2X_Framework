﻿using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace MobileDevicesExperimentalApplication
{
    public partial class PopupAlert : PopupPage
    {
        public PopupAlert()
        {
            InitializeComponent();
        }

        public async void SetAlert(SafetyMon.PedestrianSafetyStatusEnum alertType)
        {
            
            switch(alertType)
            {
                case SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_ADVISORY:
                    IsShowingAlert = true;
                    AlertImage.Source = "ped_safety_advisory.png";
                    break;
                case SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_ALERT:
                    IsShowingAlert = true;
                    AlertImage.Source = "ped_safety_alert.png";
                    break;
                case SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_WARNING:
                    IsShowingAlert = true;
                    AlertImage.Source = "ped_safety_warning.png";
                    break;
                default:
                    
                    IsShowingAlert = false;
                    break;
            }
        }

        public bool IsShowingAlert { get; set; }
    }
}
