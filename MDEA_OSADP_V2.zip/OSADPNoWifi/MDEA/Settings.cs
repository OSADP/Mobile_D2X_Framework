﻿using System;
using Plugin.Settings;
using Plugin.Settings.Abstractions;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication
{
    public enum InVehicleDetectionSetting
    {
        NotIn = 0,    //Always report NOT in vehicle
        In=1,       //Always report IN vehicle  
        UseGps=2,   //Use phone gps information to detect when in vehicle
        UseBeacon=3, //Use Bluetooth Beacon to detect when in vehicle
        UseActivityLib = 4
    }
    public enum SafetyDetectionSetting
    {
        UnsafeZone = 0,    //Always report NOT safe
        NotUnsafeZone = 1,       //Always report SAFE  
        UseMap = 2   //Use MAP information to detect when safe
    }
    public enum SendPsmSetting
    {
        NeverSend = 0,      //Never send PSMs
        AlwaysSend = 1,     //Always send PSMs  
        UseAllRules = 2         //Do all other logic&features concerning when to send/not send PSM
       // IgnoreSafeZoneRule = 3   //Do all other logic&features concerning when to send/not send PSM, 
            //EXCEPT don't suppress the sending when in safe zone.
    }
    public static class Settings
    {
        public static event EventHandler<String> SettingChanged;

        public static string ToString()
        {
            string s = "WifiDirectTimeout = " + WifiDirectTimeout 
                + " DsrcTimeout = " + DsrcTimeout
                + " PersonalRadiusOfProtection = " + PersonalRadiusOfProtection
                + " LocomateDeviceMac = " + LocomateDeviceMac
                + " InVehicleDetection = " + InVehicleDetection.ToString()
                + " SafetyDetection = " + SafetyDetection.ToString()
                + " SendPsm = " + SendPsm.ToString()
                + " LogLocationEarth = " + LogLocationEarth
                + " DisplayStatusMessages = " + DisplayStatusMessages
                + " SimulatedLocation = " + SimulatedLocation;
            return s;
        }
        private static ISettings AppSettings
        {
            get
            {
                return CrossSettings.Current;
            }
        }

        private const string WifiDirectTimeoutFrequencyKey = "wifi_direct_timeout";
        private static readonly int WifiDirectTimeoutKeyDefault = 20;

        public static int WifiDirectTimeout
        {
            get { return AppSettings.GetValueOrDefault<int>(WifiDirectTimeoutFrequencyKey, WifiDirectTimeoutKeyDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<int>(WifiDirectTimeoutFrequencyKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.WifiDirectTimeout));
            }
        }

        private const string DsrcTimeoutKey = "dsrc_timout";
        private static readonly int DsrcTimeoutKeyDefault = 20;

        public static int DsrcTimeout
        {
            get { return AppSettings.GetValueOrDefault<int>(DsrcTimeoutKey, DsrcTimeoutKeyDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<int>(DsrcTimeoutKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.DsrcTimeout));
            }
        }

        private const string PersonalRadiusOfProtectionKey = "personal_radius_of_protection";
        private static readonly int PersonalRadiusOfProtectionKeyDefault = 10;

        public static int PersonalRadiusOfProtection
        {
            get { return AppSettings.GetValueOrDefault<int>(PersonalRadiusOfProtectionKey, PersonalRadiusOfProtectionKeyDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<int>(PersonalRadiusOfProtectionKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.PersonalRadiusOfProtection));
            }
        }

        private const string LocomateDeviceMacKey = "locomate_device";
        private static readonly string LocomateDeviceMacKeyDefault = string.Empty;

        public static string LocomateDeviceMac
        {
            get { return AppSettings.GetValueOrDefault<string>(LocomateDeviceMacKey, LocomateDeviceMacKeyDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<string>(LocomateDeviceMacKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.LocomateDeviceMac));
            }
        }

   
        private const string InVehicleDetectionKey = "in_veh_detection";
        private const InVehicleDetectionSetting InVehicleDetectionKeyDefault = InVehicleDetectionSetting.UseGps;
        public static InVehicleDetectionSetting InVehicleDetection
        {
            get { return AppSettings.GetValueOrDefault<InVehicleDetectionSetting>(InVehicleDetectionKey, InVehicleDetectionKeyDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<InVehicleDetectionSetting>(InVehicleDetectionKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.InVehicleDetection));
            }
        }

        private const string SafetyDetectionKey = "safety_detection";
        private const SafetyDetectionSetting SafetyDetectionKeyDefault = SafetyDetectionSetting.UseMap;
        public static SafetyDetectionSetting SafetyDetection
        {
            get { return AppSettings.GetValueOrDefault<SafetyDetectionSetting>(SafetyDetectionKey, SafetyDetectionKeyDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<SafetyDetectionSetting>(SafetyDetectionKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SafetyDetection));
            }
        }

        private const string SendPsmKey = "send_psm";
        private const SendPsmSetting SendPsmKeyDefault = SendPsmSetting.UseAllRules;
        public static SendPsmSetting SendPsm
        {
            get { return AppSettings.GetValueOrDefault<SendPsmSetting>(SendPsmKey, SendPsmKeyDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<SendPsmSetting>(SendPsmKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SendPsm));
            }
        }

        private const string LogLocationEarthKey = "log_location_earth";
        private const bool LogLocationEarthDefault = false;
        public static bool LogLocationEarth
        {
            get { return AppSettings.GetValueOrDefault<bool>(LogLocationEarthKey, LogLocationEarthDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<bool>(LogLocationEarthKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.LogLocationEarth));
            }
        }

        private const string DisplayStatusMessagesKey = "display_status_messages";
        private const bool DisplayStatusMessagesDefault = false;
        public static bool DisplayStatusMessages
        {
            get { return AppSettings.GetValueOrDefault<bool>(DisplayStatusMessagesKey, DisplayStatusMessagesDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<bool>(DisplayStatusMessagesKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.DisplayStatusMessages));
            }
        }

        private const string SimulatedLocationsKey = "simulated_location";
        private const bool SimulatedLocationDefault = false;
        public static bool SimulatedLocation
        {
            get { return AppSettings.GetValueOrDefault<bool>(SimulatedLocationsKey, SimulatedLocationDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<bool>(SimulatedLocationsKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SimulatedLocation));
            }
        }

        private const string SimulatedLatitudeKey = "simulated_latitude";
        private const double SimulatedLatitudeDefault = 0.0;
        public static double SimulatedLatitude
        {
            get { return AppSettings.GetValueOrDefault<double>(SimulatedLatitudeKey, SimulatedLatitudeDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<double>(SimulatedLatitudeKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SimulatedLatitude));
            }
        }

        private const string SimulatedLongitudeKey = "simulated_longitude";
        private const double SimulatedLongitudeDefault = 0.0;
        public static double SimulatedLongitude
        {
            get { return AppSettings.GetValueOrDefault<double>(SimulatedLongitudeKey, SimulatedLongitudeDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<double>(SimulatedLongitudeKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SimulatedLongitude));
            }
        }

        private const string SimulatedPathKey = "simulated_path";
        private const bool SimulatedPathDefault = false;
        public static bool SimulatedPath
        {
            get { return AppSettings.GetValueOrDefault<bool>(SimulatedPathKey, SimulatedPathDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<bool>(SimulatedPathKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SimulatedPath));
            }
        }

        private const string SimulatedPathDurationKey = "simulated_path_duration";
        private const int SimulatedPathDurationDefault = 1;
        public static int SimulatedPathDuration
        {
            get { return AppSettings.GetValueOrDefault<int>(SimulatedPathDurationKey, SimulatedPathDurationDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<int>(SimulatedPathDurationKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SimulatedPathDuration));
            }
        }

        private const string SimulatedEndLatitudeKey = "simulated_end_latitude";
        private const double SimulatedEndLatitudeDefault = 0.0;
        public static double SimulatedEndLatitude
        {
            get { return AppSettings.GetValueOrDefault<double>(SimulatedEndLatitudeKey, SimulatedEndLatitudeDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<double>(SimulatedEndLatitudeKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SimulatedEndLatitude));
            }
        }

        private const string SimulatedEndLongitudeKey = "simulated_end_longitude";
        private const double SimulatedEndLongitudeDefault = 0.0;
        public static double SimulatedEndLongitude
        {
            get { return AppSettings.GetValueOrDefault<double>(SimulatedEndLongitudeKey, SimulatedEndLongitudeDefault); }
            set
            {
                AppSettings.AddOrUpdateValue<double>(SimulatedEndLongitudeKey, value);
                SettingChanged?.Invoke(null, nameof(Settings.SimulatedEndLongitude));
            }
        }

    }
}
