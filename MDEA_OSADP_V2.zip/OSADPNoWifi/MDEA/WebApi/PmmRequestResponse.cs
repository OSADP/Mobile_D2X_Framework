﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication.WebApi
{
    public class PmmRequestResponse
    {
        public int Id { get; set; }
        public string GroupIdent { get; set; }
        public int RequestId { get; set; }
        public string RequestDate { get; set; }
        public string PickupDate { get; set; }
        public int Status { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double Elevation { get; set; }
        public double PosAccuracy { get; set; }
        public string Destination { get; set; }
        public int RegularSeats { get; set; }
        public int HandicappedSeats { get; set; }
    }
}
