﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication.WebApi
{
    /// <summary>
    /// Mapping from bus stop/route to pickup&destination/latitude&longitude.
    /// The DSRC messages are fixed for this phase in the project. So for the MDEA to support transit, we need a mapping
    /// from bus stop values to pickup and destination latitude longitude, since that is what is sent in the PMM.
    /// </summary>
    public class BusRoute
    {
        /// <summary>
        /// Id: database assigned unique identifier per row.  
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Route to match.
        /// </summary>
        [StringLength(50)]
        public string TransitRoute { get; set; }
        /// <summary>
        /// Pickup stop to match.
        /// </summary>
        [StringLength(50)]
        public string TransitPickupStop { get; set; }
        /// <summary>
        /// 0-360 bearing of bus when at the stop.  This is used to differentiate between northbound and southbound stops at same location.
        /// </summary>
        public int TransitStopBearing { get; set; }
        /// <summary>
        /// Number 1-N of stops in order along the route.  Comma-separated if one stop is hit twice on route (figure 8 route)
        /// </summary>
        [StringLength(10)]
        public string TransitStopOrder { get; set; }

        /// <summary>
        /// Populated with a point at the bus stop
        /// </summary>
        public double PickupLat { get; set; } 
        public double PickupLong { get; set; }
        /// <summary>
        /// Populated with a point at the “end” of the route. Approximate. Where traveler disembarks is not really needed.
        /// </summary>
        public double DestLat { get; set; }
        public double DestLong { get; set; }

    }
}
