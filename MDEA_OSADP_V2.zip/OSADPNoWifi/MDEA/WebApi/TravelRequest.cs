﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication.WebApi
{
    public enum TravelReqStatus
    {
        Active=0,
        Cancelled =1,//cancelled by choice (leader or follower)//This status must string match the one sent in MDEA PmmStatusEventArgs.
        Complete =2,//This status must string match the one sent in MDEA PmmStatusEventArgs.
        Closed =3 //A new trip request was made when an old trip was still Active - we don't know what happened to it, so close it out.
    }
    /// <summary>
    /// Row added by MDEA when user requests a trip.  
    /// Updated by cloud service to name leader/group.
    /// </summary>
    public class TravelRequest
    {
        /// <summary>
        /// Id: database assigned unique identifier per row.  
        /// </summary>
        public int? Id { get; set; }
        /// <summary>
        /// Time of request.
        /// </summary>
        public DateTime? Time { get; set; }
        /// <summary>
        /// Self-assigned by MDEA for user.
        /// </summary>
        public Guid FollowerId { get; set; }
        /// <summary>
        /// Time pickup  is requested.
        /// Unused for this version, pickup always 'now'.
        /// </summary>
        public DateTime PickupTime { get; set; }
        /// <summary>
        /// If request is transit, Route of requested bus. Empty string if taxi request.
        /// </summary>
        public string TransitRoute { get; set; }
        /// <summary>
        /// If request is transit, Name of bus stop of requested bus.  Empty string if taxi request.
        /// </summary>
        public string TransitPickupStop { get; set; }
        /// <summary>
        /// If request is taxi, latitude of pickup spot. 0 if transit request.
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public double? TaxiPickupLat { get; set; }
        /// <summary>
        /// If request is taxi, longitude of pickup spot. 0 if transit request.
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public double? TaxiPickupLong { get; set; }
        /// <summary>
        /// If request is taxi, latitude of destination spot. 0 if transit request.
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public double? TaxiDestLat { get; set; }
        /// <summary>
        /// If request is taxi, longitude of destination spot. 0 if transit request.
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public double? TaxiDestLong { get; set; }



        /// <summary>
        ///  Populated by cloud service when group assigned.
        /// </summary>
        public Guid? GroupId { get; set; }

        /// <summary>
        ///  Initialized to false.  Modified by cloud service when group assigned.
        /// </summary>
        public bool IsLeader { get; set; }
        /// <summary>
        /// – (Active/Canceled/Complete);
        /// initialized to Active.
        /// Modified by cloud service.
        /// </summary>
        public TravelReqStatus Status { get; set; }


        public override string ToString()
        {
            string k;
            k = ((Id != null) ? "Id: " + this.Id : "")
             + "FollowerId: " + this.FollowerId
             + "GroupId: " + this.GroupId
             + "IsLeader: " + this.IsLeader
             + "Status: " + this.Status
             + ((PickupTime != null) ? "PickupTime: " + this.PickupTime : "")
             + ((TransitRoute != null) ? "TransitRoute: " + this.TransitRoute : "")
             + ((TransitPickupStop != null) ? "TransitPickupStop: " + this.TransitPickupStop : "")
             + ((TaxiPickupLat != null) ? "TaxiPickupLat: " + this.TaxiPickupLat : "")
             + ((TaxiPickupLong != null) ? "TaxiPickupLong: " + this.TaxiPickupLong : "")
             + ((TaxiDestLat != null) ? "TaxiDestLat: " + this.TaxiDestLat : "")
             + ((TaxiDestLong != null) ? "TaxiDestLong: " + this.TaxiDestLong : "");
            return k;
        }

    }
}
