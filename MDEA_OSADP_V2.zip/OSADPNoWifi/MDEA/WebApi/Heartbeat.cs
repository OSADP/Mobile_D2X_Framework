﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication.WebApi
{
    /// <summary>
    /// Heartbeats are uploaded by all followers on a configurable (per second) basis.
    /// Cancellation of request defined by when RegSeats and HcapSeats are both 0.
    /// </summary>
    public class Heartbeat
    {
        /// <summary>
        /// Id: database assigned unique identifier per row.  
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Time of udpate.
        /// </summary>
        public DateTime Time { get; set; }
        /// <summary>
        /// GroupId assigned to traveler's travel request.
        /// </summary>
        public Guid GroupId { get; set; }
        /// <summary>
        ///  Id of the person doing the posting.
        /// </summary>
        public Guid FollowerId { get; set; }
        /// <summary>
        /// Of current location of traveler.
        /// </summary>
        public double Latitude { get; set; }
        
        public double Longitude { get; set; }
        /// <summary>
        ///  Number regular seats requested. 0 all seats if cancelling.
        /// </summary>
        public int RegSeats { get; set; }
        /// <summary>
        ///  Number handicapped seats requested.0 all seats if cancelling.
        /// </summary>
        public int HcapSeats { get; set; }


        public override string ToString()
        {
            string k;
            k = "Id: " + this.Id
             + "FollowerId: " + this.FollowerId
             + "GroupId: " + this.GroupId

             + "Latitude: " + this.Latitude
             + "Longitude: " + this.Longitude
             + "RegSeats: " + this.RegSeats
             + "HcapSeats: " + this.HcapSeats;
           
            return k;
        }

    }
}
