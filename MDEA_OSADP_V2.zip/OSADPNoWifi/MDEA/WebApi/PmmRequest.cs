﻿using CITOMobileCommon.J2735.Ext;
using CITOMobileCommon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication.WebApi
{
    /// <summary>
    /// Many of the fields are nullable because only a subset of the fields required for "new" pmms are also required for "updates"
    /// </summary>
    public class PmmRequest
    {
        /// <summary>
        /// Unique RowId integer Assigned by database when row added to cloud.
        /// </summary>
        public int? Id { get; set; }
        public Guid GroupIdent { get; set; }
        public int RequestId { get; set; }
        public DateTime RequestDate { get; set; }
        public DateTime? PickupDate { get; set; }
        public int Status { get; set; }//note: pmmManager has "new" and "updated" dedicated functions and sets the message status by the function, so this field is not really used.
        public double? PickupLatitude { get; set; }
        public double? PickupLongitude { get; set; }
        public double? Elevation { get; set; }
        public double? PosAccuracy { get; set; }
        public double? DestLatitude { get; set; }
        public double? DestLongitude { get; set; }

        public int? ModeofTransport { get; set; }
        public int RegularSeats { get; set; }
        public int HandicappedSeats { get; set; }

        public override string ToString()
        {
            string k;
            k = ((Id != null) ? "Id: " + this.Id : "")
             + "GroupIdent: " + this.GroupIdent
             + "RegularSeats: " + this.RegularSeats
             + "HandicappedSeats: " + this.HandicappedSeats
             + "RequestId: " + this.RequestId
             + "Status: " + this.Status
             + ((DestLatitude != null) ? "DestLatitude: " + this.DestLatitude : "")
             + ((DestLongitude != null) ? "DestLongitude: " + this.DestLongitude : "")
             + ((ModeofTransport != null) ? "ModeofTransport: " + this.ModeofTransport : "")
             + ((PickupDate != null) ? "PickupDate: " + this.PickupDate : "")
             + ((PickupLatitude != null) ? "PickupLatitude: " + this.PickupLatitude : "")
             + ((PickupLongitude != null) ? "PickupLongitude: " + this.PickupLongitude : "");
            return k;
        }

        public PmmRequest()
        {

        }
        /// <summary>
        /// First Pmm Request for travel group
        /// </summary>
        /// <param name="destinationLoc"></param>
        /// <param name="pickupLoc"></param>
        /// <param name="pickupDateTime"></param>
        /// <param name="regularSeats"></param>
        /// <param name="handicappedSeats"></param>
        public PmmRequest( Coordinates destinationLoc, Coordinates pickupLoc, DateTime pickupDateTime,
            int regularSeats, int handicappedSeats, ModeOfTransportType modeOfTransport)
        {
            RequestId = 1;
           GroupIdent = new Guid();  //Make zeros. Group Id is now assigned by the cloud at a later point in the process. (but before the request is sent)
            PickupLatitude = pickupLoc.Latitude;
            PickupLongitude = pickupLoc.Longitude;
            Elevation = pickupLoc.Altitude;
            PosAccuracy = pickupLoc.Accuracy;

            RequestDate = DateTime.UtcNow;
            PickupDate = pickupDateTime;
            RegularSeats = regularSeats;
            HandicappedSeats = handicappedSeats;
            DestLatitude = destinationLoc.Latitude;
            DestLongitude = destinationLoc.Longitude;
            //We don't currently save destination elevation. It is selected on a map (x/y only).

            ModeofTransport = (int)modeOfTransport;
            Status = 0;  //? this is an int in the db, but maps to an enum, and we send the string over dsrc. can/should we make this cleaner? (true for all the enums).
        }
        /// <summary>
        /// Pmm Updates only change the seat counts.
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="regularSeats"></param>
        /// <param name="handicappedSeats"></param>
        public PmmRequest(int requestId,
    int regularSeats, int handicappedSeats, PmmRequest originalRequest)
        {
            RequestId = requestId;

            RequestDate = DateTime.UtcNow;
            RegularSeats = regularSeats;
            HandicappedSeats = handicappedSeats;
            Status = 1;

            //the rest of the fields are sent identically to the first request (not edited on subsequent requests).
            //They must be included, because if people join right away, we could already be on request 2 by the time we hit the cloud and
            //the acceptor will still need the pickup information.
            GroupIdent = originalRequest.GroupIdent;
            PickupLatitude = originalRequest.PickupLatitude;
            PickupLongitude = originalRequest.PickupLongitude;
            PickupDate = originalRequest.PickupDate;
            DestLatitude = originalRequest.DestLatitude;
            DestLongitude = originalRequest.DestLongitude;
            Elevation = originalRequest.Elevation;
            PosAccuracy = originalRequest.PosAccuracy;
            ModeofTransport = originalRequest.ModeofTransport;
        }


    }
}
