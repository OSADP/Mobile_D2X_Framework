﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication.WebApi
{
    /// <summary>
    /// LeaderUpdates are uploaded by the leader as a result of DSRC information obtained from the leader regarding the group status.
    /// </summary>
    public class LeaderUpdate
    {
        /// <summary>
        /// Id: database assigned unique identifier per row.  
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Time of udpate.
        /// </summary>
        public DateTime Time { get; set; }
        /// <summary>
        /// GroupId assigned to traveler's travel request.
        /// </summary>
        public Guid GroupId { get; set; }
        /// <summary>
        ///  nullable Guid.  The Guid of the follower if the message specific to one follower. If null, message is relevant to all members of GroupId.
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public Guid? FollowerId { get; set; }
        /// <summary>
        /// Update to follower(s).
        /// </summary>
        [StringLength(150)]
        public string Message { get; set; }

        public override string ToString()
        {
            string k;
            k = "Id: " + this.Id
              + ((FollowerId != null) ? "FollowerId: " + this.FollowerId : "")
             + "GroupId: " + this.GroupId

             + "Message: " + this.Message;


            return k;
        }
    }
}
