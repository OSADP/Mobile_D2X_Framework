﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication.WebApi
{
    public class PmmStatusResponse
    {
        public int Id { get; set; }
        public int PmmRequestId { get; set; }
        public object VehicleIdent { get; set; }
        public string ResponseDate { get; set; }
        public int TotalRegSeatsAccptd { get; set; }
        public int TotalHandicapSeatsAccptd { get; set; }
    }
}
