﻿using CITOMobileCommon.DSRC;
using CITOMobileCommon.Logging;
using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace MobileDevicesExperimentalApplication
{
    public partial class SettingsPage : PopupPage
    {
        Dictionary<String, LocomateDevice> LocomateDevices;

        public SettingsPage()
        {
            InitializeComponent();
            LocomateDevices = new Dictionary<string, LocomateDevice>();

            LocomateProvider vp = new LocomateProvider();

            List<LocomateDevice> deviceList = LocomateProvider.ReturnPairedDevices();

            //LocomateDevices.Add("Select Device", null);

            foreach (LocomateDevice locoDevice in deviceList)
            {
                LocomateDevices.Add(locoDevice.DeviceName, locoDevice);
                AradaObuPicker.Items.Add(locoDevice.DeviceName);
            }


            //Set initial selection

            // AradaObuPicker.SelectedIndex = 0;

            if (!String.IsNullOrEmpty(Settings.LocomateDeviceMac))
            {
                String locomateMac = Settings.LocomateDeviceMac;
                SetInitialDevice(locomateMac);

            }

            AradaObuPicker.SelectedIndexChanged += AradaObuPicker_SelectedIndexChanged;

            for (int i = 0; i <= 12; i++)
            {
                WifiDirectTimeoutPicker.Items.Add((i * 5).ToString());
                DsrcTimeoutPicker.Items.Add((i * 5).ToString());
                PersonalRadiusOfProtectionPicker.Items.Add(i.ToString());
            }

            WifiDirectTimeoutPicker.SelectedIndex = Settings.WifiDirectTimeout / 5;

            WifiDirectTimeoutPicker.SelectedIndexChanged += WifiDirectTimeoutPicker_SelectedIndexChanged;

            DsrcTimeoutPicker.SelectedIndex = Settings.DsrcTimeout / 5;

            DsrcTimeoutPicker.SelectedIndexChanged += DsrcTimeoutPicker_SelectedIndexChanged;

            PersonalRadiusOfProtectionPicker.SelectedIndex = Settings.PersonalRadiusOfProtection;

            PersonalRadiusOfProtectionPicker.SelectedIndexChanged += PersonalRadiusOfProtectionPicker_SelectedIndexChanged;

            foreach (InVehicleDetectionSetting type in Enum.GetValues(typeof(InVehicleDetectionSetting)))
            {
                InVehicleDetectionPicker.Items.Add(type.ToString());
            }
            InVehicleDetectionPicker.SelectedIndex = (int)Settings.InVehicleDetection;
            InVehicleDetectionPicker.SelectedIndexChanged += InVehicleDetectionPicker_SelectedIndexChanged;

            foreach (SafetyDetectionSetting type in Enum.GetValues(typeof(SafetyDetectionSetting)))
            {
                SafetyDetectionPicker.Items.Add(type.ToString());
            }
            SafetyDetectionPicker.SelectedIndex = (int)Settings.SafetyDetection;
            SafetyDetectionPicker.SelectedIndexChanged += SafetyDetectionPicker_SelectedIndexChanged;

            foreach (SendPsmSetting type in Enum.GetValues(typeof(SendPsmSetting)))
            {
                SendPsmPicker.Items.Add(type.ToString());
            }
            SendPsmPicker.SelectedIndex = (int)Settings.SendPsm;
            SendPsmPicker.SelectedIndexChanged += SendPsmPicker_SelectedIndexChanged;

            LocationLogEarthSwitch.IsToggled = Settings.LogLocationEarth;
            LocationLogEarthSwitch.Toggled += LogLocationEarth_Toggled;

            DisplayStatusMessagesSwitch.IsToggled = Settings.DisplayStatusMessages;
            DisplayStatusMessagesSwitch.Toggled += DisplayStatusMessagesSwitch_Toggled;

            SimulatedLocationSwitch.IsToggled = Settings.SimulatedLocation;
            SimulatedLocationSwitch.Toggled += SimulatedLocationSwitch_Toggled;

            SimulatedLatitudeEntry.Text = string.Format("{0:0.########}", Settings.SimulatedLatitude);
            SimulatedLongitudeEntry.Text = string.Format("{0:0.########}", Settings.SimulatedLongitude);
            if (SimulatedLocationSwitch.IsToggled)
            {
                SimulatedLatitudeEntry.IsEnabled = false;
                SimulatedLongitudeEntry.IsEnabled = false;
            }
            else
            {
                SimulatedLatitudeEntry.IsEnabled = true;
                SimulatedLongitudeEntry.IsEnabled = true;
            }


            SimulatedPathSwitch.IsToggled = Settings.SimulatedPath;
            SimulatedPathSwitch.Toggled += SimulatedPathSwitch_Toggled;

            SimulatedPathDurationEntry.Text = Settings.SimulatedPathDuration.ToString();
            SimulatedEndLatitudeEntry.Text = string.Format("{0:0.########}", Settings.SimulatedEndLatitude);
            SimulatedEndLongitudeEntry.Text = string.Format("{0:0.########}", Settings.SimulatedEndLongitude);
            if (SimulatedPathSwitch.IsToggled)
            {
                SimulatedPathDurationEntry.IsEnabled = false;
                SimulatedEndLatitudeEntry.IsEnabled = false;
                SimulatedEndLongitudeEntry.IsEnabled = false;
            }
            else
            {
                SimulatedPathDurationEntry.IsEnabled = true;
                SimulatedEndLatitudeEntry.IsEnabled = true;
                SimulatedEndLongitudeEntry.IsEnabled = true;
            }
        }

        private void DsrcTimeoutPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DsrcTimeoutPicker.SelectedIndex != -1)
            {
                string oldValue = Settings.DsrcTimeout.ToString();
                Settings.DsrcTimeout = DsrcTimeoutPicker.SelectedIndex * 5;
                string newValue = Settings.DsrcTimeout.ToString();
                LogSettingChanged("DsrcTimeout", oldValue, newValue);
            }
        }

        private void WifiDirectTimeoutPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (WifiDirectTimeoutPicker.SelectedIndex != -1)
            {
                string oldValue = Settings.WifiDirectTimeout.ToString();
                Settings.WifiDirectTimeout = WifiDirectTimeoutPicker.SelectedIndex * 5;
                string newValue = Settings.WifiDirectTimeout.ToString();
                LogSettingChanged("WifiDirectTimeout", oldValue, newValue);
            }
        }

        private void PersonalRadiusOfProtectionPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (PersonalRadiusOfProtectionPicker.SelectedIndex != -1)
            {
                string oldValue = Settings.PersonalRadiusOfProtection.ToString();
                Settings.PersonalRadiusOfProtection = PersonalRadiusOfProtectionPicker.SelectedIndex;
                string newValue = Settings.PersonalRadiusOfProtection.ToString();
                LogSettingChanged("PersonalRadiusOfProtection", oldValue, newValue);
            }
        }

        private void InVehicleDetectionPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (InVehicleDetectionPicker.SelectedIndex != -1)
            {
                string oldValue = Settings.InVehicleDetection.ToString();
                Settings.InVehicleDetection = (InVehicleDetectionSetting)InVehicleDetectionPicker.SelectedIndex;
                string newValue = Settings.InVehicleDetection.ToString();
                LogSettingChanged("InVehicleDetection", oldValue, newValue);
            }
        }
        private void SafetyDetectionPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SafetyDetectionPicker.SelectedIndex != -1)
            {
                string oldValue = Settings.SafetyDetection.ToString();
                Settings.SafetyDetection = (SafetyDetectionSetting)SafetyDetectionPicker.SelectedIndex;
                string newValue = Settings.SafetyDetection.ToString();
                LogSettingChanged("SafetyDetection", oldValue, newValue);
            }
        }
        private void SendPsmPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SendPsmPicker.SelectedIndex != -1)
            {
                string oldValue = Settings.SendPsm.ToString();
                

                Settings.SendPsm = (SendPsmSetting)SendPsmPicker.SelectedIndex;

                string newValue = Settings.SendPsm.ToString();
                LogSettingChanged("SendPsm", oldValue, newValue);
            }
        }
        private void LogLocationEarth_Toggled(object sender, EventArgs e)
        {
            string oldValue = Settings.LogLocationEarth.ToString();
            Settings.LogLocationEarth = this.LocationLogEarthSwitch.IsToggled;
            string newValue = Settings.LogLocationEarth.ToString();
            LogSettingChanged("LogLocationEarth", oldValue, newValue);
        }
        private void DisplayStatusMessagesSwitch_Toggled(object sender, EventArgs e)
        {
            string oldValue = Settings.DisplayStatusMessages.ToString();
            Settings.DisplayStatusMessages = DisplayStatusMessagesSwitch.IsToggled;
            string newValue = Settings.DisplayStatusMessages.ToString();
            LogSettingChanged("DisplayStatusMessages", oldValue, newValue);
        }

        private void LogSettingChanged(string setting, string oldValue, string newValue)
        {
            string v = "Setting Changed: " + setting + " Old = " + oldValue + " New = " + newValue;
            DbLogger.Instance().Debug(v);
        }

        private void SimulatedLocationSwitch_Toggled(object sender, EventArgs e)
        {
            double coord;
            if (SimulatedLocationSwitch.IsToggled)
            {
                try
                {
                    coord = Convert.ToDouble(SimulatedLatitudeEntry.Text);
                    if (coord >= -90 && coord <= 90)
                    {
                        SimulatedLatitudeEntry.TextColor = Color.Black;
                        Settings.SimulatedLatitude = coord;
                    }
                    else
                    {
                        SimulatedLatitudeEntry.TextColor = Color.Red;
                        SimulatedLocationSwitch.IsToggled = false;
                    }
                }
                catch
                {
                    SimulatedLatitudeEntry.TextColor = Color.Red;
                    SimulatedLocationSwitch.IsToggled = false;
                }

                try
                {
                    coord = Convert.ToDouble(SimulatedLongitudeEntry.Text);
                    if (coord >= -180 && coord <= 180)
                    {
                        SimulatedLongitudeEntry.TextColor = Color.Black;
                        Settings.SimulatedLongitude = coord;
                    }
                    else
                    {
                        SimulatedLongitudeEntry.TextColor = Color.Red;
                        SimulatedLocationSwitch.IsToggled = false;
                    }
                }
                catch
                {
                    SimulatedLongitudeEntry.TextColor = Color.Red;
                    SimulatedLocationSwitch.IsToggled = false;
                }
                

                if (SimulatedLocationSwitch.IsToggled)
                {
                    SimulatedLatitudeEntry.IsEnabled = false;
                    SimulatedLongitudeEntry.IsEnabled = false;
                }

            }
            else
            {
                SimulatedLatitudeEntry.IsEnabled = true;
                SimulatedLongitudeEntry.IsEnabled = true;
            }

            string oldValue = Settings.SimulatedLocation.ToString();
            Settings.SimulatedLocation = SimulatedLocationSwitch.IsToggled;
            string newValue = Settings.SimulatedLocation.ToString();
            LogSettingChanged("SimulatedLocation", oldValue, newValue);
        }

        private void SimulatedPathSwitch_Toggled(object sender, EventArgs e)
        {
            double coord;
            Int32 duration;
            if (SimulatedPathSwitch.IsToggled)
            {
                try
                {
                    duration = Convert.ToInt32(SimulatedPathDurationEntry.Text);
                    if (duration > 0 && duration < 10000)
                    {
                        SimulatedPathDurationEntry.TextColor = Color.Black;
                        Settings.SimulatedPathDuration = duration;
                    }
                    else
                    {
                        SimulatedPathDurationEntry.TextColor = Color.Red;
                        SimulatedPathSwitch.IsToggled = false;
                    }
                }
                catch
                {
                    SimulatedPathDurationEntry.TextColor = Color.Red;
                    SimulatedPathSwitch.IsToggled = false;
                }

                try
                {
                    coord = Convert.ToDouble(SimulatedEndLatitudeEntry.Text);
                    if (coord >= -90 && coord <= 90)
                    {
                        SimulatedEndLatitudeEntry.TextColor = Color.Black;
                        Settings.SimulatedEndLatitude = coord;
                    }
                    else
                    {
                        SimulatedEndLatitudeEntry.TextColor = Color.Red;
                        SimulatedPathSwitch.IsToggled = false;
                    }
                }
                catch
                {
                    SimulatedEndLatitudeEntry.TextColor = Color.Red;
                    SimulatedPathSwitch.IsToggled = false;
                }

                try
                {
                    coord = Convert.ToDouble(SimulatedEndLongitudeEntry.Text);
                    if (coord >= -180 && coord <= 180)
                    {
                        SimulatedEndLongitudeEntry.TextColor = Color.Black;
                        Settings.SimulatedEndLongitude = coord;
                    }
                    else
                    {
                        SimulatedEndLongitudeEntry.TextColor = Color.Red;
                        SimulatedPathSwitch.IsToggled = false;
                    }
                }
                catch
                {
                    SimulatedEndLongitudeEntry.TextColor = Color.Red;
                    SimulatedPathSwitch.IsToggled = false;
                }

                if (SimulatedPathSwitch.IsToggled)
                {
                    SimulatedPathDurationEntry.IsEnabled = false;
                    SimulatedEndLatitudeEntry.IsEnabled = false;
                    SimulatedEndLongitudeEntry.IsEnabled = false;
                }

            }
            else
            {
                SimulatedPathDurationEntry.IsEnabled = true;
                SimulatedEndLatitudeEntry.IsEnabled = true;
                SimulatedEndLongitudeEntry.IsEnabled = true;
            }

            string oldValue = Settings.SimulatedPath.ToString();
            Settings.SimulatedPath = SimulatedPathSwitch.IsToggled;
            string newValue = Settings.SimulatedPath.ToString();
            LogSettingChanged("SimulatedPathI am ", oldValue, newValue);
        }

        private async void CloseButton_Clicked(object sender, EventArgs e)
        {
            await PopupNavigation.PopAsync();
        }

        private void SetInitialDevice(String locomateMac)
        {
            String selectedDeviceName = "";
            foreach (string deviceName in LocomateDevices.Keys)
            {
                LocomateDevice locoDevice = LocomateDevices[deviceName];
                if (locoDevice.MacAddress == locomateMac)
                {
                    selectedDeviceName = locoDevice.DeviceName;
                }
            }

            if (!String.IsNullOrEmpty(selectedDeviceName))
            {
                for (int i = 0; i < AradaObuPicker.Items.Count; i++)
                {
                    if (AradaObuPicker.Items[i] == selectedDeviceName)
                    {
                        AradaObuPicker.SelectedIndex = i;
                    }
                }
            }
        }

        private void AradaObuPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (AradaObuPicker.SelectedIndex == -1)// || AradaObuPicker.SelectedIndex ==0)
            {
                Settings.LocomateDeviceMac = "";
            }
            else
            {
                LocomateDevice locoDevice = LocomateDevices[AradaObuPicker.Items[AradaObuPicker.SelectedIndex]];
                Settings.LocomateDeviceMac = locoDevice.MacAddress;
            }
        }
    }
}
