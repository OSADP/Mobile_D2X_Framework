﻿using CITOMobileCommon;
using CITOMobileCommon.Data;
using CITOMobileCommon.Geo;
using CITOMobileCommon.J2735.R41;
using CITOMobileCommon.Logging;
using CITOMobileCommon.Maps;
using CITOMobileCommon.Models;
using CITOMobileCommon.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MobileDevicesExperimentalApplication
{
    public class SafetyMon
    {
        public enum PedestrianSafetyStatusEnum
        {
            PED_SAFETY_NONE,
            PED_SAFETY_ADVISORY,
            PED_SAFETY_ALERT,
            PED_SAFETY_WARNING

        }
        public bool AmIInAVehicle { get; set; }
        private ActivityDetection.ActivityDetectionType _lastDetectedActivty;
        private bool _amIUnsafe;
        public bool AmIUnsafe
        {
            get
            {
                return _amIUnsafe;
            }
            set
            {
                _amIUnsafe = value;
                //UpdateTransmitPsm();
            }
        }

        public bool AmIInGroup { get; set; }
        public bool AmIGroupLeader { get; set; }




        private LocomateConnectionManager LocomateConnectionMgr;
        private CancellationToken CancelToken;
        private CancellationTokenSource CancelTokenSrc;
        private BeaconMon BeaconMonitor;

        private DsrcSettings ObuSettings;
        private Object ObuSettingsLock;
        private DateTime MostRecentLocationMsgTime;

       // private bool MostRecentShouldTransmitPSM;

        private Location CurrentLocation;
        private bool ShouldIContinueMonitoring;

        public SafetyMon(bool amIInVehicle, bool amIUnsafe, bool amIInGroup, bool amIGroupLeader,
            LocomateConnectionManager connectionMgr, BeaconMon beaconMonitor, DsrcSettings obuSettings, object obuSettingsLock)
        {
            AmIInAVehicle = amIInVehicle;
            AmIUnsafe = amIUnsafe;
            AmIInGroup = amIInGroup;
            AmIGroupLeader = amIGroupLeader;

          //  MostRecentShouldTransmitPSM = false;

            LocomateConnectionMgr = connectionMgr;
            ObuSettings = obuSettings;
            ObuSettingsLock = obuSettingsLock;
            BeaconMonitor = beaconMonitor;
        }

        public void StartMonitoring()
        {
            ShouldIContinueMonitoring = true;
            Device.StartTimer(TimeSpan.FromSeconds(1), () => {

                UpdateTransmitPsm();
                return ShouldIContinueMonitoring;
            });
        }

        public void StopMonitoring()
        {
            ShouldIContinueMonitoring = false;
        }

        public void SendCurrentObuSettings()
        {
            DsrcSettings settings;
            lock(ObuSettingsLock)
            {
                settings = ObuSettings;
            }
            DbLogger.Instance().Debug("Dsrc: Tx: SendPsm: " + settings.SendPsm + " (SendPmm:" + settings.SendPmm +")");
            LocomateConnectionMgr.SendJsonData(settings);
        }


        /// <summary>
        /// Should get triggered when a new gps location has been updated (~ once a second)
        /// </summary>
        public void LocationUpdated(Location location)
        {
            CurrentLocation = location;
        }

        /// <summary>
        /// Returns true if we are in vehicle (AmIInAVehicle). Also accounts for overridden settings.
        /// </summary>
        /// <param name="activityType"></param>
        public bool ActivityDetectionUpdated(ActivityDetection activityType)
        {

            //TODO: Technically, if the setting is set to anything other than "use activity lib" then we really
            //should react to that settings change and turn off the activity recognition updates so that this 
            //funtion never fires.?


            //The ActivityRecognition library does not appear to be to awesome yet, we get
            //'tilting' a lot of the time, and 'still' when you stop walking or driving.
            //Lets only change if onfoot or vehicle occurs. Anything else, keep with the last of
            //either onfoot or vehicle.
            if (activityType.MostPrbActivity == ActivityDetection.ActivityDetectionType.OnFoot
                || activityType.MostPrbActivity == ActivityDetection.ActivityDetectionType.Walking//these two show up interchangeably.
               || activityType.MostPrbActivity == ActivityDetection.ActivityDetectionType.Running)  //and lets throw in Running too just cuz.
            {
                //Set to walking
                _lastDetectedActivty = ActivityDetection.ActivityDetectionType.OnFoot;
                return false;
            }
            else if (activityType.MostPrbActivity == ActivityDetection.ActivityDetectionType.InVehicle)
            {
                //Set to in Vehicle
                _lastDetectedActivty = ActivityDetection.ActivityDetectionType.InVehicle;
                return true;
            }
            return false;
        }
        /// <summary>
        /// We need consistent speed readings to trigger a change in InVehicle.
        /// 3 provides stable results with a delay of 5 - 6 seconds.
        /// 2 provides delay of 3-4 seconds, however, introducing false readings when in vehicle in stop and go conditions.
        /// </summary>
        const int NumSpeedsToFilter = 3;
        private List<double> _speeds = new List<double>();
        private void UpdateTransmitPsm()
        {
            if (CurrentLocation == null)
                return;

            //Check user setting to determine how to set InAVehicle
            //See if user has overridden the value to be fixed true or false.
            if (Settings.InVehicleDetection == InVehicleDetectionSetting.In) AmIInAVehicle = true;
            else if (Settings.InVehicleDetection == InVehicleDetectionSetting.NotIn) AmIInAVehicle = false;
            //or see which algorithm we should use.
            else if (Settings.InVehicleDetection == InVehicleDetectionSetting.UseGps)
            {
                SetAmIInAVehicleBasedOnGps(CurrentLocation);

            }
            else if (Settings.InVehicleDetection == InVehicleDetectionSetting.UseActivityLib)
            {
                //use DetectedActivity android api value (updated through callbacks)
                if (_lastDetectedActivty == ActivityDetection.ActivityDetectionType.InVehicle) AmIInAVehicle = true;
                else AmIInAVehicle = false;

            }
            else if (Settings.InVehicleDetection == InVehicleDetectionSetting.UseBeacon)
            {
                //use bluetooth beacon
                if (BeaconMonitor.InVehicle)
                    AmIInAVehicle = true;
                else
                    AmIInAVehicle = false;

            }

            //Check user setting to determine how to set AmISafe
            //See if user has overridden the value to be fixed true or false.
            if (Settings.SafetyDetection == SafetyDetectionSetting.UnsafeZone) AmIUnsafe = true;
            else if (Settings.SafetyDetection == SafetyDetectionSetting.NotUnsafeZone) AmIUnsafe = false;
            else
            {
                //Latest map is loaded as the bsm's are recieved. Parsed if new.
                //See if current location is in a vehicle lane
                MapSupport mapSup = new MapSupport();
                Coordinates coord = new Coordinates(CurrentLocation.LocationMessage.Latitude, CurrentLocation.LocationMessage.Longitude);
                MapMatchResult res = mapSup.FindVehicleLaneForPoint(coord, latestMap);
                if (res.IsInLane)
                {
                    //Current location of pedestrian is IN a vehicle lane, and thus is not safe.
                    AmIUnsafe = true;
                }
                else AmIUnsafe = false;
            }

            string trackPsmDec = "";//We need to track which thing changed psm.
            if (Settings.SendPsm == SendPsmSetting.AlwaysSend) doTransmitPsm = true;
            else if (Settings.SendPsm == SendPsmSetting.NeverSend) doTransmitPsm = false;
            else
            {
                //update doTransmitPsm via real functionality
                /// 
                /// To accomodate poorly written requirement FR 1.06, we need a user configurable property to turn
                /// on/off during demo.  Supressing psms in the safe zone trumps all the other rules - like followers not 
                /// sending psms, so we need to be able to turn off this req to demo those features.
                /// There are ATP tests that test conflicting logic, so this allows us to do both.
                ///
               // bool ignoreSafeZoneRule = (Settings.SendPsm == SendPsmSetting.IgnoreSafeZoneRule);
                doTransmitPsm =
                    TestAllCasesForPsm(out trackPsmDec);
                DbLogger.Instance().Debug("Psm Dec Track: " + trackPsmDec);
            }

            ClearBsmRecs(); //clear for next cycle

            StatusEventArgs statusArgs = new StatusEventArgs(StatusType.SENDPSM, doTransmitPsm.ToString() +","+trackPsmDec);
            DebugStatus.SendDebugStatus(this, statusArgs);

            DsrcSettings settings;
            lock (ObuSettingsLock)
            {
                settings = ObuSettings;
            }
            //Update setting that gets sent to the radio
            if (settings.SendPsm != doTransmitPsm)
            {
                lock (ObuSettingsLock)
                {
                    ObuSettings.SendPsm = doTransmitPsm;
                }
                SendCurrentObuSettings();
            }
        }

        private void SetAmIInAVehicleBasedOnGps(Location location)
        {

            //Make a queue
            _speeds.Insert(0, location.LocationMessage.Speed);
            if (_speeds.Count > NumSpeedsToFilter) _speeds.RemoveAt(NumSpeedsToFilter);
            else
            {
                //We haven't accrued X samples yet, just guess based on this one. Chances are it will be 0 anyway if the app is launching.
                if (location.LocationMessage.Speed >= 2) AmIInAVehicle = true;
                else { AmIInAVehicle = false; }
            }

            //All 5 samples must be in either walking or driving for us to change our minds.
            //Zero can't be used, because both can be still.
            int drivCnt = 0;
            int walkCnt = 0;
            foreach (double s in _speeds)
            {
                if (s <= 0.1)
                {
                    //Not moving. unknown.
                }
                //Average walking speed is 1.4m/s.  Max Speed walking is 2.5 m/s. My personal max i saw was 1.7 and that was a pretty fast walk.
                //Getting some false 'walkings' in slow car with 1.7, lets try 1.6. runners will false to invehicle though.
                else if (s > 0.1 && s < 1.6)
                {
                    //Walking speed
                    walkCnt++;
                }
                else
                {
                    //Driving
                    drivCnt++;
                }
            }
            if (walkCnt == NumSpeedsToFilter)
            {
                //All were walking. Set to walking.
                AmIInAVehicle = false;
            }
            else if (drivCnt == NumSpeedsToFilter)
            {
                //All were driving. Set to in vehicle.
                AmIInAVehicle = true;
            }

        }

        private bool doTransmitPsm { get; set; }
        private bool ShouldTransmitPsm()
        {
            return doTransmitPsm;
        }

        /// <summary>
        /// Once all the prep work for psm factors (am i in vehicle, am i unsafe, etc) is done, this function runs
        /// all the cases and determines if we should send a psm
        /// </summary>
        /// <returns></returns>
        private bool TestAllCasesForPsm(out string psmDecisionTracker)
        {
            bool sendPsms = true;
            psmDecisionTracker = "";

            if (AmIInAVehicle)
            {
                //When in a vehicle, we do not transmit PSMs
                sendPsms = false;
                psmDecisionTracker += "a";
                return sendPsms;
            }

            if (AmIInGroup)
            {
                //Only the leader transmits Psms
                if (!AmIGroupLeader)
                {
                    sendPsms = false;
                    psmDecisionTracker += "b";
                }
            }

            if (AmIUnsafe)
            {
                //Exception to "leader only transmits psm" rule - if unsafe, we transmit psm.
                sendPsms = true;
                psmDecisionTracker += "c";
            }
            //if (!ignoreSafeZoneRule)//this requirement trumps the above logic.  Consider it a 'mode' and only check if user has said so.
            //{
            //    if (!AmIUnsafe)
            //    {
            //        //We are safe. Don't transmit psm.
            //        sendPsms = false;
            //        psmDecisionTracker += "d";
            //    }
            //}
            if (sendPsms)
            {
                //If there are no cars around, we don't transmit a PSM.
                //Or if the vehicle is too far, we don't transmit a PSM.

                /*FR 1.08	PSM Transmit Timing	Mobile devices shall transmit PSMs only when the mobile device determines a vehicle
                is within a specified radius of the mobile device. The specified radius is dependent on the vehicle’s speed. The 
                radius calculation is the same as the advisory display distance, explained in Appendix C of Req doc.
                Note: This is in accordance with the J2945-9, Clause 6.3.3 standard.
                */

                //Iterate over each of the bsms received this cycle (calculations done elsewhere for safety warnings).
                bool carInRange = false;
                foreach (NearbyBsms nb in rcvdBsms)
                {
                    if (nb.DistanceApart < nb.AdvisoryDistBasedOnSpeed)
                    {
                        DbLogger.Instance().Debug("IsBsmClose: Dist: " + nb.DistanceApart + "<? AdvDist: "+nb.AdvisoryDistBasedOnSpeed);
                        //This BSM is close enough to the ped.
                        carInRange = true;
                        psmDecisionTracker += "e";
                        break; //one car close enough is all we need to send psm
                    }
                }
                sendPsms = carInRange;
                psmDecisionTracker += rcvdBsms.Count + "f";
            }

            return sendPsms;
        }

        private string uniqueMapId = "";
        private string mapRevision = "";
        private ParsedMap latestMap = new ParsedMap();
        private List<NearbyBsms> rcvdBsms = new List<NearbyBsms>();
        /// <summary>
        /// One of the determining factors of whether we send Psms or not is whether there are any cars around, and whether
        /// the car is 'close enough'.  Close enough is determined by the distance and speed of the car.
        /// </summary>
        public class NearbyBsms
        {
            public DateTime Rcvd { get; set; }
            /// <summary>
            /// Based on the location of the bsm, and the current location of pedestrian, the distance between the two. in meters
            /// </summary>
            public double DistanceApart { get; set; }
            /// <summary>
            /// Based on the speed of the car from the bsm, the minimum advisory distance from the algorithm  D = v*9
            /// </summary>
            public double AdvisoryDistBasedOnSpeed { get; set; }
        }
        /// <summary>
        /// Saves data from a received BSM so that it can be evaluated for contributing to sending out psms.
        /// </summary>
        /// <param name="distanceInM"></param>
        /// <param name="advisoryDistanceBasedOnSpeedInM"></param>
        public void AddBsmRec(double distanceInM, double advisoryDistanceBasedOnSpeedInM)
        {
            rcvdBsms.Add(new NearbyBsms()
            {
                Rcvd = DateTime.Now,
                DistanceApart = distanceInM,
                AdvisoryDistBasedOnSpeed = advisoryDistanceBasedOnSpeedInM
            });
        }
        /// <summary>
        ///             //Since we check once a second, and bsms are sent 10/second, we are assuming that if a car was in range,
        //that we will hear from it at least once each cycle - so we can clear this list each time and start fresh.
        //(Timestamp saved in case this assumption is wrong and needs to become more complex).
        /// </summary>
        public void ClearBsmRecs()
        {
            rcvdBsms.Clear();
        }

        public void LoadMap(MAP_P map)
        {
            //See if this map is new to us based on ID and revision.
            string newUniqueMapId = map.ToString();
            //  string newMapRevision = map.MapData.roadSegments[0].revision;
            string newMapRevision = map.MapData.msgIssueRevision;


            if (uniqueMapId != newUniqueMapId )//|| mapRevision != newMapRevision) //take out revision since it keeps changing for some reason.
            {
                uniqueMapId = map.ToString();
               // mapRevision = map.MapData.roadSegments[0].revision;
                mapRevision = map.MapData.msgIssueRevision;

                //For demo, we Assume map is roadway map (not intersection) and has only one roadway Set.
              //  latestMap.LoadMapLanes(map.MapData.roadSegments[0].refPoint,
              //      map.MapData.roadSegments[0].roadLaneSet, map.MapData.roadSegments[0].laneWidth);
                latestMap.LoadMapLanes(map.MapData.intersections[0].refPoint,
                     map.MapData.intersections[0].laneSet, map.MapData.intersections[0].laneWidth);

                if (Settings.LogLocationEarth)
                {
                    //Output in csv Lat,Long,Type,LaneNumber,Region (ETRP format to use same Google Earth Plotter tool)
                    string mapearth = latestMap.MapToString();

                    DbLogger.Instance().Debug("Map: " + mapRevision +" " + mapearth);
                }
            }
        }
        public PedestrianSafetyStatusEnum MonitorPedestrianSafety(BSM_BasicSafetyMessage bsm, CITOMobileCommon.Models.Coordinates location)
        {
            double bsmLatitude = bsm.Latitude;
            double bsmLongitude = bsm.Longitude;
            Coordinates bsmCoordinates = new Coordinates(bsmLatitude, bsmLongitude);
            double bsmHeading = bsm.Heading;
            double bsmSpeed_mps = Conversions.ConvertMilesPerHourToMetersPerSec(bsm.Speed_mph);

            double psmLatitude = location.Latitude;
            double psmLongitude = location.Longitude;
            double psmHeading = location.Heading;
            double psmSpeed_mps = location.Speed;


            double crossTrackDistanceUsingBearing = GeoVector.CrossTrackDistanceInMeters(location, bsmCoordinates, bsmHeading);
            double psmRadiusOfProtectionInMeters = Settings.PersonalRadiusOfProtection;
            bool pedestrianInPath = false;

            //check if path of vehicle is inside radius of protection
            if (crossTrackDistanceUsingBearing <= psmRadiusOfProtectionInMeters && crossTrackDistanceUsingBearing >= -psmRadiusOfProtectionInMeters)
                pedestrianInPath = true;
            else
                pedestrianInPath = false;

            //calculate angle between vehicle path and path from vehicle to pedestrian
            //if this angle is > 90 or < -90 vehicle is moving away from pedestrian
            double pathToPedestrianAngleUsingBearing = GeoVector.AngleBetweenPathsInDegrees(bsmCoordinates, bsmHeading,
                    bsmCoordinates, location);

            bool pedestrianInFrontOfVehicle = false;
            //check if pedestrian is in front of vehicle
            if (pathToPedestrianAngleUsingBearing <= 90.0 && pathToPedestrianAngleUsingBearing >= -90.0)
                pedestrianInFrontOfVehicle = true;
            else
                pedestrianInFrontOfVehicle = false;

            //calculate intersection of paths
            Coordinates intersectionOfPaths = GeoVector.Intersection(bsmCoordinates, bsmHeading, location, psmHeading);

            //calculate distance pedestrian traveled when vehicle intersects pedestrians path
            double distanceToIntersect = Conversions.DistanceMeters(bsmCoordinates, intersectionOfPaths);
            double timeOfIntersect = distanceToIntersect / bsmSpeed_mps; // in seconds
            double pedestrianDistanceTraveled = psmSpeed_mps * timeOfIntersect;

            // calculate location of pedestrian when vehicle intersects pedestrians path
            Coordinates pedestrianLocAtIntersect = GeoVector.DestinationPoint(location, psmHeading, pedestrianDistanceTraveled);

            // calculate distance between pedestrian and vehicle when vehicle intersects pedestrians path
            double pedestrianDistanceToVehicleAtIntersect = Conversions.DistanceMeters(pedestrianLocAtIntersect, intersectionOfPaths);

            bool predictedPedestrianInPath = false;
            //check if vehicle is in radius of protection when vehicle intersects pedestrian path
            if (pedestrianDistanceToVehicleAtIntersect <= psmRadiusOfProtectionInMeters && pedestrianDistanceToVehicleAtIntersect >= -psmRadiusOfProtectionInMeters)
                predictedPedestrianInPath = true;
            else
                predictedPedestrianInPath = false;

            //calculate distance in meters using vectors
            double pedestrianToVehicleDistanceInMetersUsingVector = Conversions.DistanceMeters(location, bsmCoordinates);

            //calculate distance in meters using conversion library
            double pedestrianToVehicleDistanceInMeters = Conversions.DistanceMeters(location, bsmCoordinates);
            //calculate for advisory , calculation based on formulas in document FHWA-JPO-16-423, Appendix C
            double advisoryDistanceInMeters = bsmSpeed_mps * 9.0;
            AddBsmRec(pedestrianToVehicleDistanceInMeters, advisoryDistanceInMeters);//Save for 'doTransmitPsm' calculations.

            //check for warning, calculation based on formulas in document FHWA-JPO-16-423, Appendix C
            double warningDistanceInMeters = 1.1 * (((0.5 + 2.5) * bsmSpeed_mps) + ((bsmSpeed_mps * bsmSpeed_mps) / (2.0 * 5.6)));
            if (pedestrianToVehicleDistanceInMeters <= warningDistanceInMeters)
            {
                if (pedestrianInFrontOfVehicle && (pedestrianInPath || predictedPedestrianInPath))
                {
                    DbLogger.Instance().Debug("Sf:Warn: " + pedestrianToVehicleDistanceInMeters + ", " +warningDistanceInMeters);
                    return PedestrianSafetyStatusEnum.PED_SAFETY_WARNING;
                }
            }
            else
            {
                //check for alert, calculation based on formulas in document FHWA-JPO-16-423, Appendix C
                double alertDistanceInMeters = 1.1 * (((0.5 + 2.5) * bsmSpeed_mps) + ((bsmSpeed_mps * bsmSpeed_mps) / (2.0 * 3.4)));
                if (pedestrianToVehicleDistanceInMeters <= alertDistanceInMeters)
                {
                    if (pedestrianInFrontOfVehicle && (pedestrianInPath || predictedPedestrianInPath))
                    {
                        DbLogger.Instance().Debug("Sf:Alert: " + pedestrianToVehicleDistanceInMeters + ", " + alertDistanceInMeters);
                        return PedestrianSafetyStatusEnum.PED_SAFETY_ALERT;
                    }
                }
                else
                {
                    //check for advisory.Calculated above so that we can store the bsm value.
                    if (pedestrianToVehicleDistanceInMeters <= advisoryDistanceInMeters)
                    {
                        if (pedestrianInFrontOfVehicle && (pedestrianInPath || predictedPedestrianInPath))
                        {
                            DbLogger.Instance().Debug("Sf:Adv: " + pedestrianToVehicleDistanceInMeters + ", " + advisoryDistanceInMeters);
                            return PedestrianSafetyStatusEnum.PED_SAFETY_ADVISORY;
                        }
                    }
                }
            }


            return PedestrianSafetyStatusEnum.PED_SAFETY_NONE;
        }
    }
}
