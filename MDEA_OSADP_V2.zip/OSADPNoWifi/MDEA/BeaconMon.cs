﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CITOMobileCommon;
using CITOMobileCommon.Beacon;
using CITOMobileCommon.Data;
using System.Threading;
using Xamarin.Forms;

namespace MobileDevicesExperimentalApplication
{
    public class BeaconMon
    {
        private int _beaconCheckIntervalInSeconds = 7;
        private IBeaconHelper _beaconHelper = DependencyService.Get<IBeaconHelper>();
        private bool _beaconMonitoring = false;
        private bool _beaconScanning = false;
        private string BEACON_LOCK = "BEACON_LOCK";
        private bool _inVehicle = false;

        public bool InVehicle
        {
            get
            {
                return _inVehicle;
            }
        }

        public void StartMonitoring()
        {
            lock(BEACON_LOCK)
            {
                if (_beaconMonitoring)
                    return;
                _beaconMonitoring = true;
            }
            
            //start timer to process beacon
            Device.StartTimer(TimeSpan.FromSeconds(_beaconCheckIntervalInSeconds), () => {
                bool rc;
                ProcessBeacons();
                lock (BEACON_LOCK)
                {
                    rc = _beaconMonitoring;
                }
                return rc;
            });
        }

        public void StopMonitoring()
        {
            lock (BEACON_LOCK)
            {
                if (!_beaconMonitoring)
                    return;
                _beaconMonitoring = false;
            }
        }

        private void ProcessBeacons()
        {
            List<BeaconData> beaconList;
            int i;
            sbyte txPower;
            bool foundInVehicle;
            lock(BEACON_LOCK)
            {
                //get list if we are scanning
                if (_beaconScanning)
                {
                    beaconList = _beaconHelper.GetBeaconList();
                    //check if in vehicle
                    if (beaconList.Count > 0)
                    {
                        foundInVehicle = false;
                        for (i=0;i<beaconList.Count;i++)
                        {
                            if (beaconList[i]._manufacturerData.Length >= 23)
                            {
                                //check rssi against txpower, to determine if within 1 meter power calibration
                                txPower = (sbyte)beaconList[i]._manufacturerData[22];
                                if (beaconList[i]._bestRssi > txPower)
                                {
                                    foundInVehicle = true;
                                }
                            }
                        }
                        if (foundInVehicle)
                        {
                            //beacons found and within range
                            _inVehicle = true;
                        }
                        else
                        {
                            //beacons found but not within range
                            _inVehicle = false;
                        }
                    }
                    else
                    {
                        //no beacons found
                        _inVehicle = false;
                    }
                    //clear list for next scan period
                    _beaconHelper.ClearBeaconList();
                }
                else
                {
                    //if not scanning then cant show in-vehicle
                    _inVehicle = false;
                }
                //check in-vehicle detection setting to see if we should start/stop scanning
                if (Settings.InVehicleDetection == InVehicleDetectionSetting.UseBeacon && _beaconMonitoring)
                {
                    //start beacon scan
                    if (!_beaconScanning)
                    {
                        _beaconHelper.StartScan();
                        _beaconScanning = true;
                    }
                }
                else
                {
                    //stop beacon scan
                    if (_beaconScanning)
                    {
                        _beaconHelper.StopScan();
                        _beaconScanning = false;
                    }
                }
            }
        }

    }

}
