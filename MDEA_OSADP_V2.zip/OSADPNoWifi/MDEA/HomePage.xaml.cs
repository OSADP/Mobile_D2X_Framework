﻿using CITOMobileCommon;
using CITOMobileCommon.Data;
using CITOMobileCommon.J2735;
using CITOMobileCommon.J2735.Ext;
using CITOMobileCommon.J2735.R41;
using CITOMobileCommon.Locations;
using CITOMobileCommon.Logging;
using CITOMobileCommon.Models;
using CITOMobileCommon.Utils;
using MobileDevicesExperimentalApplication.WebApi;
using Newtonsoft.Json;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CITOMobileCommon.TextToSpeech;

using Xamarin.Forms;

namespace MobileDevicesExperimentalApplication
{
    public partial class HomePage : ContentPage
    {
        private static String TAG = "MDEA";

        private object ObuSettingsLock = new object();
        private DsrcSettings ObuSettings;

        private SafetyMon PersonalSafetyMonitor;
        private PersonalMobilityGroupManager PersonalMobilityGroupMgr;
        //private PopupAlert PopupAlertPage;
        private LocomateConnectionManager LocomateConnectionMgr;
        private LocationMonitor LocationMontr;
        private ActivityDetectMonitor ActivityDetectMontr;
        private BeaconMon BeaconMonitor;
        // private TapGestureRecognizer SafeStatusTapGesture;

        private TapGestureRecognizer GroupStatusTapGesture;
        private TapGestureRecognizer CancelTripTapGesture;
        private TapGestureRecognizer ScheduleTripTapGesture;
        private TapGestureRecognizer ScheduleTransitTapGesture;
        private TapGestureRecognizer SettingsTapGesture;
        private TapGestureRecognizer TestAlertTapGesture;

        private Boolean IsSafe;
        private Boolean IsInVehicle;
        private object locationLock = new object();
        private CITOMobileCommon.Models.Coordinates CurrentLocation;
        private CITOMobileCommon.Models.ActivityDetection CurrentActivityDetection;
        private double CurrentDestinationLat;
        private double CurrentDestinationLon;

        private SafetyMon.PedestrianSafetyStatusEnum CurrentSafetyAlert = SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_NONE;
        private ITextToSpeech _textToSpeech = DependencyService.Get<ITextToSpeech>();


        private DateTime LastAlertTime = DateTime.MinValue;
        private CITOMobileCommon.Utils.Timer StaleTimer;
        private object MDEAAlertLock = new object();

        private DateTime _simulatedPathStartTime = DateTime.MinValue;
        private Coordinates _simulatedLocation = new Coordinates(0, 0);

        private Dictionary<string, List<BusRoute>> _transitRoutes = new Dictionary<string, List<BusRoute>>();
        private bool _gettingTransitRoutes = true;
        private bool _transitRoutesAvailable = false;

        //distance from pickup for leaving group
        private int _distanceFromPickupForLeavingGroupInMetersSetting = 75;//fordebugging   10;

        public HomePage()
        {
            InitializeComponent();

            IsSafe = true;
            IsInVehicle = false;

            StaleTimer = new CITOMobileCommon.Utils.Timer(TimeSpan.FromSeconds(1), CheckStaleAlertTimerTick, false);

            ObuSettings = new DsrcSettings();
            ObuSettings.SendBsm = false;
            ObuSettings.SendPsm = false;
            ObuSettings.SendPmm = false;

            // SafeStatusTapGesture = new TapGestureRecognizer();
            CancelTripTapGesture = new TapGestureRecognizer();
            ScheduleTripTapGesture = new TapGestureRecognizer();
            ScheduleTransitTapGesture = new TapGestureRecognizer();
            SettingsTapGesture = new TapGestureRecognizer();
            TestAlertTapGesture = new TapGestureRecognizer();
            GroupStatusTapGesture = new TapGestureRecognizer();

            LocomateConnectionMgr = new LocomateConnectionManager();
            LocationMontr = new LocationMonitor();
            ActivityDetectMontr = new ActivityDetectMonitor();

            PersonalMobilityGroupMgr = new PersonalMobilityGroupManager(ObuSettings, ObuSettingsLock, LocomateConnectionMgr);
            BeaconMonitor = new BeaconMon();
            
            PersonalSafetyMonitor = new SafetyMon(IsInVehicle, IsSafe,
                PersonalMobilityGroupMgr.IsInGroup, PersonalMobilityGroupMgr.IsGroupLeader, LocomateConnectionMgr, BeaconMonitor,
                ObuSettings, ObuSettingsLock);
            DbLogger.Instance().Debug("App: Launching MDEA");
            DbLogger.Instance().Debug("Settings: " + Settings.ToString());
            GetTransitRoutes();
        }

        private async void GetTransitRoutes()
        {
            List<BusRoute> routes;
            List<BusRoute> stops;
            MdeaCloudCommunications cloudCommunications;
            try
            {
                cloudCommunications = new MdeaCloudCommunications();
                routes = await cloudCommunications.GetTransitRoute("TRANSITROUTELIST");
                if (routes != null)
                {
                    foreach (BusRoute route in routes)
                    {
                        stops = await cloudCommunications.GetTransitRoute(route.TransitPickupStop);
                        if (stops != null)
                        {
                            _transitRoutes[route.TransitPickupStop] = stops;
                        }
                    }
                }
                if (_transitRoutes.Count > 0)
                    _transitRoutesAvailable = true;
            }
            catch (Exception ex)
            {
                Logger.Debug(TAG, "Exception in GetTransitRoutes: " + ex.Message);
            }
            _gettingTransitRoutes = false;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            //PersonalMobilityGroupMgr.Reset();

            Settings.SettingChanged += HandleSettingsChanged;
            DebugStatus.DebugStatusEvent += HandleDebugStatusChanged;


            CancelTripTapGesture.Tapped += CancelTripTapGesture_Tapped;
            CancelTripLabel.GestureRecognizers.Add(CancelTripTapGesture);

            ScheduleTripTapGesture.Tapped += TakeTripTapGesture_Tapped;
            ScheduleTripButton.GestureRecognizers.Add(ScheduleTripTapGesture);

            ScheduleTransitTapGesture.Tapped += TakeTransitTapGesture_Tapped;
            ScheduleTransitButton.GestureRecognizers.Add(ScheduleTransitTapGesture);

            SettingsTapGesture.Tapped += SettingsTapGesture_Tapped;
            SettingsImage.GestureRecognizers.Add(SettingsTapGesture);

            LocationMontr.ConnectedEvent += LocationMontr_ConnectedEvent;
            LocationMontr.DisconnectedEvent += LocationMontr_DisconnectedEvent;
            LocationMontr.LocationChanged += LocationMontr_LocationChanged;

            ActivityDetectMontr.ActivityDetectionChanged += ActivityDetectMontr_ActivityDetectionChanged;
            ActivityDetectMontr.StartMonitoring();

            LocomateConnectionMgr.ConnectedEvent += LocomateConnectionMgr_ConnectedEvent;
            LocomateConnectionMgr.DisconnectedEvent += LocomateConnectionMgr_DisconnectedEvent;
            LocomateConnectionMgr.DeviceNotFound += LocomateConnectionMgr_DeviceNotFound;

           // PersonalMobilityGroupMgr.FindOrCreateGroupComplete += PersonalMobilityGroupMgr_FindOrCreateGroupComplete;
            PersonalMobilityGroupMgr.UpdateGroupStatus += PersonalMobilityGroupMgr_UpdateGroupStatus;
            PersonalMobilityGroupMgr.UpdateLeaderNotes += PersonalMobilityGroupMgr_UpdateGroupLeaderNotes;
            //PersonalMobilityGroupMgr.NumberOfClientsChanged += PersonalMobilityGroupMgr_NumberOfClientsChanged;
            // PersonalMobilityGroupMgr.ReceivedPMMResponse += PersonalMobilityGroupMgr_ReceivedPMMResponse;


            GroupStatusTapGesture.Tapped += GroupStatusTapGesture_Tapped;
            GroupStatusImage.GestureRecognizers.Add(GroupStatusTapGesture);

            LocationMontr.StartMonitoringLocation();
            ConnectToLocomate();

            ReSetIconImages();

            BeaconMonitor.StartMonitoring();

            PersonalSafetyMonitor.StartMonitoring();

        }

        public void OnActivityDestroy()
        {
            DbLogger.Instance().Debug("App: Closing MDEA");
            PersonalMobilityGroupMgr.Disconnect();
            LocomateConnectionMgr.DisableConnection();
            DbLogger.Close();
            GC.Collect();//http://stackoverflow.com/questions/8511901/system-data-sqlite-close-not-releasing-database-file
        }

        private void GroupStatusTapGesture_Tapped(object sender, EventArgs e)
        {
            //PersonalMobilityGroupMgr.SendTestString("Test String : " + DateTime.Now.ToString("yyyy-MM-dd hh:mm"));
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();

            PersonalSafetyMonitor.StopMonitoring();

            GroupStatusImage.GestureRecognizers.Remove(GroupStatusTapGesture);
            CancelTripLabel.GestureRecognizers.Remove(CancelTripTapGesture);
            ScheduleTripButton.GestureRecognizers.Remove(ScheduleTripTapGesture);
            ScheduleTransitButton.GestureRecognizers.Remove(ScheduleTransitTapGesture);
            SettingsImage.GestureRecognizers.Remove(SettingsTapGesture);

            LocationMontr.ConnectedEvent -= LocationMontr_ConnectedEvent;
            LocationMontr.DisconnectedEvent -= LocationMontr_DisconnectedEvent;
            LocationMontr.LocationChanged -= LocationMontr_LocationChanged;
            LocationMontr.StopMonitoringLocation();

            ActivityDetectMontr.ActivityDetectionChanged -= ActivityDetectMontr_ActivityDetectionChanged;
            ActivityDetectMontr.StopMonitoring();

            LocomateConnectionMgr.ConnectedEvent -= LocomateConnectionMgr_ConnectedEvent;
            LocomateConnectionMgr.DisconnectedEvent -= LocomateConnectionMgr_DisconnectedEvent;
            LocomateConnectionMgr.DeviceNotFound -= LocomateConnectionMgr_DeviceNotFound;

           // PersonalMobilityGroupMgr.FindOrCreateGroupComplete -= PersonalMobilityGroupMgr_FindOrCreateGroupComplete;
            PersonalMobilityGroupMgr.UpdateGroupStatus -= PersonalMobilityGroupMgr_UpdateGroupStatus;
            PersonalMobilityGroupMgr.UpdateLeaderNotes -= PersonalMobilityGroupMgr_UpdateGroupLeaderNotes;
           // PersonalMobilityGroupMgr.NumberOfClientsChanged -= PersonalMobilityGroupMgr_NumberOfClientsChanged;
            //PersonalMobilityGroupMgr.ReceivedPMMResponse -= PersonalMobilityGroupMgr_ReceivedPMMResponse;

            if (LocomateConnectionMgr.CurrentLocomateDevice != null)
                LocomateConnectionMgr.CurrentLocomateDevice.J2735MessageReceived -= LocomateConnectionMgr_J2735MessageReceived;

            DisconnectFromCurrentLocomate();
        }

        private void ReSetIconImages()
        {
            if (IsSafe)
                SetImageIcon(SafeStatusImage, "grayminus.png");
            else
                SetImageIcon(SafeStatusImage, "warningred.png");

            if (IsInVehicle)
                SetImageIcon(VehicleStatusImage, "cargreen.png");
            else
                SetImageIcon(VehicleStatusImage, "carred.png");
        }



        public void ConnectToLocomate()
        {
            if (!String.IsNullOrEmpty(Settings.LocomateDeviceMac))
            {
                String locomateName = Settings.LocomateDeviceMac;

                LocomateConnectionMgr.EstabilshConnection(locomateName);
            }
        }

        private void DisconnectFromCurrentLocomate()
        {
            LocomateConnectionMgr.DisableConnection();

        }


        /*********************************************************************************************************************
         * 
         *  Tap Gestures
         * 
         ********************************************************************************************************************/
        //private void SafeStatusTapGesture_Tapped(object sender, EventArgs e)
        //{
        //    SetIsSafe(!IsSafe);
        //}

        //private void VehicleStatusTapGesture_Tapped(object sender, EventArgs e)
        //{
        //    SetIsInVehicle(!IsInVehicle);
        //}

        private void TestAlertTapGesture_Tapped(object sender, EventArgs e)
        {
            Device.BeginInvokeOnMainThread(() => DisplayMDEAAlert(SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_WARNING));
        }

        private async void SettingsTapGesture_Tapped(object sender, EventArgs e)
        {
            var settingsPage = new SettingsPage();
            await PopupNavigation.PushAsync(settingsPage);
        }

        /// <summary>
        /// Called when in a wifi travel group, to exit participation in the group.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void CancelTripTapGesture_Tapped(object sender, EventArgs e)
        {
            DbLogger.Instance().Debug("User State Change: Trip Cancelled By User.");
            //Inform the PersonalMobilityGroupManager that a Cancel action was selected.
            PersonalMobilityGroupMgr.SaveCancel();

            //if(PersonalMobilityGroupMgr.IsInGroup)//if we aren't in  a group, this button shouldn't even be visable
            //{
            //    //If the leader cancels the trip - the whole trip ends because finding a new leader is not in scope for demo.
            //    //if  a follower quits, they only need to update the leader with their cancel
            //    //so that the leader can send an updated (reduced) pmm seat request.
            //    if (PersonalMobilityGroupMgr.IsGroupLeader)
            //    {


            //        //notify followers?

            //        //Send PMM Cancel (until acknowledged with acceptance)
            //    }

            //    ////Disband group - Disconnect will end the service too if we are the leader.
            //    //PersonalMobilityGroupMgr.Disconnect();
            //    SetGroupIcon();

            //    PersonalSafetyMonitor.AmIGroupLeader = PersonalMobilityGroupMgr.IsGroupLeader;
            //    PersonalSafetyMonitor.AmIInGroup = PersonalMobilityGroupMgr.IsInGroup;


            //}

            ////Clear out display
            //DestinationLabel.Text = "No Destination";
            //StatusLabel.Text = "";
            //CancelTripLabel.Text = "";

            //Re-enable take trip request now that we are done with the current one.
            // ScheduleTripTapGesture.Tapped += TakeTripTapGesture_Tapped;
            //ScheduleTripButton.IsEnabled = true;
        }

        private async void TakeTripTapGesture_Tapped(object sender, EventArgs e)
        {
            DbLogger.Instance().Debug("User State Change: Taxi trip Screen requested.");
            //Disable the button so that they can't stack trip requests
            // ScheduleTripButton.GestureRecognizers.Remove(ScheduleTripTapGesture);
            // ScheduleTripButton.IsEnabled = false;// todo:doesn't work

            if (CurrentLocation == null)
            {
                //Display Alert
                await DisplayAlert("Location Not Found.", "Location needed to take taxi trip.", "OK");
            }
            else
            {
                var tripInputPage = new UserTripInputPage(CurrentLocation);
                tripInputPage.UserTripInputRequested += TripOrTransitInputPage_UserTripOrTransitInputRequested;
                tripInputPage.UserTripCanceled += TripInputPage_UserTripCanceled;
                await PopupNavigation.PushAsync(tripInputPage);
            }

        }

        private async void TakeTransitTapGesture_Tapped(object sender, EventArgs e)
        {
            DbLogger.Instance().Debug("User State Change: Transit trip Screen requested.");
            //Disable the button so that they can't stack trip requests
            // ScheduleTripButton.GestureRecognizers.Remove(ScheduleTripTapGesture);
            // ScheduleTripButton.IsEnabled = false;// todo:doesn't work

            if (CurrentLocation == null)
            {
                //Display Alert
                await DisplayAlert("Location Not Found.", "Location needed to take transit trip.", "OK");
            }
            else if (_gettingTransitRoutes)
            {
                await DisplayAlert("Getting Transit Routes", "Getting transit route information, please try again later.", "OK");
            }
            else if (!_transitRoutesAvailable)
            {
                await DisplayAlert("No Transit Routes", "Failed to get transit route information.", "OK");
            }
            else
            {
                var transitInputPage = new UserTransitInputPage(_transitRoutes);
                transitInputPage.UserTransitInputRequested += TripOrTransitInputPage_UserTripOrTransitInputRequested;
                transitInputPage.UserTransitCanceled += TransitInputPage_UserTransitCanceled;
                await PopupNavigation.PushAsync(transitInputPage);
            }

        }
        
        private async void TripOrTransitInputPage_UserTripOrTransitInputRequested(object sender, UserTripInput e)
        {
            DbLogger.Instance().Debug("User State Change: Trip Started. Initializing.");
            string currentDestinationString;
            Coordinates currentLoc = new Coordinates(0, 0);
            Coordinates destinationLoc = new Coordinates(0, 0);
   
            lock (locationLock)
            {
                //Create a copy of coordinates
                currentLoc = new Coordinates(CurrentLocation);
            }

            if (e.ModeOfTransport == "transit")
            {
                foreach (BusRoute stop in _transitRoutes[e.TransitRoute])
                {
                    if (stop.TransitPickupStop == e.TransitPickupStop)
                    {
                        //check distance to selected stop
                        double distance = Conversions.DistanceMeters(currentLoc.Latitude, currentLoc.Longitude, stop.PickupLat, stop.PickupLong);
                        if (distance < _distanceFromPickupForLeavingGroupInMetersSetting)
                        {
                            //in range of selected stop
                            currentLoc = new Coordinates(stop.PickupLat, stop.PickupLong);
                            destinationLoc = new Coordinates(stop.DestLat, stop.DestLong);
                            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
                            {
                                ScheduleTripButton.IsVisible = false;
                                ScheduleTransitButton.IsVisible = false;
                                DestinationLabel.Text = e.TransitPickupStop;
                                StatusLabel.Text = "Looking for group";
                            });
                        }
                        else
                        {
                            //not in range of selected stop, display Alert
                            await DisplayAlert("Invalid Stop Selected.", "Selected transit stop is too far away.", "OK");
                            return;
                        }
                    }
                }
            }
            else
            {
                CurrentDestinationLat = e.Destination.Latitude;
                CurrentDestinationLon = e.Destination.Longitude;
                currentDestinationString = string.Format("{0:0.########}", e.Destination.Latitude) + "," + string.Format("{0:0.########}", e.Destination.Longitude);
                Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
                {
                    ScheduleTripButton.IsVisible = false;
                    ScheduleTransitButton.IsVisible = false;
                    DestinationLabel.Text = currentDestinationString;
                    StatusLabel.Text = "Looking for group";
                });
                destinationLoc = new Coordinates(e.Destination.Latitude, e.Destination.Longitude); //TODO add rest of fields like elevation? not populated currently from map
            }


            //MdeaCloudCommunications CloudCommunications = new MdeaCloudCommunications();

            //PmmRequest pr = new PmmRequest();
            //pr.DestLatitude = 1;
            //pr.DestLongitude = 1;
            //pr.Elevation = 0;
            //pr.GroupIdent = Guid.NewGuid();
            //pr.HandicappedSeats = 0;
            //pr.ModeofTransport = 0;
            //pr.PickupDate = DateTime.UtcNow;
            //pr.PickupLatitude = 1;
            //pr.PickupLongitude = 1;
            //pr.PosAccuracy = 0;
            //pr.RegularSeats = 3;
            //pr.RequestDate = DateTime.UtcNow;
            //pr.RequestId = 1;
            //pr.Status = 1;
            //var response = await CloudCommunications.SendPmm(pr);
            //TravelRequest tr = new TravelRequest();
            //tr.FollowerId = Guid.NewGuid();
            //tr.PickupTime = DateTime.UtcNow;
            ////Specify these 4 fields for a taxi request
            //tr.TaxiDestLat = destinationLoc.Latitude;
            //tr.TaxiDestLong = destinationLoc.Longitude;
            //tr.TaxiPickupLat = destinationLoc.Latitude;
            //tr.TaxiPickupLong = destinationLoc.Longitude;
            //TravelRequest responsetr =  CloudCommunications.SendTravelRequest(tr);
            PersonalMobilityGroupMgr.FindOrCreateGroup(destinationLoc, currentLoc, e.HandicapSeats, e.RegularSeats, e.ModeOfTransport, e.TransitRoute, e.TransitPickupStop);
        }

        private void TripInputPage_UserTripCanceled(object sender, EventArgs e)
        {
            DbLogger.Instance().Debug("User State Change: Taxi trip screen quit by user.");
            try
            {
            }
            catch
            {
            }
        }

        private void TransitInputPage_UserTransitCanceled(object sender, EventArgs e)
        {
            DbLogger.Instance().Debug("User State Change: Transit trip screen quit by user.");
            try
            {
            }
            catch
            {
            }
        }

        /*********************************************************************************************************************
        *  End Tap Gestures
        ********************************************************************************************************************/


        /*********************************************************************************************************************
         * 
         *  Personal Mobility Group Manager Events
         * 
         ********************************************************************************************************************/
        //private void PersonalMobilityGroupMgr_NumberOfClientsChanged(object sender, int e)
        //{
        //    //CreateAndSendPmmReqest(e);

        //}

        //private void PersonalMobilityGroupMgr_ReceivedPMMResponse(object sender, PMM e)
        //{
        //    ProcessPMM(e);
        //}
        private void ProcessPMM(PMM pmm)//todo no longer called. do we need to send the pickup date from the response? don't currently.
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                StatusLabel.Text = pmm.PersonalMobilityMessage.status;
                StartDateLabel.Text = "Pickup Date: " + pmm.PersonalMobilityMessage.pickupDate.ToDateTimeString();
                VehicleTypeLabel.Text = "Vehicle Description: " + pmm.PersonalMobilityMessage.vehicleDesc;
            });
        }
        //private void PersonalMobilityGroupMgr_FindOrCreateGroupComplete(object sender, EventArgs e)
        //{

        //    SetGroupIcon();

        //    PersonalSafetyMonitor.AmIGroupLeader = PersonalMobilityGroupMgr.IsGroupLeader;
        //    PersonalSafetyMonitor.AmIInGroup = PersonalMobilityGroupMgr.IsInGroup;
        //    if (PersonalMobilityGroupMgr.IsInGroup)
        //    {
        //        Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
        //        {
        //            //    StatusLabel.Text = "Pending";
        //            CancelTripLabel.Text = "Cancel Trip";
        //        });
        //    }

        //}

        /// <summary>
        /// Not called on main thread.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PersonalMobilityGroupMgr_UpdateGroupStatus(object sender, PmmStatusEventArgs e)
        {
            DbLogger.Instance().Debug("User State Change: Update status " + e.Status);
            //This handler is called from another thread. Use BeginInvoke to update the UI on the UI thread.
            //You must be in the main activity to call BeginInvokeOnMainThread.
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                StatusLabel.Text = e.Status;
                CancelTripLabel.Text = "Cancel Trip";
                if (e.MessageType == PmmStatusEventArgs.MsgType.Complete)
                {
                    //Clear out display
                    ScheduleTripButton.IsVisible = true;
                    ScheduleTransitButton.IsVisible = true;
                    DestinationLabel.Text = "No Destination";
                    StatusLabel.Text = "";
                    CancelTripLabel.Text = "";
                    LeaderNoteLabel.Text = "";
                
            }
                else if ( e.MessageType == PmmStatusEventArgs.MsgType.Cancelled)
                {
                    //Clear out display
                    ScheduleTripButton.IsVisible = true;
                    ScheduleTransitButton.IsVisible = true;
                    DestinationLabel.Text = "No Destination";
                    StatusLabel.Text = "Trip Cancelled";
                    CancelTripLabel.Text = "";

                    //todo : maybe start a timer to clear out statusLabel after 20 seconds?
                    Device.StartTimer(TimeSpan.FromSeconds(20), () =>
                     {
                         if (StatusLabel.Text == "Trip Cancelled") { 
                             StatusLabel.Text = "";
                         LeaderNoteLabel.Text = "";
                        }
                         return false;
                     }
                    );
                }
                else if (e.MessageType == PmmStatusEventArgs.MsgType.Quit)
                {
                    //Clear out display
                    ScheduleTripButton.IsVisible = true;
                    ScheduleTransitButton.IsVisible = true;
                    DestinationLabel.Text = "No Destination";
                    StatusLabel.Text = "Group Failed";
                    CancelTripLabel.Text = "";

                    //todo : maybe start a timer to clear out statusLabel after 20 seconds?
                    Device.StartTimer(TimeSpan.FromSeconds(20), () =>
                    {
                        if (StatusLabel.Text == "Group Failed")
                        {
                            StatusLabel.Text = "";
                            LeaderNoteLabel.Text = "";
                        }
                        return false;
                    }
                    );
                }

                PersonalSafetyMonitor.AmIGroupLeader = PersonalMobilityGroupMgr.IsGroupLeader;
                PersonalSafetyMonitor.AmIInGroup = PersonalMobilityGroupMgr.IsInGroup;
                SetGroupIcon();
            });

        }


        private void PersonalMobilityGroupMgr_UpdateGroupLeaderNotes(object sender, PmmStatusEventArgs e)
        {
            DbLogger.Instance().Debug("User State Change: Update leader note " + e.Status);
 
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                LeaderNoteLabel.Text = e.Status;
            });
        }
        //private void CreateAndSendPmmReqest(int numberOfSeats)
        //{
        //    if (PersonalMobilityGroupMgr.IsGroupLeader)
        //    {
        //        //Connected and Group Leader
        //        //TODO: Send PMM Request
        //        if (CurrentLocation != null && CurrentDestinationLat != 0 && CurrentDestinationLon != 0)
        //        {
        //            PersonalMobilityManager.SendPmmReqToDsrc(LocomateConnectionMgr, CurrentDestinationLat, CurrentDestinationLon,
        //                CurrentLocation.Latitude, CurrentLocation.Longitude, CurrentLocation.Altitude, DateTime.UtcNow, numberOfSeats, 0);
        //        }
        //    }
        //}

        private void SetGroupIcon()
        {
            if (PersonalMobilityGroupMgr.IsGroupLeader)
            {
                DbLogger.Instance().Debug("User State Change: InGroup, Leader");
                //Connected and Group Leader
                SetImageIcon(GroupStatusImage, "groupleader.png");
            }
            else if (PersonalMobilityGroupMgr.IsInGroup)
            {
                DbLogger.Instance().Debug("User State Change: InGroup, Follower");
                //Connected, and not group leader
                SetImageIcon(GroupStatusImage, "groupin.png");
            }
            else
            {
                DbLogger.Instance().Debug("User State Change: Not InGroup");
                //Not in group
                SetImageIcon(GroupStatusImage, "groupnotin.png");
            }
        }
        /*********************************************************************************************************************
        *  End Personal Mobility Group Manager
        ********************************************************************************************************************/


        /*********************************************************************************************************************
         * 
         *  Locomate Connection Manager Event Handlers
         * 
         ********************************************************************************************************************/
        private void LocomateConnectionMgr_DeviceNotFound(object sender, EventArgs e)
        {
            Logger.Debug(TAG, "DeviceNotFound");
            SetImageIcon(DsrcStatusImage, "dsrcoff.png");
        }

        private void LocomateConnectionMgr_DisconnectedEvent(object sender, EventArgs e)
        {
            Logger.Debug(TAG, "Disconnected");
            SetImageIcon(DsrcStatusImage, "dsrcoff.png");
            if (LocomateConnectionMgr.CurrentLocomateDevice != null)
                LocomateConnectionMgr.CurrentLocomateDevice.J2735MessageReceived -= LocomateConnectionMgr_J2735MessageReceived;
        }

        private void LocomateConnectionMgr_ConnectedEvent(object sender, EventArgs e)
        {
            Logger.Debug(TAG, "Connected");
            SetImageIcon(DsrcStatusImage, "dsrcon.png");

            PersonalSafetyMonitor.SendCurrentObuSettings();
            PersonalMobilityGroupMgr.InitPsmObuSettings();
            LocomateConnectionMgr.CurrentLocomateDevice.J2735MessageReceived += LocomateConnectionMgr_J2735MessageReceived;
        }

        private void SetImageIcon(Image img, String source)
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                var oldsource = (string)img.Source.GetValue(FileImageSource.FileProperty);
                if (oldsource != source)
                    img.Source = source;
            });
        }

        private void LocomateConnectionMgr_J2735MessageReceived(object sender, JsonDataMessage e)
        {
            StatusEventArgs gotMsg;
            DateTime now = DateTime.Now;
            string gotMsgTime = now.Minute.ToString() + ":" + now.Second.ToString();
            try
            {
                bool isMap = e is MAP_P;
                bool isSpat = e is SPAT_P;
                bool isBSM = e is BSM;
                bool isLocation = e is Location;
                bool isRTCM = e is RTCMInfo;
                bool isTIM = e is TravelerInformation;
                bool isPMM = e is PMM;

                if (isPMM)
                {
                    gotMsg = new StatusEventArgs(StatusType.PMMTIME, gotMsgTime);
                    DebugStatus.SendDebugStatus(this, gotMsg);

                    PMM pmm = e as PMM;
                    DbLogger.Instance().Debug("Dsrc: Rx: Pmm status: " + pmm.PersonalMobilityMessage.status + " GroupIdent: " + pmm.PersonalMobilityMessage.groupId + " RequestId: " + pmm.PersonalMobilityMessage.requestId);
                    PersonalMobilityGroupMgr.SavePmm(pmm);
                }
                else if (isBSM && CurrentLocation != null)
                {
                    gotMsg = new StatusEventArgs(StatusType.BSMTIME, gotMsgTime);
                    DebugStatus.SendDebugStatus(this, gotMsg);             

                    BSM bsm = e as BSM;
                    DbLogger.Instance().Debug("Dsrc: Rx: Bsm Lat:" + bsm.BasicSafetyMessage.Latitude + " Long: " + bsm.BasicSafetyMessage.Longitude + " Head: " + bsm.BasicSafetyMessage.Heading + " Sp: " + bsm.BasicSafetyMessage.Speed_mph);
                    SafetyMon.PedestrianSafetyStatusEnum pedSafey = PersonalSafetyMonitor.MonitorPedestrianSafety(bsm.BasicSafetyMessage, CurrentLocation);

                    Device.BeginInvokeOnMainThread(() => DisplayMDEAAlert(pedSafey));

                }
                else if (isMap)
                {
                    gotMsg = new StatusEventArgs(StatusType.MAPTIME, gotMsgTime);
                    DebugStatus.SendDebugStatus(this, gotMsg);

                    MAP_P map = e as MAP_P;
                    DbLogger.Instance().Debug("Dsrc: Rx: Map id:" + map.MapData.msgID);
                    PersonalSafetyMonitor.LoadMap(map);

                }
                else if (isSpat)
                {
                    SPAT_P spat = e as SPAT_P;
                    DbLogger.Instance().Debug("Dsrc: Rx: Spat id:" + spat.SPAT.msgID);
                }

            }
            catch (Exception ex)
            {
                Logger.Error(TAG + " Home Page", "J2735MessageReceived Error: " + ex.Message);
            }

        }



        /*********************************************************************************************************************
        *  End Locomate Connection Manager Event Handlers
        ********************************************************************************************************************/


        /*********************************************************************************************************************
        * 
        *  Location Event Handlers
        * 
        ********************************************************************************************************************/
        private void LocationMontr_DisconnectedEvent(object sender, EventArgs e)
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                SetImageIcon(LocationStatusImage, "locationoff.png");
            });
        }

        private void LocationMontr_ConnectedEvent(object sender, EventArgs e)
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                SetImageIcon(LocationStatusImage, "locationon.png");
            });
        }

        private void SetSimulatedLocation()
        {
            double secElapsed;
            double factor;
            try
            {
                if (Settings.SimulatedLocation)
                {
                    if (Settings.SimulatedPath)
                    {
                        secElapsed = (DateTime.UtcNow - _simulatedPathStartTime).TotalSeconds;
                        if (secElapsed > Settings.SimulatedPathDuration)
                        {
                            _simulatedPathStartTime = DateTime.UtcNow;
                            _simulatedLocation.Latitude = Settings.SimulatedLatitude;
                            _simulatedLocation.Longitude = Settings.SimulatedLongitude;
                        }
                        else
                        {
                            factor = (DateTime.UtcNow - _simulatedPathStartTime).TotalSeconds / Settings.SimulatedPathDuration;
                            _simulatedLocation.Latitude = Settings.SimulatedLatitude + ((Settings.SimulatedEndLatitude - Settings.SimulatedLatitude) * factor);
                            _simulatedLocation.Longitude = Settings.SimulatedLongitude + ((Settings.SimulatedEndLongitude - Settings.SimulatedLongitude) * factor);
                        }
                    }
                    else
                    {
                        _simulatedLocation.Latitude = Settings.SimulatedLatitude;
                        _simulatedLocation.Longitude = Settings.SimulatedLongitude;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(TAG + " Home Page", "SetSimulatedLocation Error: " + ex.Message);
            }
        }

        private void LocationMontr_LocationChanged(object sender, CITOMobileCommon.Models.Coordinates e)
        {
            lock (locationLock)
            {
                if (Settings.SimulatedLocation)
                {
                    SetSimulatedLocation();
                    e = _simulatedLocation;
                }
                CurrentLocation = e;
            }
       
            Location locationMsg = new Location();
            locationMsg.LocationMessage.Heading = e.Heading;
            locationMsg.LocationMessage.Latitude = e.Latitude;
            locationMsg.LocationMessage.Longitude = e.Longitude;
            locationMsg.LocationMessage.Speed = e.Speed;
            locationMsg.LocationMessage.Elevation = e.Altitude;

            LocomateConnectionMgr.SendJsonData(locationMsg);

            PersonalSafetyMonitor.LocationUpdated(locationMsg);


            //TODO MOVE THIS icon update: need to update the icon more often than the other handler gives me.
            //Routinely update the vehicle icon per the AmInAVehicle variable from SafetyMon

           
            
            if(IsInVehicle != PersonalSafetyMonitor.AmIInAVehicle)
            {
                IsInVehicle = PersonalSafetyMonitor.AmIInAVehicle;
                DbLogger.Instance().Debug("User State Change: In Vehicle Icon " + IsInVehicle.ToString());
            }
            PersonalMobilityGroupMgr.SaveStatuses(PersonalSafetyMonitor.AmIInAVehicle, e);
            if(IsSafe != (!PersonalSafetyMonitor.AmIUnsafe))
            {
                IsSafe = !PersonalSafetyMonitor.AmIUnsafe;
                DbLogger.Instance().Debug("User State Change: Is Safe Icon " + IsSafe.ToString());
            }
            ReSetIconImages();

            if (Settings.LogLocationEarth)
            {
                //Output in csv Lat,Long,Type,LaneNumber,Region (ETRP format to use same Google Earth Plotter tool)
                //Lane number and Region have no applicability here. but must be numbers. Lets do bool conversion of Safe and inVehicle flags.
                string safe = "0";
                if (IsSafe) safe = "1";
                string veh = "0";
                if (IsInVehicle) veh = "1";

                DbLogger.Instance().Debug("Location: " + e.Latitude.ToString() + "," + e.Longitude.ToString() + ",p,"+safe+"," + veh);
            }
            else
            {
                //Output full location details per req.
                DbLogger.Instance().Debug("Dsrc: Tx: Location: " + e.ToString());
            }
               
          
        }

        private void ActivityDetectMontr_ActivityDetectionChanged(object sender, CITOMobileCommon.Models.ActivityDetection e)
        {
            CurrentActivityDetection = e;

            PersonalSafetyMonitor.ActivityDetectionUpdated(e);
            
            Logger.Debug(TAG, "Activity " + e.MostPrbActivity.ToString());
            //  ReSetIconImages();
        }

        /*********************************************************************************************************************
        *  End Location Event Handlers
        ********************************************************************************************************************/

        /*********************************************************************************************************************
        * 
        *  Display Alert Functions
        * 
        ********************************************************************************************************************/
        private void DisplayMDEAAlert(SafetyMon.PedestrianSafetyStatusEnum newAlert, bool timerAlert = false)
        {
            lock (MDEAAlertLock)
            {
                if (newAlert == SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_NONE)
                {
                    double secElapsed = (DateTime.UtcNow - LastAlertTime).TotalSeconds;
                    if (secElapsed > 2.0)
                    {
                        if (StaleTimer.IsRunning && timerAlert)
                        {
                            StaleTimer.Stop();
                        }
                        if (CurrentSafetyAlert != SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_NONE)
                        {
                            DbLogger.Instance().Debug("User State Change: Clear ped alert");
                            CurrentSafetyAlert = newAlert;
                            SetAlert(newAlert);
                        }
                    }
                    
                }
                else if (newAlert != CurrentSafetyAlert)
                {
                    if (!IsInVehicle) //Don't alert if in the car.
                    {
                        DbLogger.Instance().Debug("User State Change: Set ped alert " + newAlert.ToString());
                        SetAlert(newAlert);
                        CurrentSafetyAlert = newAlert;
                        LastAlertTime = DateTime.UtcNow;

                        if (!StaleTimer.IsRunning)
                        {
                            StaleTimer.Start();
                        }
                        if (newAlert == SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_ADVISORY)
                        {
                            _textToSpeech.Speak("advisory");
                        }
                        else if (newAlert == SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_ALERT)
                        {
                            _textToSpeech.Speak("alert");
                        }
                        else if (newAlert == SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_WARNING)
                        {
                            _textToSpeech.Speak("warning");
                        }
                    }
                }
                else
                {
                    //Still on the same alert, update timestamp.
                    LastAlertTime = DateTime.UtcNow;
                }
            }
        }

        public void SetAlert(SafetyMon.PedestrianSafetyStatusEnum alertType)
        {
            
            switch (alertType)
            {
                case SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_ADVISORY:
                    AlertImage.Source = "ped_safety_advisory.png";
                    break;
                case SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_ALERT:
                    AlertImage.Source = "ped_safety_alert.png";
                    break;
                case SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_WARNING:
                    AlertImage.Source = "ped_safety_warning.png";
                    break;
                default:
                    AlertImage.Source = "";
                    break;
            }
        }

        private void CheckStaleAlertTimerTick()
        {
            //if it has been more than X seconds since an alert update, clear the alert state back to none.
            double secElapsed = (DateTime.UtcNow - LastAlertTime).TotalSeconds;
            if (secElapsed > 2.0)
            {
                Device.BeginInvokeOnMainThread(() => DisplayMDEAAlert(SafetyMon.PedestrianSafetyStatusEnum.PED_SAFETY_NONE, true));
            }
        }

        /*********************************************************************************************************************
        *  End Display Alert Functions
        ********************************************************************************************************************/


        /*********************************************************************************************************************
        * 
        *  Beacon Events
        * 
        ********************************************************************************************************************/

        public void HandleDebugStatusChanged(object sender, CITOMobileCommon.Utils.StatusEventArgs args)
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                try
                {
                    string statusText = "";
                    if (Settings.DisplayStatusMessages)
                    {
                        switch (args.StatusType)
                        {
                            case CITOMobileCommon.Utils.StatusType.LAT:
                                if (Settings.SimulatedLocation)
                                {
                                    statusText = string.Format("Lat: " + "{0:0.########}", _simulatedLocation.Latitude);
                                }
                                else
                                {
                                    statusText = (string)args.Data;
                                }
                                DebugLatLabel.Text = statusText;
                                break;
                            case CITOMobileCommon.Utils.StatusType.LON:
                                if (Settings.SimulatedLocation)
                                {
                                    statusText = string.Format("Lon: " + "{0:0.########}", _simulatedLocation.Longitude);
                                }
                                else
                                {
                                    statusText = (string)args.Data;
                                }
                                DebugLonLabel.Text = statusText;
                                break;
                            case CITOMobileCommon.Utils.StatusType.BEACON:
                                statusText = (string)args.Data;
                                DebugRSSILabel.Text = statusText;
                                break;
                            case CITOMobileCommon.Utils.StatusType.SPEED:
                                statusText = (string)args.Data;
                                DebugSpeedLabel.Text = statusText;
                                break;
                            case CITOMobileCommon.Utils.StatusType.PMMTIME:
                                statusText = "Pmm: " + (string)args.Data;
                                DebugPmmTimeLabel.Text = statusText;
                                break;
                            case CITOMobileCommon.Utils.StatusType.BSMTIME:
                                statusText = "Bsm: " + (string)args.Data;
                                DebugBsmTimeLabel.Text = statusText;
                                break;
                            case CITOMobileCommon.Utils.StatusType.MAPTIME:
                                statusText = "Map: " + (string)args.Data;
                                DebugMapTimeLabel.Text = statusText;
                                break;
                            case CITOMobileCommon.Utils.StatusType.SENDPSM:
                                statusText = "SendPsm "+(string)args.Data;
                                DebugSendPsmLabel.Text = statusText;
                                break;
                            default:
                                break;
                        }
                    }
                }
                catch(Exception ex)
                {
                }
            });
        }

        /*********************************************************************************************************************
        *  End Beacon Events
        ********************************************************************************************************************/

        /*********************************************************************************************************************
        * 
        *  Settings Events
        * 
        ********************************************************************************************************************/

        public void HandleSettingsChanged(object sender, string setting)
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                if (setting == "DisplayStatusMessages")
                {
                    //clear all status messages only if toggled off
                    if (!Settings.DisplayStatusMessages)
                    {
                        DebugLatLabel.Text = "";
                        DebugLonLabel.Text = "";
                        DebugRSSILabel.Text = "";
                        DebugSpeedLabel.Text = "";
                        DebugPmmTimeLabel.Text = "";
                        DebugBsmTimeLabel.Text = "";
                        DebugMapTimeLabel.Text = "";
                        DebugSendPsmLabel.Text = "";
                    }
                }
                else if (setting == "LocomateDevice")
                {
                    DisconnectFromCurrentLocomate();
                    ConnectToLocomate();
                }
            });
        }

        /*********************************************************************************************************************
        *  End Settings Events
        ********************************************************************************************************************/

    }
}
