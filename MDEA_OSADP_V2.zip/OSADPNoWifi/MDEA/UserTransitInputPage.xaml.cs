﻿using CITOMobileCommon.J2735.Ext;
using CITOMobileCommon.Logging;
using CITOMobileCommon.Models;
using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Maps;
using MobileDevicesExperimentalApplication.WebApi;

namespace MobileDevicesExperimentalApplication
{
    public partial class UserTransitInputPage : PopupPage
    {
        private Dictionary<string, List<BusRoute>> _transitRoutes;

        public event EventHandler<UserTripInput> UserTransitInputRequested;
        public event EventHandler UserTransitCanceled;

        public UserTransitInputPage(Dictionary<string, List<BusRoute>> transitRoutes)
        {
            InitializeComponent();

            for (int i = 0; i <= 10; i++)
            {
                RegularSeatPicker.Items.Add((i).ToString());
                HandicapSeatPicker.Items.Add((i).ToString());
            }

            HandicapSeatPicker.SelectedIndex = 0;
            RegularSeatPicker.SelectedIndex = 1;

            _transitRoutes = transitRoutes;
            foreach (string route in transitRoutes.Keys)
            {
                TransitRoutePicker.Items.Add(route);
            }
            TransitRoutePicker.SelectedIndexChanged += TransitRoutePicker_SelectedIndexChanged;
        }

        private void TransitRoutePicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (TransitRoutePicker.SelectedIndex >= 0)
            {
                TransitStopPicker.Items.Clear();
                foreach (BusRoute stop in _transitRoutes[TransitRoutePicker.Items[TransitRoutePicker.SelectedIndex]])
                {
                    TransitStopPicker.Items.Add(stop.TransitPickupStop);
                }
            }
        }

        private async void RequestButton_Clicked(object sender, EventArgs e)
        {
            Coordinates stopCoordinates;
            if (TransitRoutePicker.SelectedIndex >= 0 && TransitStopPicker.SelectedIndex >= 0)
            {
                foreach (BusRoute stop in _transitRoutes[TransitRoutePicker.Items[TransitRoutePicker.SelectedIndex]])
                {
                    if (stop.TransitPickupStop == TransitStopPicker.Items[TransitStopPicker.SelectedIndex])
                    {
                        stopCoordinates = new Coordinates(stop.PickupLat, stop.PickupLong);
                        UserTransitInputRequested?.Invoke(this, new UserTripInput(RegularSeatPicker.SelectedIndex, HandicapSeatPicker.SelectedIndex,
                            "transit", stop.TransitRoute, stop.TransitPickupStop));
                        //   await Task.Delay(500);
                        await PopupNavigation.PopAsync().ConfigureAwait(false);
                        return;
                    }
                }
            }
        }

        private async void CancelButton_Clicked(object sender, EventArgs e)
        {
            UserTransitCanceled?.Invoke(this, e);
            await PopupNavigation.PopAsync().ConfigureAwait(false);
        }

    }
}
