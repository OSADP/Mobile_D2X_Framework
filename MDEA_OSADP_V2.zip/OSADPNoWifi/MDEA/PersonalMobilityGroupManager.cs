﻿using CITOMobileCommon;
using CITOMobileCommon.Data;
using CITOMobileCommon.J2735.Ext;
using CITOMobileCommon.Logging;
using CITOMobileCommon.Models;
using CITOMobileCommon.Utils;
using CITOMobileCommon.WiFi;
using MobileDevicesExperimentalApplication.WebApi;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
//using System.Threading;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MobileDevicesExperimentalApplication
{
    public class PersonalMobilityGroupManager
    {
        MdeaCloudCommunications CloudCommunications = new MdeaCloudCommunications();
        private static String TAG = "MDEA-PMMGM";
        /// <summary>
        /// To handle passing some custom fields back to the home page.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public delegate void PmmStatusEventHandler(
     object sender,
     PmmStatusEventArgs args);


        public event EventHandler FindOrCreateGroupComplete;
        /// <summary>
        /// Not handled on main thread.
        /// </summary>
        public event PmmStatusEventHandler UpdateGroupStatus;
        /// <summary>
        /// Not handled on main thread.
        /// </summary>
        public event PmmStatusEventHandler UpdateLeaderNotes;
        public event EventHandler<int> NumberOfClientsChanged;
        //  public event EventHandler<PMM> ReceivedPMMResponse;


        private PmmManager _pmManager;
        private TravelRequest _travelRequest;
        private Guid _followerGuid; //Set at startup and kept consistent until software restarted.  Unique guid for traveler.
        private int _handicapSeats = 0;
        private int _regularSeats = 0;
        private ModeOfTransportType _modeOfTransport = ModeOfTransportType.noPreference;

        //      private IWiFiP2P _wirelessDirect;
        private string _destinationString;

        private object _groupFlagsLock = new object();
        // private bool _isGroupFound;
        public bool IsGroupLeader { get; private set; }
        public bool IsInGroup { get; private set; }
        private bool _stopTryingToConnect;

        private bool _IsTryingToConnect;

        //private object _recvPmmsLock = new object();
        private ConcurrentQueue<PMM> _recvPmms; //thread safe
        private object _pmmCancelLock = new object();
        private bool _pmmCancelRequested = false;
        private object _pmmStatusesLock = new object();
        private bool _pmmInVehicle = false;
        private Coordinates _pmmCurrLocation = new Coordinates();

        PmmRequest _usersPmmRequest;

        //private object _memberLock = new object();
        private List<PMGroupMember> _members; //only accessed from leader thread.
        //private object _msgsToWifiLock = new object();
        //private ConcurrentQueue<string> _msgsToWifi; //thread safe
        ////private object _msgsFromWifiLock = new object();
        //private ConcurrentQueue<string> _msgsFromWifi; //thread safe

        //heartbeat expiration time
        private int _heartbeatExpirationInSecondsSetting = 300;//for debugging   3;

        //distance from pickup for leaving group
        private int _distanceFromPickupForLeavingGroupInMetersSetting = 75;//fordebugging   10;

        //      private int _maxWifiDevicesSetting = 3;


        private DateTime _startDsrcWindow;
        private DateTime _stopDsrcWindow;
        //Time to wait after attempting over dsrc before we bother trying over dsrc again.
        private TimeSpan _timeBeforeRetryDsrcSetting = new TimeSpan(0, 0, 1); //wait 1 second before trying over dsrc again.//todo put back 1 minute someday - more 'realistic' setting, but not good for ATP testing - not a requirement.

        // AutoResetEvent _msgsToWifiSent = new AutoResetEvent(false);

        Timer _findOrCreateGroupTimer;

        public PersonalMobilityGroupManager(DsrcSettings obuSettings, object obuSettingsLock, LocomateConnectionManager connectionMgr)
        {
            _recvPmms = new ConcurrentQueue<PMM>();

            //      _msgsToWifi = new ConcurrentQueue<string>();
            //       _msgsFromWifi = new ConcurrentQueue<string>();
            _pmManager = new PmmManager(obuSettings, obuSettingsLock, connectionMgr);


            //_isGroupFound = false;
            //_wirelessDirect = DependencyService.Get<IWiFiP2P>();
            //_wirelessDirect.NumberClientsChanged += WirelessDirect_NumberClientsChanged;
            //_wirelessDirect.ServiceFound += WirelessDirect_ServiceFound;
            //_wirelessDirect.GroupStatusChanged += WirelessDirect_GroupStatusChanged;
            //_wirelessDirect.ConnectedToGroup += WirelessDirect_ConnectedToGroup;
            //_wirelessDirect.RecievedData += WirelessDirect_RecievedData;

            //Initialize timing window to use for transmitting dsrc
            _startDsrcWindow = DateTime.Now;
            _stopDsrcWindow = DateTime.Now;

            //Set up a timer.  When the leader or follower thread spawns, we need something on the main thread
            //to talk to the _wirelessDirect object and send out messages coming from the threads.

            //TODO: is this okay to leave this running forever? if there is no active group, _msgsToWifi should be empty and it should exit.
            // Timer outgoingWifiMsgs = new Timer(TimeSpan.FromSeconds(1), () =>
            //{
            //    string memMsg;
            //    while (_msgsToWifi.TryDequeue(out memMsg))
            //    {
            //        _wirelessDirect.SendInformation(memMsg);
            //    }
            //    _msgsToWifiSent.Set();
            //}, false).Start();

        }

        //public void SendTestString(string testString)
        //{
        //    _wirelessDirect.SendInformation(testString);
        //}
        //char[] wifiMsgTerminator = new char[] { ';' };
        /// <summary>
        /// Called from AndroidWifiP2P.StartListenThreadForClientSocket
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //private void WirelessDirect_RecievedData(object sender, string e)
        //{
        //    Logger.Debug(TAG, "Grouping: Rx: " + e);
        //    DbLogger.Instance().Debug("Grouping: Rx: " + e);

        //    if (e.StartsWith(BasePrefixToken))//Starts with "$MDEA"
        //    {
        //        //Send message off to leader/follower threads. sometimes they get concatenated.
        //        foreach (var w in e.Split(wifiMsgTerminator, StringSplitOptions.RemoveEmptyEntries))
        //        {
        //            string msg = w;
        //            //queue this so we can grab the data on the leader/follower thread.
        //            _msgsFromWifi.Enqueue(msg);
        //        }

        //    }



        //}
        private void RecordHeartbeatToMemberList(PMGroupMember heartbeat)
        {
            bool isNew = true;
            foreach (PMGroupMember m in _members)
            {
                if (m.MemberGuid == heartbeat.MemberGuid)
                {
                    //Update for an existing member, save current.
                    isNew = false;

                    if (m.Status != MemberPmmStatus.Deleted)//may get the same message twice, only update status if it's not already gone.
                    {
                        if (heartbeat.RegularSeats == 0 && heartbeat.HandicappedSeats == 0)
                        {
                            //This follower has elected to quit.
                            m.Status = MemberPmmStatus.Quit;
                            //Dont save the changed seat request, cuz we need to know how many to 
                            //subtract - only save the "quit" status so we know to remove them.                  
                        }
                    }
                    m.LastUpdate = heartbeat.LastUpdate;
                    m.MemberLat = heartbeat.MemberLat;
                    m.MemberLong = heartbeat.MemberLong;
                }
            }
            if (isNew)
            {
                Logger.Debug(TAG, "Grouping: Group: Adding new wifi member: " + heartbeat.MemberGuid + " Reg Seats: " + heartbeat.RegularSeats);
                DbLogger.Instance().Debug("Grouping: Group: Adding new wifi member: " + heartbeat.MemberGuid + " Reg Seats: " + heartbeat.RegularSeats);
                _members.Add(heartbeat);
            }
        }

        //private void WirelessDirect_ConnectedToGroup(object sender, bool isConnected)
        //{


        //    lock (_groupFlagsLock)
        //    {
        //        _IsTryingToConnect = false;
        //        IsInGroup = isConnected;
        //        IsGroupLeader = false;
        //    }

        //    if (FindOrCreateGroupComplete != null)
        //        FindOrCreateGroupComplete(this, new EventArgs());

        //}

        public void Reset()
        {

            lock (_groupFlagsLock)
            {
                //  _stopTryingToConnect = true;
                //_isGroupFound = false;
                IsGroupLeader = false;
                IsInGroup = false;
                //   _IsTryingToConnect = false;

                _travelRequest = null;
            }
        }

        //private void WirelessDirect_GroupStatusChanged(object sender, GroupStatus e)
        //{
        //    //First see if this is a valid update: if we are just launching the app, and there is leftover device connections,
        //    //we may call this in error.
        //    //if (String.IsNullOrEmpty(_destinationString) && e.IsInGroup)
        //    if (!_wirelessDirect.IsTryingToJoinGroup && !_wirelessDirect.IsTryingToLeadGroup)
        //    {
        //        //_wirelessDirect.Reset();
        //    }
        //    else
        //    {
        //        //do we want/need this? don't we set this in the two handlers in this class (whether or not we found the service) and it's done? why would it change thereafter?
        //        lock (_groupFlagsLock)
        //        {
        //            _isGroupFound = e.IsInGroup;
        //            IsInGroup = e.IsInGroup;
        //            IsGroupLeader = e.IsGroupLeader;
        //        }
        //        if (_wirelessDirect.IsTryingToJoinGroup)
        //        {
        //            //tell WD we are no longer trying to connect
        //            _wirelessDirect.IsTryingToJoinGroup = false;
        //        }
        //        //kg: don't think we should call this here? gz: yes we do.  this refreshes the UI
        //        FindOrCreateGroupComplete?.Invoke(this, new EventArgs());
        //    }
        //}

        //private void WirelessDirect_NumberClientsChanged(object sender, int e)
        //{
        //    //     Logger.Debug(TAG, "Number of Client Changed to " + e.ToString());

        //    if (NumberOfClientsChanged != null)
        //        NumberOfClientsChanged(this, e);

        //}

        //private void WirelessDirect_ServiceFound(object sender, P2pService e)
        //{
        //    if (!_isGroupFound)
        //    {
        //        foreach (var record in e.RecordMap)
        //        {
        //            if (record.Key == "MDEA")
        //            {
        //                Logger.Error(TAG, "MDEA Service Found");
        //                //Grab the destination string from the group that we found already existing.
        //                string theirDestinationString = record.Value;
        //                double theirDestinationLat = Double.Parse(theirDestinationString.Substring(0, theirDestinationString.IndexOf(",")));
        //                double theirDestinationLong = Double.Parse(theirDestinationString.Substring(theirDestinationString.IndexOf(",") + 1));
        //                //Compare to the destination of the trip that this user just requested.
        //                double destinationLat = Double.Parse(_destinationString.Substring(0, _destinationString.IndexOf(",")));
        //                double destinationLong = Double.Parse(_destinationString.Substring(_destinationString.IndexOf(",") + 1));

        //                //The destination's don't have to be exact, just close.  Fuzzy match them to see if they are close enough.
        //                double dist = Conversions.DistanceMeters(theirDestinationLat, theirDestinationLong, destinationLat, destinationLong);

        //                if (dist < 500)
        //                {
        //                    try
        //                    {
        //                        _findOrCreateGroupTimer.Stop();
        //                    }
        //                    catch { }

        //                    _wirelessDirect.StopScanningForServices();

        //                    //We found a group with a close/same destination.
        //                    //Flag that we are in the group, but are a follower.
        //                    lock (_groupFlagsLock)
        //                    {
        //                        _isGroupFound = true;
        //                        IsGroupLeader = false;
        //                        //we are not in the group yet!
        //                        //IsInGroup = true;

        //                    }
        //                    DbLogger.Instance().Debug("Grouping: Found MDEA Group");

        //                    StartConnectionThread(e.DeviceAddress);
        //                    Task.Run(() => ManageMsgsTask_Follower_Run()).LogExceptions(TAG);


        //                }
        //            }
        //        }
        //    }
        //}

        //private void StartConnectionThread(string DeviceAddress)
        //{
        //    Logger.Error(TAG, "In StartConnectionThread");
        //    Task.Run(async () =>
        //    {
        //        bool isInGroupCopy;
        //        bool isTryingToConnectCopy;
        //        bool stopTryingToConnect;

        //        lock (_groupFlagsLock)
        //        {
        //            isInGroupCopy = IsInGroup;
        //            _stopTryingToConnect = false;
        //            stopTryingToConnect = _stopTryingToConnect;
        //        }
        //        //tell WD we are trying to join
        //        _wirelessDirect.IsTryingToJoinGroup = true;
        //        while (!isInGroupCopy && !stopTryingToConnect)
        //        {
        //            lock (_groupFlagsLock)
        //            {
        //                _IsTryingToConnect = true;
        //            }


        //            Logger.Error(TAG, "In StartConnectionThread: connect to " + DeviceAddress);
        //            _wirelessDirect.ConnectToDevice(DeviceAddress);

        //            //Logger.Error(TAG, "In StartConnectionThread: After connect to " + DeviceAddress);

        //            lock (_groupFlagsLock)
        //            {
        //                isTryingToConnectCopy = _IsTryingToConnect;
        //            }
        //            //wait for group connect call to finish
        //            while (isTryingToConnectCopy && !stopTryingToConnect)
        //            {
        //                await Task.Delay(1 * 1000);
        //                lock (_groupFlagsLock)
        //                {
        //                    stopTryingToConnect = _stopTryingToConnect;
        //                    isTryingToConnectCopy = _IsTryingToConnect;
        //                }
        //            }

        //            lock (_groupFlagsLock)
        //            {
        //                isInGroupCopy = IsInGroup;
        //                stopTryingToConnect = _stopTryingToConnect;
        //            }
        //        }

        //    });
        //}

        /// <summary>
        /// In a future version, pickup location would clearly be a defining group param, but for this demo
        /// they need to be standing at pickup location to request, so if in range we assume they are close enough together.
        /// </summary>
        /// <param name="destinationString"></param>
        /// <param name="handicapseats"></param>
        /// <param name="regularseats"></param>
        public void FindOrCreateGroup(Coordinates destinationLoc, Coordinates pickupLoc, int handicapseats, int regularseats, string modeOfTransport, string transitRoute, string transitPickupStop)
        {
            Logger.Debug(TAG, "New trip requested.");
            //Initialize member variables for new trip.
            _pmmCancelRequested = false;

            // _usersPmmRequest = null; //followers don't send pmms

            //Destination string is used as the name of the broadcast service to find passengers to group together.
            //Saved to member variable for comparison to discovered groups.
            _destinationString = destinationLoc.Latitude.ToString() + "," + destinationLoc.Longitude.ToString();
            _handicapSeats = handicapseats;
            _regularSeats = regularseats;


            //!!!!!!!!!!!!!!!!!TEMPORARY till the UI changes happen
            //override to transit
            //modeOfTransport = ModeOfTransportType.transit.ToString();
            //transitRoute = "Medical Center";
            //transitPickupStop = "Buckeye Lot Loop";
            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

            ModeOfTransportType mode;
            if (Enum.TryParse(modeOfTransport, out mode))
            {
                _modeOfTransport = mode;
            }

            _travelRequest = new TravelRequest();
            //Assign new Follower id per trip
            _followerGuid = Guid.NewGuid();
            _travelRequest.FollowerId = _followerGuid;
            _travelRequest.PickupTime = DateTime.UtcNow;

            //Specify these 4 fields for a taxi request
            if (modeOfTransport == ModeOfTransportType.taxi.ToString())
            {
                _travelRequest.TaxiDestLat = destinationLoc.Latitude;
                _travelRequest.TaxiDestLong = destinationLoc.Longitude;
                _travelRequest.TaxiPickupLat = pickupLoc.Latitude;
                _travelRequest.TaxiPickupLong = pickupLoc.Longitude;
            }
            //Specify these two for a Transit request.
            else if (modeOfTransport == ModeOfTransportType.transit.ToString())
            {
                _travelRequest.TransitRoute = transitRoute;
                _travelRequest.TransitPickupStop = transitPickupStop;
            }

            //Going to start looking for groups. Clear out flags.
            lock (_groupFlagsLock)
            {
                //_isGroupFound = false;
                IsGroupLeader = false;
                IsInGroup = false;
            }
            //Create the PMM Request that we will be using for DSRC.
            //Because the PMM DSRC message is not being updated for "transit" we are still going to use the lat/longs of the bus stop locations (the bus
            //stop info only gets loaded into TravelRequest for the cloud to do the grouping).
            _usersPmmRequest = new PmmRequest(new Coordinates(destinationLoc.Latitude, destinationLoc.Longitude), new Coordinates(pickupLoc.Latitude, pickupLoc.Longitude), DateTime.UtcNow, _regularSeats, _handicapSeats, _modeOfTransport);

            Task.Run(() => GetGroupingFromCloud()).LogExceptions(TAG);

            ////Attempt for WifiDirectTimeout seconds to get response from cloud.
            //_findOrCreateGroupTimer = new Timer(TimeSpan.FromSeconds(Settings.WifiDirectTimeout), () =>
            //{
            //    lock (_groupFlagsLock)
            //    {
            //        if (!_isGroupFound || !IsInGroup)//Did WirelessDirect_ServiceFound find a valid matching group and connect to it.
            //        {
            //            //if WD is currently trying to connect then conecntion has failed and must reset
            //            if (_wirelessDirect.IsTryingToJoinGroup == true)
            //            {
            //                Reset();
            //                UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Quit", PmmStatusEventArgs.MsgType.Quit));
            //                return;
            //            }
            //            _wirelessDirect.StopScanningForServices();
            //            //We need to create our own new group.  Set flag to show we are the leader.
            //            IsGroupLeader = true;
            //            IsInGroup = true;

            //            //Group Not Found, Start Broadcasting Service
            //            DbLogger.Instance().Debug("Grouping: Group Not Found, Start Broadcasting Service");

            //            //tell WD we are trying to lead
            //            _wirelessDirect.IsTryingToLeadGroup = true;

            //            _wirelessDirect.BroadcastService(_destinationString);

            //            _usersPmmRequest = new PmmRequest(destinationLoc, pickupLoc, DateTime.UtcNow, _regularSeats, _handicapSeats, _modeOfTransport);

            //            Task.Run(() => ManageMsgsTask_Leader_Run()).LogExceptions(TAG);
            //            if (FindOrCreateGroupComplete != null)
            //                FindOrCreateGroupComplete(this, new EventArgs());
            //        }
            //    }
            //}, true).Start();

        }

        /// <summary>
        /// Ben, there is a lot of commented chaos in here due to the attempts to make the context deadlock on the web api's go away. see email i sent.
        /// </summary>
        /// <returns></returns>
        public async Task<bool> GetGroupingFromCloud()
        {
            try
            {


                //  int retry = 0;
                //  while (retry < 3)
                //  {
                //Task<TravelRequest> sendToCloud3 = _pmManager.SendTravelReqToCloud(_travelRequest);
                DbLogger.Instance().Debug("Grouping: tx: TravelRequest : " + _travelRequest.ToString());

                //Task<TravelRequest> sendToCloud3 = CloudCommunications.SendTravelRequest(_travelRequest);

                //sendToCloud3.LogExceptions(TAG);
                //sendToCloud3.Wait(2000);
                //if (sendToCloud3.Result == null)
                //{
                //    //Error, did not receive response.
                //    DbLogger.Instance().Error("Grouping: Error: SendTravelReqToCloud failed to obtain row id.");
                //    retry++;
                //    if (retry > 2) throw new Exception("Failed to log TravelRequest to cloud after multiple attempts.");
                //}
                //else
                //{
                //    _travelRequest.Id = (int)sendToCloud3.Result.Id;
                //    _travelRequest = sendToCloud3.Result; //save result to keep row id.

                //    break;
                //}

                TravelRequest sendToCloud3 = await CloudCommunications.SendTravelRequest(_travelRequest);
                _travelRequest = sendToCloud3;


                //     }
                //Now we poll the cloud to see if we are a leader or follower
                DateTime startTime = DateTime.Now;
                bool resolved = false;
                while (startTime + TimeSpan.FromSeconds(Settings.WifiDirectTimeout * 2) > DateTime.Now && !resolved)
                {
                    //Task<TravelRequest> pollReq = _pmManager.GetTravelRequestFromCloud((int)_travelRequest.Id);

                    //Task<TravelRequest> pollReq = CloudCommunications.GetTravelRequestStatus((int)_travelRequest.Id);
                    //pollReq.LogExceptions(TAG);
                    //pollReq.Wait(2000);
                    //if (pollReq.Result == null)
                    //{
                    //    //Error, did not receive response.
                    //    DbLogger.Instance().Error("Grouping: Error: GetTravelRequestFromCloud failed to obtain row id.");

                    //}
                    //else
                    //{
                    //    //See if we got grouped
                    //    if (pollReq.Result.GroupId != null)
                    //    {
                    //        // if (FindOrCreateGroupComplete != null)
                    //        //      FindOrCreateGroupComplete(this, new EventArgs());

                    //        resolved = true;
                    //        _isGroupFound = true;
                    //        IsInGroup = true;
                    //        IsGroupLeader = pollReq.Result.IsLeader;
                    //        //Save group id provided by cloud service to our starting pmm request.
                    //        _usersPmmRequest.GroupIdent = (Guid)pollReq.Result.GroupId;
                    //        //Save the updated object
                    //        _travelRequest = pollReq.Result;
                    //        if (IsGroupLeader)
                    //        {
                    //            DbLogger.Instance().Debug("Grouping: Running as leader.");

                    //            //Task.Run(() => ManageMsgsTask_Leader_Run()).LogExceptions(TAG);
                    //            //ManageMsgsTask_Leader_Run();
                    //        }
                    //        else
                    //        {
                    //            DbLogger.Instance().Debug("Grouping: Running as follower");
                    //            // Task.Run(() => ManageMsgsTask_Follower_Run()).LogExceptions(TAG);
                    //            // ManageMsgsTask_Follower_Run();
                    //        }
                    //        break;
                    //    }

                    //}
                    TravelRequest pollReq = await CloudCommunications.GetTravelRequestStatus((int)_travelRequest.Id);

                    //See if we got grouped
                    if (pollReq.GroupId != null) //cloud assigns group id when it processes it.
                    {
                        // if (FindOrCreateGroupComplete != null)
                        //      FindOrCreateGroupComplete(this, new EventArgs());

                        resolved = true;
                        IsInGroup = true;
                        IsGroupLeader = pollReq.IsLeader;
                        //Save group id provided by cloud service to our starting pmm request.
                        _usersPmmRequest.GroupIdent = (Guid)pollReq.GroupId;
                        //Save the updated object
                        _travelRequest = pollReq;
                        if (IsGroupLeader)
                        {
                            DbLogger.Instance().Debug("Grouping: Running as leader. Id=" +_travelRequest.Id);

                            Task.Run(() => ManageMsgsTask_Leader_Run()).LogExceptions(TAG);
                            //ManageMsgsTask_Leader_Run();
                        }
                        else
                        {
                            DbLogger.Instance().Debug("Grouping: Running as follower. Id=" + _travelRequest.Id);
                            Task.Run(() => ManageMsgsTask_Follower_Run()).LogExceptions(TAG);
                            // ManageMsgsTask_Follower_Run();
                        }
                        break;
                    }


                    Task.Delay(1000).Wait();
                }
                if (!resolved)
                {
                    DbLogger.Instance().Debug("Grouping: Grouping never returned grouping result. Check cloud service.");
                    //reset
                    Reset();
                    //Display to user.
                    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Grouping failed", PmmStatusEventArgs.MsgType.Quit));
                    return false;
                }
            }
            catch (Exception ex)
            {
                Logger.Error(TAG, "Termination of Pmm Leader Loop: " + ex.Message + Environment.NewLine + ex.StackTrace);


                //reset
                Reset();
                //Display to user.
                UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Grouping failed", PmmStatusEventArgs.MsgType.Quit));
                return false;
            }
            return true;
        }


        /// <summary>
        /// Thread save save of received pmm message so that the running thread can process it.
        /// </summary>
        /// <param name="pmm"></param>
        public void SavePmm(PMM pmm)
        {
            // lock (_recvPmmsLock)
            // {
            _recvPmms.Enqueue(pmm);
            Logger.Debug(TAG, "Dsrc: Rx: PMM: GUID:" + pmm.PersonalMobilityMessage.groupId + ", Status: " + pmm.PersonalMobilityMessage.status);
            // }
        }
        /// <summary>
        /// Thread-safe save of cancel selection setting so master leader follower threads can use it to quit.
        /// </summary>
        public void SaveCancel()
        {
            lock (_pmmCancelLock)
            {
                _pmmCancelRequested = true;
            }
        }

        /// <summary>
        /// Thread-safe save of a status change to the in vehicle detection status and current gps location.
        /// The wifi group disbands when we enter the vehicle, or when we get too far away.
        /// </summary>
        /// <param name="inVehicle"></param>
        public void SaveStatuses(bool inVehicle, Coordinates currentLocation)
        {
            lock (_pmmStatusesLock)
            {
                _pmmInVehicle = inVehicle;
                _pmmCurrLocation = new Coordinates(currentLocation);
            }
        }



        //public void SendPmmInfoToGroup(PMM pmm)
        //{
        //    if (WirelessDirect.IsGroupOwner)
        //    {
        //        string jsonPmm = JsonConvert.SerializeObject(pmm);

        //        string msg = "$MDEA3," + jsonPmm + "\r\n";

        //        //If we are group owner, we can contact group
        //        DbLogger.Instance().Debug("Sending information to group: " + msg);
        //        WirelessDirect.SendInformation(msg);
        //    }
        //}

        public void Disconnect()
        {
            // _wirelessDirect.Reset();
            //_isGroupFound = false;
        }

        /// <summary>
        /// If we haven't received a response from dsrc after a period of time, we switch to communicate over cloud instead.
        /// </summary>
        /// <returns></returns>
        private bool TimeToAttemptViaCloud()
        {
            if (DateTime.Now > _stopDsrcWindow)
                return true;
            else
                return false;
        }
        /// <summary>
        /// Determines whether or not a new Pmm Request should be attempted over Dsrc.
        /// We always want to prefer dsrc, but if there is no one talking, we go over cloud.
        /// If time for a new window, it sets the time bounds on the window.
        /// </summary>
        /// <param name="lastRequest">The most recent request - e.g. the Last() one in our list.</param>
        /// <param name="previousRequestsStatus">The status of the one prior to this one (e.g. second to Last())</param>
        /// <returns></returns>
        private bool TimeToAttemptViaDsrc(PmmRequestRecord lastRequest, PmmRequestStatus previousRequestsStatus)
        {
            //if this is the first request (reqrd to start over dsrc), or,
            // if the last one we got back over dsrc, or, 
            //If no one answered the last one over dsrc, its kinda pointless to try again right
            //away. Wait a bit before trying dsrc again.
            if (lastRequest.Request.RequestId == 1 ||
                previousRequestsStatus == PmmRequestStatus.ResponseRxDsrc ||
                DateTime.Now > _stopDsrcWindow + _timeBeforeRetryDsrcSetting)
            {
                //set new start and stop times, because it is time to give dsrc another shot.
                _startDsrcWindow = DateTime.Now;
                _stopDsrcWindow = DateTime.Now + new TimeSpan(0, 0, Settings.DsrcTimeout);
                DbLogger.Instance().Debug("Dsrc: Updating window: start " + _startDsrcWindow.ToString() + " stop " + _stopDsrcWindow.ToString());
                Logger.Debug(TAG, "Dsrc: Updating window: start " + _startDsrcWindow.ToString() + " stop " + _stopDsrcWindow.ToString());

                return true;
            }

            //see if we are already inside an active dsrc window attempt
            if (DateTime.Now <= _stopDsrcWindow)
            {
                //If we are still inside a previous window of attempting dsrc, we can try this one
                //too, but we don't want the window extended if no one is out there to answer.
                return true;
            }

            return false;
        }
        private void ManageMsgsTask_Leader_Run()
        {
            try
            {
                UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Requesting ride", PmmStatusEventArgs.MsgType.Unk));
                Logger.Debug(TAG, "Running as Leader");
                //Initialize the leader's member list
                _members = new List<PMGroupMember>();

                DateTime heartbeatsLastChecked = (DateTime)_travelRequest.Time;

                //Initalize the request history list
                List<PmmRequestRecord> requestList = new List<PmmRequestRecord>();

                //We are leader of a new group. Initiate a pmm request for just us.

                requestList.Add(new PmmRequestRecord(_usersPmmRequest));
                _pmManager.SendNewPmmReq(requestList.Last().Request);
                if (UpdateLeaderNotes != null)
                {
                    string s = "Rqst: Dsrc Reg/Hd: " + requestList.Last().Request.RegularSeats + "/" + requestList.Last().Request.HandicappedSeats;
                    UpdateLeaderNotes(this, new PmmStatusEventArgs(s, PmmStatusEventArgs.MsgType.Unk));
                    Logger.Debug(TAG, s);
                }
                requestList.Last().Status = PmmRequestStatus.Pending;
                TimeToAttemptViaDsrc(requestList.Last(), PmmRequestStatus.Pending);//call to set our first dsrc window, previousStatus doesn't apply( set benign).
                // call to set intial psm change (number of travelers represented affects psm size).
                _pmManager.SetTotalNumPedestrians(_usersPmmRequest.RegularSeats, _usersPmmRequest.HandicappedSeats);


                bool gotResponse = false;
                PmmStatusResponse response = null;

                int dbRowToCheckForResp = 0;
                //We stay inside this leader monitoring loop forever, unless we choose to leave/cancel the trip,
                //or, we have gotten inside the vehicle. 
                //TODO: should we enforce that we should first receive Arrive msg??
                bool cancelRequested = false;
                bool cancelComplete = false;
                bool gotInVehicle = false;
                bool gotDSRCResponse = false;
                Coordinates location;
                lock (_pmmCancelLock)
                {
                    cancelRequested = _pmmCancelRequested;
                }
                lock (_pmmStatusesLock)
                {
                    //The trip scheduling/grouping ends when we get in the vehicle.
                    gotInVehicle = _pmmInVehicle;
                    location = new Coordinates(_pmmCurrLocation);
                }
                //Add self as first member.
                _members.Add(new PMGroupMember(_followerGuid, location.Latitude, location.Longitude, _usersPmmRequest.RegularSeats, _usersPmmRequest.HandicappedSeats, _usersPmmRequest.RequestDate));
                _members[0].RequestId = _usersPmmRequest.RequestId;
                _members[0].Status = MemberPmmStatus.Pending;//we already sent the request for ourselves above.
                DbLogger.Instance().Debug("Grouping: Assigned leader Guid: " + _members[0].MemberGuid.ToString());

                while (!cancelComplete && !gotInVehicle)
                {
                    try
                    {
                        //Event leaders now need to routinely send a 'coordination heartbeat' message.  So that they don't dork up future travel requests if it was swiped out or crashed.
                        BuildHeartbeatTokenizedMsg(_followerGuid, location, _regularSeats, _handicapSeats);


                        //Check if we have an update to send
                        if (requestList.Last().Status == PmmRequestStatus.New)
                        {
                            //The latest request has not been sent. Send it.
                            //need status of the PREVIOUS request. guaranteed to exist since we always add the first one above as Pending. 'count-1' index is current
                            PmmRequestStatus prevStatus = requestList[requestList.Count - 2].Status;
                            if (TimeToAttemptViaDsrc(requestList.Last(), prevStatus))
                            {
                                _pmManager.SendUpdatePmmReqToDsrc(requestList.Last().Request);
                                if (UpdateLeaderNotes != null)
                                {
                                    string s = "Rqst: Dsrc Reg/Hd: " + requestList.Last().Request.RegularSeats + "/" + requestList.Last().Request.HandicappedSeats;
                                    UpdateLeaderNotes(this, new PmmStatusEventArgs(s, PmmStatusEventArgs.MsgType.Unk));
                                    Logger.Debug(TAG, s);
                                }
                            }
                            requestList.Last().Status = PmmRequestStatus.Pending;
                            gotResponse = false;
                            response = null;//clear out response.
                            dbRowToCheckForResp = 0;//clear out web api row to check.


                        }

                        //Check if any new pmm messages have been recieved.
                        PMM pmmCopy = null;
                        gotDSRCResponse = false;
                        //loop through PMM queue until we find an unprocessed response
                        //process arrived messages in loop but dont exit
                        while (_recvPmms.TryDequeue(out pmmCopy) && !gotDSRCResponse)
                        {
                            //Check the response
                            if (IsThisOurResponse(pmmCopy, requestList))
                            {
                                //See if it is a response we've already received.
                                if (!HasPmmResponseAlreadyBeenProcessed(requestList, pmmCopy))
                                {
                                    //We got our response. Cancel the DSRC message streaming.
                                    _pmManager.CancelDsrcSendPmm();
                                    gotResponse = true;
                                    response = StorePmmResponse(pmmCopy, requestList);
                                    gotDSRCResponse = true;
                                }
                            }
                            else if (IsThisOurArrive(pmmCopy, requestList))
                            {
                                //Notify self
                                string arrivalMsg = "Ride Arrived - "
                                    + pmmCopy.PersonalMobilityMessage.vehicleDesc;
                                UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs(arrivalMsg, PmmStatusEventArgs.MsgType.Arrived));

                                //Notify rest of group.
                                BuildArrivedTokenizedMsg(arrivalMsg); //followers wont have MsgType set, only the string status, but HomePage doesn't use it for Arrived. 

                            }
                        }

                        //Check for responses from pmm Requests.
                        //If we have not yet gotten a response over dsrc, see if we can/have over cloud.
                        if (!gotResponse)
                        {
                            //We haven't received a response.  See if our Dsrc attempt window has expired.
                            if (TimeToAttemptViaCloud())
                            {
                                //The time window elapsed and we have not received a response to our request.  Send the request to the cloud.
                                //See if we've already loaded our request to the web api.
                                if (dbRowToCheckForResp == 0)
                                {
                                    //Stop attempting over dsrc. Use webapi instead.
                                    _pmManager.CancelDsrcSendPmm();

                                    if (UpdateLeaderNotes != null)
                                    {
                                        string s = "Rqst: Cloud Reg/Hd: " + requestList.Last().Request.RegularSeats + "/" + requestList.Last().Request.HandicappedSeats;
                                        UpdateLeaderNotes(this, new PmmStatusEventArgs(s, PmmStatusEventArgs.MsgType.Unk));
                                        Logger.Debug(TAG, s);
                                    }

                                    Task<PmmRequest> sendToCloud = _pmManager.SendPmmReqToCloud(requestList.Last().Request);
                                    sendToCloud.LogExceptions(TAG);
                                    sendToCloud.Wait();
                                    if (sendToCloud.Result == null)
                                    {
                                        //Error, did not receive response.
                                        DbLogger.Instance().Error("Grouping: Error: SendPmmReqToCloud failed to obtain row id.");
                                    }
                                    else
                                    {
                                        //Save the  database row id to check for responses.
                                        dbRowToCheckForResp = (int)sendToCloud.Result.Id;
                                        requestList.Last().Request = sendToCloud.Result; //save result to keep row id.

                                        //Check to make sure this wasn't a final cancellation. If so, now that we've logged it to the cloud,
                                        //we don't need to wait for confirmation (unlike with DSRC).
                                        if (sendToCloud.Result.RegularSeats == 0 && sendToCloud.Result.HandicappedSeats == 0)
                                        {
                                            cancelComplete = true;
                                        }
                                    }
                                }

                                if (dbRowToCheckForResp != 0)//if we have succesfully put our request out on the cloud
                                {
                                    //periodically check to see if we got a response yet from a bus.
                                    try
                                    {
                                        Task<PmmStatusResponse> getFromCloud = _pmManager.GetPmmResponseFromCloud(dbRowToCheckForResp);
                                        getFromCloud.LogExceptions(TAG);
                                        getFromCloud.Wait();
                                        if (getFromCloud.Result != null)//If no one got back to us yet, it will stay null.
                                        {
                                            gotResponse = true;
                                            response = StorePmmResponse((int)requestList.Last().Request.RequestId, getFromCloud.Result, requestList);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        Logger.Error(TAG, "Exception in Pmm Leader getFromCloud: " + ex.Message + Environment.NewLine + ex.StackTrace);
                                    }
                                }
                            }
                        }

                        //We need to process this reponse and Accept whatever members were accepted and let them know.
                        if (gotResponse && response != null)//todo do we need gotResponse at all now?
                        {
                            if (UpdateLeaderNotes != null)
                            {
                                string s = "Resp: " + requestList.Last().Status.ToString() + " Reg/Hd: " + response.TotalRegSeatsAccptd + "/" + response.TotalHandicapSeatsAccptd;
                                UpdateLeaderNotes(this, new PmmStatusEventArgs(s, PmmStatusEventArgs.MsgType.Unk));
                                Logger.Debug(TAG, s);
                            }

                            int previousAcceptedRegSeats = TallyRequestsForRegSeats();
                            int previousAcceptedHcapSeats = TallyRequestsForHcapSeats();
                            //The difference between the last accepted number of seats, and this response's number
                            //of seats, is the new number approved.
                            int newRegSpotsAvl = response.TotalRegSeatsAccptd - previousAcceptedRegSeats;
                            int newHcapSpotsAvl = response.TotalHandicapSeatsAccptd - previousAcceptedHcapSeats;
                            //Figure out which pending members were accepted with this response
                            //If the member is pending, they may have been accepted in this response
                            foreach (PMGroupMember m in _members.Where(m => m.Status == MemberPmmStatus.Pending))
                            {
                                //See if this pending member was included in this request.
                                //If the response is to a request id greater than the member's id, then it is inclusive.
                                if (response.PmmRequestId >= m.RequestId)
                                {
                                    //if the seats requested for this member fits in the spots available.
                                    if (newRegSpotsAvl >= m.RegularSeats && newHcapSpotsAvl >= m.HandicappedSeats)
                                    {
                                        //Take the seats.  Set status to Accepted and notify.
                                        m.Status = MemberPmmStatus.Accepted;
                                        if (_members.First() == m)//m member is leader, first member
                                        {
                                            if (UpdateGroupStatus != null)
                                                UpdateGroupStatus(this, new PmmStatusEventArgs("Accepted", PmmStatusEventArgs.MsgType.Accepted));
                                        }
                                        else//m member is follower
                                        {
                                            BuildFollowerUpdateTokenizedMsg(m.MemberGuid, PmmStatusEventArgs.MsgType.Accepted);
                                        }
                                        //reduce the amound avl for the next pending member accordingly.
                                        newRegSpotsAvl -= m.RegularSeats;
                                        newHcapSpotsAvl -= m.HandicappedSeats;
                                    }
                                    else//if the requestId indicates this request was inclusive of this request, then they didn't fit.
                                    {
                                        //reject them.
                                        m.Status = MemberPmmStatus.Rejected;
                                        //if (_members.First() == m)//m member is leader, first member
                                        //{
                                        //   if (UpdateGroupStatus != null)
                                        //        UpdateGroupStatus(this, new PmmStatusEventArgs("Rejected", PmmStatusEventArgs.MsgType.Rejected));
                                        //TODO: what do we do if the leader is rejected?
                                        //I guess we just would wait for some other VEA to accept us? We'd have to renew the request by setting m.Status back to New. but the Request Id would be upped.
                                        //OR we program the VEA to NOT reject a Request Id of 1 - it really doesn't make sense anyway, if
                                        //they can't pick us up, then they should simply NOT respond. Again this gets into differences between buses and
                                        //taxis and is out of scope: if 20 taxis were in the city, we wouldn't want 19 of them to say "no". but if it was
                                        //one nearby bus route being targeted, then a no would be useful.
                                        // }
                                        //else//m member is follower
                                        //{
                                        BuildFollowerUpdateTokenizedMsg(m.MemberGuid, PmmStatusEventArgs.MsgType.Rejected);
                                        // }
                                    }
                                }
                            }
                            //See JIRA: Partial Rejection Mismatch
                            //At this point, newRegSpotsAvl should really be 0. If not, it may mean we rejected someone because
                            //they didn't fully fit, thus now the bus is reserving more than it ought to.  
                            //Send some new message to address this? - out of scope for demo i think.  maybe we don't care if we reserved too many.
                            //12/9 addressed by any rejection being deleted and another update being sent.
                        }

                        //Check on members

                        //Receive and load all latest member messages from the queue.
                        //string memMsg;
                        //while (_msgsFromWifi.TryDequeue(out memMsg))
                        //{
                        //    //Process new message
                        //    string[] tokens = memMsg.Split(",".ToCharArray());
                        //    //until we fix the receive to not get garbled and spliced messages, make sure we have a whole one:
                        //    if (tokens.Length == 6)
                        //    {
                        //        if (tokens[0] == HeartbeatMessageToken)
                        //        {
                        //            //This is a heartbeat message, if we are leader we use this to build and maintain our member list.
                        //            PMGroupMember heartbeat = new PMGroupMember(tokens);
                        //            RecordHeartbeatToMemberList(heartbeat);
                        //        }
                        //    }
                        //}

                        DateTime heartbeatNewTime = DateTime.UtcNow - new TimeSpan(0, 0, 10);
                        try
                        {
                            //Even leaders send heartbeats now. Append leaders Id in order to exclude leader heartbeats from being returned.
                            Task<List<Heartbeat>> heartbeats = CloudCommunications.GetNewHeartbeats(heartbeatsLastChecked, (Guid)_travelRequest.GroupId, _followerGuid);
                            heartbeats.LogExceptions(TAG);
                            if (heartbeats.Wait(2000))
                            {
                                if (heartbeats.Result != null)
                                {
                                    foreach (var h in heartbeats.Result)
                                    {
                                        PMGroupMember heartbeatMsg = new PMGroupMember(h.FollowerId, h.Latitude, h.Longitude, h.RegSeats, h.HcapSeats, h.Time);
                                        RecordHeartbeatToMemberList(heartbeatMsg);
                                    }
                                }
                                if (heartbeats.Result.Count > 0)
                                {
                                    Logger.Debug(TAG, "Grouping: Rx:  " + heartbeats.Result.Count + " heartbeats. Id " + heartbeats.Result.First().Id + " through " + heartbeats.Result.Last().Id);
                                    DbLogger.Instance().Debug("Grouping: Rx: " + heartbeats.Result.Count + " heartbeats. Id " + heartbeats.Result.First().Id + " through " + heartbeats.Result.Last().Id);
                                    heartbeatsLastChecked = heartbeats.Result.Last().Time;  //this way grabs minimal when active, but always grabs the last message over and over when there are none. (web api uses >= in case another message came in at the ~same time)
                                    //heartbeatsLastChecked = heartbeatNewTime;  //this way when follower cancels and there are no msg, this allows 0 msgs, but grabs extra when active due to the slop. (slop due to maybe a time mismatch to webapi?)
                                    //TODO future work: both of the two previous line options are wasteful of bandwidth in different ways.  Figure out a better way to not miss messages but not waste bw.
                                }
                                else
                                {
                                    Logger.Debug(TAG, "Grouping: Rx: " + heartbeats.Result.Count + " heartbeats. Time " + heartbeatsLastChecked + " . new time " + heartbeatNewTime);
                                    DbLogger.Instance().Debug("Grouping: Rx: " + heartbeats.Result.Count + " heartbeats. Time " + heartbeatsLastChecked + " . new time " + heartbeatNewTime);
                                    //Save current time, but with some slop
                                    heartbeatsLastChecked = heartbeatNewTime;
                                }
                                //  heartbeatsLastChecked = heartbeatNewTime;//this simplistic attempt was missing some.
                            }
                            else Logger.Error(TAG, "Grouping: Rx: CloudCommunications.GetNewHeartbeats did not receive response in time.");
                        }
                        catch (Exception ex)
                        {
                            Logger.Error(TAG, "Exception in Pmm Leader GetNewHeartbeats: " + ex.Message + Environment.NewLine + ex.StackTrace);
                        }



                        //Iterate over all member timestamps and see if any have not provided the heartbeat within the
                        //specified window.  If not, set their status to Expired to remove them from the group and notify them.
                        foreach (var m in _members.Skip(1).Where(m => m.Status != MemberPmmStatus.Deleted)) //member 0 is leader, who can't expire. skip him.
                        {
                            if ((DateTime.UtcNow - m.LastUpdate).TotalSeconds >= _heartbeatExpirationInSecondsSetting && m.Status != MemberPmmStatus.Deleted)
                            {
                                m.Status = MemberPmmStatus.Expired;
                                //We are cancelling this traveler. let them know.
                                BuildFollowerUpdateTokenizedMsg(m.MemberGuid, PmmStatusEventArgs.MsgType.Cancelled);
                            }
                        }
                        //Iterate over all member locations and see if they have wandered too far from pickup location.
                        //If so, set their status to Left to remove them from the group and notify them.
                        //update leader (member[0] location too)
                        //never check for leader wandering away
                        _members[0].MemberLat = location.Latitude;
                        _members[0].MemberLong = location.Longitude;
                        foreach (var m in _members.Skip(1))
                        {
                            if (Conversions.DistanceMeters(m.MemberLat, m.MemberLong, (double)_usersPmmRequest.PickupLatitude, (double)_usersPmmRequest.PickupLongitude)
                                >= _distanceFromPickupForLeavingGroupInMetersSetting && m.Status != MemberPmmStatus.Deleted)
                            {
                                m.Status = MemberPmmStatus.Left;
                                //We are cancelling this traveler. let them know.
                                BuildFollowerUpdateTokenizedMsg(m.MemberGuid, PmmStatusEventArgs.MsgType.Cancelled);
                            }
                        }

                        //check for leader wandering away
                        if (Conversions.DistanceMeters(_members[0].MemberLat, _members[0].MemberLong, (double)_usersPmmRequest.PickupLatitude, (double)_usersPmmRequest.PickupLongitude)
                                >= _distanceFromPickupForLeavingGroupInMetersSetting)
                        {
                            lock (_pmmCancelLock)
                            {
                                _pmmCancelRequested = true;
                            }
                        }

                        //Iterate over the member list and build a new Pmm based on the last one. With incremented RequestId.
                        //For all New members,  update their status to Pending. Save RequestId.
                        //For all expired, quit, etc., update them to deleted so that they are subtracted from the total.
                        int nextRequestId = requestList.Last().Request.RequestId + 1;


                        bool haveUpdate = false;
                        foreach (PMGroupMember m in _members)
                        {
                            if (m.Status == MemberPmmStatus.New)
                            {
                                //Update their status to being included in a request.
                                m.Status = MemberPmmStatus.Pending;
                                m.RequestId = nextRequestId;
                                haveUpdate = true;
                            }
                            if (m.Status == MemberPmmStatus.Quit || m.Status == MemberPmmStatus.Left ||
                                m.Status == MemberPmmStatus.Expired || m.Status == MemberPmmStatus.Rejected)
                            {
                                Logger.Warning(TAG, "Grouping: Group: Deleting Member. Status: " + m.Status + " Guid: " + m.MemberGuid.ToString() + " Reg Seats: " + m.RegularSeats);
                                DbLogger.Instance().Debug("Grouping: Group: Deleting Member. Status: " + m.Status + " Guid: " + m.MemberGuid.ToString() + " Reg Seats: " + m.RegularSeats);
                                //Update their removed status to being included in a request.
                                m.Status = MemberPmmStatus.Deleted;
                                m.RequestId = nextRequestId;
                                haveUpdate = true;
                            }
                        }

                        if (haveUpdate)
                        {
                            //Add all members that are new, pending or accepted.
                            int totalRegSeats = TallyRequestsForRegSeats(false);
                            int totalHcapSeats = TallyRequestsForHcapSeats(false);
                            _pmManager.SetTotalNumPedestrians(totalRegSeats, totalHcapSeats);

                            //Save Pmm Update to list so that it is sent out.
                            PmmRequest updatedReq = new PmmRequest(nextRequestId,
                                totalRegSeats, totalHcapSeats, requestList.First().Request);
                            requestList.Add(new PmmRequestRecord(updatedReq));

                            int countDev = 0;
                            //count devices that are active
                            foreach (PMGroupMember m in _members)
                            {
                                if (m.Status == MemberPmmStatus.Pending || m.Status == MemberPmmStatus.Accepted)
                                {
                                    countDev++;
                                }
                            }
                            //if (countDev >= _maxWifiDevicesSetting)
                            //{
                            //    //If we have already maxed the number of wifi devices for this group,
                            //    //stop broadcasting the service so that we don't get any more members and they will form their own groups.
                            //    Logger.Warning(TAG, "Grouping: Group: Stop broadcasting. Reached max members " + _maxWifiDevicesSetting);
                            //    DbLogger.Instance().Debug("Grouping: Group: Stop broadcasting. Reached max members " + _maxWifiDevicesSetting);
                            //    _wirelessDirect.JustStopBroadcastingService();
                            //}
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Error(TAG, "Exception in Pmm Leader Loop: " + ex.Message + Environment.NewLine + ex.StackTrace);
                    }
                    //Update variables used to quit the loop
                    lock (_pmmCancelLock)
                    {
                        cancelRequested = _pmmCancelRequested;

                    }
                    if (cancelRequested) //if cancel tapped or leader wanders out of range
                    {
                        //Set all members to cancel so that the next time through the loop, a request will be generated with 0 requested seats.
                        foreach (var m in _members)
                        {
                            if (m.Status == MemberPmmStatus.New || m.Status == MemberPmmStatus.Pending || m.Status == MemberPmmStatus.Accepted)
                            {
                                m.Status = MemberPmmStatus.Quit;
                                if (m == _members.First())
                                {
                                    //Give the user some feedback that we got their input, even though since we are leader we can't quit immediately/
                                    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Cancelling", PmmStatusEventArgs.MsgType.Cancelling));
                                }
                            }
                        }

                        //Next time through the loop, confirm a new request will be made.
                        //I don't think we have to actually track that specific request id, we can just wait till we
                        //get a response that confirms 0 total seats.
                        if (gotResponse && response != null)
                        {
                            if (response.TotalHandicapSeatsAccptd == 0 && response.TotalRegSeatsAccptd == 0)
                            {
                                //we got confirmation (over DSRC) of our cancellation, now we can really quit the loop.
                                cancelComplete = true;
                            }
                        }

                    }
                    lock (_pmmStatusesLock)
                    {
                        //The trip scheduling/grouping ends when we get in the vehicle.
                        gotInVehicle = _pmmInVehicle;
                        location = new Coordinates(_pmmCurrLocation);
                    }
                    // gotResponse = false; //We've processed the response, clear the flag.
                    response = null;
                    Task.Delay(100).Wait();
                }

                if (cancelRequested)
                {
                    //Let all others know we've quit. This demo doesn't address finding a new leader.
                    BuildBroadcastTokenizedMsg(PmmStatusEventArgs.MsgType.Cancelled);
                    //brief wait to deal with improbable timing case
                    //Task.Delay(100).Wait();
                    //wait for next message send interval to finish
                    //_msgsToWifiSent.Reset();
                    // _msgsToWifiSent.WaitOne();
                    //wait for sends to flush
                    // Task.Delay(1000).Wait();
                    //reset
                    Reset();
                    //Update GUI
                    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Cancelled", PmmStatusEventArgs.MsgType.Cancelled));
                }
                if (gotInVehicle)
                {
                    BuildBroadcastTokenizedMsg(PmmStatusEventArgs.MsgType.Complete);
                    //brief wait to deal with improbable timing case
                    // Task.Delay(100).Wait();
                    //wait for next message send interval to finish
                    //_msgsToWifiSent.Reset();
                    //_msgsToWifiSent.WaitOne();
                    //wait for sends to flush
                    // Task.Delay(1000).Wait();
                    //reset
                    Reset();
                    //Update GUI
                    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Complete", PmmStatusEventArgs.MsgType.Complete));
                }
                // Task.Delay(30000).Wait();
                //The trip has been ended or completed. End the group.
                //Disband group - Disconnect will end the service too if we are the leader.
                //Task.Delay(10000).Wait();//test waiting, cancel not being rxed by follower.

                Logger.Debug(TAG, "Trip End (leader). CancelFlag:" + cancelComplete + " vehFlag:" + gotInVehicle);
            }
            catch (Exception ex)
            {
                Logger.Error(TAG, "Termination of Pmm Leader Loop: " + ex.Message + Environment.NewLine + ex.StackTrace);
                //reset
                Reset();
            }
            //Ensure that no matter how we left this thread, that we've turned off dsrc.
            _pmManager.CancelDsrcSendPmm();
            _pmManager.SetTotalNumPedestrians(1, 0);//restore default psm protection level.

            _travelRequest = null;
        }



        /// <summary>
        /// Returns true if we've already received a response for this request.
        /// </summary>
        /// <param name="requestList"></param>
        /// <param name="pmmCopy"></param>
        /// <returns></returns>
        private bool HasPmmResponseAlreadyBeenProcessed(List<PmmRequestRecord> requestList, PMM pmmCopy)
        {
            int requestIdOfResponse = Convert.ToInt32(pmmCopy.PersonalMobilityMessage.requestId);
            //Find request in list.
            foreach (var r in requestList)
            {
                if (r.Request.RequestId == requestIdOfResponse)
                {
                    //Found this request, see if the response is null (== not yet received & processed).
                    if (r.Response == null)
                    {
                        return false;
                    }
                    else return true; //Response is a valid object, so we already got the response for this request.

                }
            }
            DbLogger.Instance().Error("Grouping: Error: Response received for Request Id not in list. id: " + requestIdOfResponse);
            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="onlyCoundAccepted">If true, counts returned are only for accepted members.
        /// If false, Count returned includes Accepted, New and Pending members.</param>
        /// <returns></returns>
        private int TallyRequestsForRegSeats(bool onlyCoundAccepted = true)
        {
            int total = 0;
            foreach (var m in _members)
            {
                if (m.Status == MemberPmmStatus.Accepted) total += m.RegularSeats;
                //only include new and pending if the param was false.
                else if (m.Status == MemberPmmStatus.New && !onlyCoundAccepted) total += m.RegularSeats;
                else if (m.Status == MemberPmmStatus.Pending && !onlyCoundAccepted) total += m.RegularSeats;
            }
            return total;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="onlyCoundAccepted">If true, counts returned are only for accepted members.
        /// If false, Count returned includes Accepted, New and Pending members.</param>
        /// <returns></returns>
        private int TallyRequestsForHcapSeats(bool onlyCoundAccepted = true)
        {
            int total = 0;
            foreach (var m in _members)
            {
                if (m.Status == MemberPmmStatus.Accepted) total += m.HandicappedSeats;
                else if (m.Status == MemberPmmStatus.New && !onlyCoundAccepted) total += m.HandicappedSeats;
                else if (m.Status == MemberPmmStatus.Pending && !onlyCoundAccepted) total += m.HandicappedSeats;
            }
            return total;
        }

        /// <summary>
        /// Finds the matching request for this response and stores it in the list.
        /// </summary>
        /// <param name="response"></param>
        /// <param name="isFromCloud">defaults to true if the response came from the cloud. false if from dsrc.</param>
        public PmmStatusResponse StorePmmResponse(int requestId, PmmStatusResponse response, List<PmmRequestRecord> requests,
            bool isFromCloud = true)
        {
            //Find the request that this response is for.
            foreach (var r in requests) //todo efficiency: if we searched backwards we'd likely find it right away.
            {
                if (r.Request.RequestId == requestId)
                {
                    //This response pairs with this request. store it.
                    r.Response = response;
                    if (isFromCloud) r.Status = PmmRequestStatus.ResponseRxCloud;
                    else r.Status = PmmRequestStatus.ResponseRxDsrc;
                    break;
                }

            }
            return response;//no different than input, added for consistency with other function
        }
        /// <summary>
        /// Finds the matching request for this response and stores it in the list.
        /// </summary>
        public PmmStatusResponse StorePmmResponse(PMM dsrcResponse, List<PmmRequestRecord> requests)
        {
            //Parse the dsrc response into our type.
            PmmStatusResponse response = new PmmStatusResponse();
            response.Id = -1; //dsrc responses did not come through the database.
            response.PmmRequestId = Convert.ToInt32(dsrcResponse.PersonalMobilityMessage.requestId);
            response.VehicleIdent = dsrcResponse.PersonalMobilityMessage.vehicleDesc;

            foreach (var m in dsrcResponse.PersonalMobilityMessage.mobilityNeeds)
            {
                MobilityNeedsType type = (MobilityNeedsType)Enum.Parse(typeof(MobilityNeedsType), m.type);
                if (type == MobilityNeedsType.noSpecialNeeds)//regular
                {
                    response.TotalRegSeatsAccptd = Convert.ToInt32(m.count);
                }
                else if (type == MobilityNeedsType.wheelchair)//handicapped
                {
                    response.TotalHandicapSeatsAccptd = Convert.ToInt32(m.count);
                }
            }
            //Match and store response.
            StorePmmResponse(Convert.ToInt32(dsrcResponse.PersonalMobilityMessage.requestId), response, requests, false);
            return response;
        }

        /// <summary>
        /// Confirms the Group Id of the response is our Group Id.
        /// </summary>
        /// <param name="pmm"></param>
        /// <param name="requests"></param>
        /// <returns></returns>
        public bool IsThisOurDsrcMsg(PMM pmm, List<PmmRequestRecord> requests)
        {
            if (requests.First().Request.GroupIdent == null)
            {
                //TODO log
                //We shouldn't even be calling this and receiving pmm's if we're not leader and don't have a group id.
                return false;
            }
            //Confirm the Group Id indicates that this is OUR reponse/arrive
            if (pmm.PersonalMobilityMessage.groupId == requests.First().Request.GroupIdent.ToString())
            {
                return true;
            }
            else return false;
        }
        /// <summary>
        /// Checks if the Group id and message type indicates it is a response to our pmm request.
        /// </summary>
        /// <param name="pmm"></param>
        /// <param name="requests"></param>
        /// <returns></returns>
        public bool IsThisOurResponse(PMM pmm, List<PmmRequestRecord> requests)
        {
            //See if the Group id is correct.
            if (IsThisOurDsrcMsg(pmm, requests))
            {
                //See if this pmm is 1. A reponse type 
                if (pmm.PersonalMobilityMessage.status == PmmType.response.ToString())
                {
                    //todo confirm request id too - this could be a response for request 2 when we just started sending request 3.
                    return true;

                }


            }
            return false;
        }
        public bool IsThisOurArrive(PMM pmm, List<PmmRequestRecord> requests)
        {
            if (IsThisOurDsrcMsg(pmm, requests))
            {
                if (pmm.PersonalMobilityMessage.status == PmmType.arrival.ToString())
                {
                    return true;
                }

            }
            return false;
        }

        private void ManageMsgsTask_Follower_Run()
        {
            try
            {
                UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Requesting ride", PmmStatusEventArgs.MsgType.Unk));
                Logger.Debug(TAG, "Running as Follower");
                _members = null; //folowers don't track members.

                DateTime msgLastChecked = (DateTime)_travelRequest.Time;

                //check for successful group connection
                //DateTime startTime = DateTime.Now;
                //while ((!IsInGroup || !_wirelessDirect.GotConnectionInfo) && (DateTime.Now - startTime).TotalSeconds < Settings.WifiDirectTimeout)
                //{
                //    Task.Delay(500).Wait();
                //}
                //if (!IsInGroup || !_wirelessDirect.GotConnectionInfo)
                //{
                //    //reset
                //    Reset();
                //    //Display to user.
                //    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Quit", PmmStatusEventArgs.MsgType.Quit));
                //    return;
                //}

                //We stay inside this follower monitoring loop forever, unless we choose to leave/cancel the trip,
                //or, we have gotten inside the vehicle. 
                //TODO: should we enforce that we should first receive Arrive msg??
                //TODO: should the vehicle state NOT matter for follower and instead only quit on a message from the leader?
                bool cancelRequested = false; //elected by user
                bool gotInVehicle = false; //comes from SafetyMon/HomePage
                bool rejected = false;//comes from leader.
                bool gettingUpdates = false;
                DateTime lastRequestSentTime = DateTime.UtcNow;
                Task<List<LeaderUpdate>> leaderUpdates = null;
                Coordinates location;
                int lastUpdateId = 0;
                LeaderUpdate lastUpdate;
                lock (_pmmCancelLock)
                {
                    cancelRequested = _pmmCancelRequested;
                }
                lock (_pmmStatusesLock)
                {
                    //The trip scheduling/grouping ends when we get in the vehicle.
                    gotInVehicle = _pmmInVehicle;
                    location = new Coordinates(_pmmCurrLocation);
                }
                //As a follower, I assign myself a Guid so that the leader knows all my messages are from me.
                //Guid followerGuid = Guid.NewGuid();
                DbLogger.Instance().Debug("Grouping: Assigned follower Guid: " + _followerGuid.ToString());
                while (!cancelRequested && !gotInVehicle && !rejected)// && !_wirelessDirect.SocketError)
                {
                    try
                    {
                        //Need to routinely send a 'coordination heartbeat' message.
                        BuildHeartbeatTokenizedMsg(_followerGuid, location, _regularSeats, _handicapSeats);

                        //Receive and load all latest member messages from the queue.
                        try
                        {
                            if (!gettingUpdates)
                            {
                                //start task to read leader updates
                                gettingUpdates = true;
                                lastRequestSentTime = DateTime.UtcNow;
                                leaderUpdates = CloudCommunications.GetNewLeaderUpdates(DateTime.MinValue, (Guid)_travelRequest.GroupId, _followerGuid);
                                leaderUpdates.LogExceptions(TAG);
                            }
                            else
                            {
                                if (leaderUpdates.IsCompleted)
                                {
                                    gettingUpdates = false;
                                    msgLastChecked = lastRequestSentTime;
                                    if (leaderUpdates.Result != null)
                                    {
                                        lastUpdate = leaderUpdates.Result.Last();
                                        if (lastUpdate.Id > lastUpdateId)
                                        {
                                            lastUpdateId = lastUpdate.Id;
                                            Logger.Debug(TAG, "Grouping: Rx: LeaderUpdate " + lastUpdate.ToString());
                                            DbLogger.Instance().Debug("Grouping: Rx: LeaderUpdate " + lastUpdate.ToString());
                                            //This is a broadcast message from the leader to all.
                                            if (lastUpdate.FollowerId == null)
                                            {

                                                PmmStatusEventArgs updateToAll = new PmmStatusEventArgs(lastUpdate.Message, lastUpdate.Message);
                                                //The leader cancelled the trip. finding a new leader is not supported in this prototype.
                                                if (updateToAll.MessageType == PmmStatusEventArgs.MsgType.Cancelled)
                                                {
                                                    rejected = true;//use the rejected flag to quit the loop.
                                                }
                                                else
                                                {
                                                    //group message to all: e.g. ride Arrived
                                                    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs(lastUpdate.Message, lastUpdate.Message));
                                                }
                                            }
                                            else//This is a message to only one follower
                                            {

                                                if (_followerGuid == lastUpdate.FollowerId)//compare message to my guid
                                                {
                                                    //This message is to me.
                                                    PmmStatusEventArgs myUpdate = new PmmStatusEventArgs(lastUpdate.Message, lastUpdate.Message);
                                                    UpdateGroupStatus?.Invoke(this, myUpdate);
                                                    //todo:: does the software need to track when we are accepted? Don't think it really matters except to UI.

                                                    //If we got rejected , we need to quit.
                                                    if (myUpdate.MessageType == PmmStatusEventArgs.MsgType.Rejected)
                                                    {
                                                        rejected = true;
                                                    }
                                                    //The leader cancelled the trip for me (either expiration or distance from pickup)
                                                    if (myUpdate.MessageType == PmmStatusEventArgs.MsgType.Cancelled)
                                                    {
                                                        rejected = true;//use the rejected flag to quit the loop.
                                                    }

                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.Error(TAG, "Exception in Pmm Leader GetNewHeartbeats: " + ex.Message + Environment.NewLine + ex.StackTrace);
                            gettingUpdates = false;
                        }




                        //while (_msgsFromWifi.TryDequeue(out memMsg))
                        //{
                        //    //Process new message
                        //    string[] tokens = memMsg.Split(",".ToCharArray());
                        //    if (tokens[0] == FollowerStatusToken)
                        //    {
                        //        //This is a follower update, 
                        //        string guid = tokens[1];
                        //        //This is a broadcast message from the leader to all.
                        //        if (guid == "0")
                        //        {

                        //            PmmStatusEventArgs updateToAll = new PmmStatusEventArgs(tokens[2], tokens[2]);
                        //            //The leader cancelled the trip. finding a new leader is not supported in this prototype.
                        //            if (updateToAll.MessageType == PmmStatusEventArgs.MsgType.Cancelled)
                        //            {
                        //                rejected = true;//use the rejected flag to quit the loop.
                        //            }
                        //            else
                        //            {
                        //                //group message to all: e.g. ride Arrived
                        //                UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs(tokens[2], tokens[2]));
                        //            }
                        //        }
                        //        else//This is a message to only one follower
                        //        {
                        //            Guid msgGuid = new Guid(guid);
                        //            if (_followerGuid == msgGuid)//compare message to my guid
                        //            {
                        //                //This message is to me.
                        //                PmmStatusEventArgs myUpdate = new PmmStatusEventArgs(tokens[2], tokens[2]);
                        //                UpdateGroupStatus?.Invoke(this, myUpdate);
                        //                //todo:: does the software need to track when we are accepted? Don't think it really matters except to UI.

                        //                //If we got rejected , we need to quit.
                        //                if (myUpdate.MessageType == PmmStatusEventArgs.MsgType.Rejected)
                        //                {
                        //                    rejected = true;
                        //                }
                        //                //The leader cancelled the trip for me (either expiration or distance from pickup)
                        //                if (myUpdate.MessageType == PmmStatusEventArgs.MsgType.Cancelled)
                        //                {
                        //                    rejected = true;//use the rejected flag to quit the loop.
                        //                }

                        //            }
                        //        }


                        //    }
                        //}

                        //As a follower, we don't have as much to do. let's sleep
                        Task.Delay(1000).Wait();

                    }
                    catch (Exception ex)
                    {
                        Logger.Error(TAG, "Exception in Pmm Follower Loop: " + ex.Message + Environment.NewLine + ex.StackTrace);
                    }
                    //Update variables used to quit the loop
                    lock (_pmmCancelLock)
                    {
                        cancelRequested = _pmmCancelRequested;
                    }
                    lock (_pmmStatusesLock)
                    {
                        //The trip scheduling/grouping ends when we get in the vehicle.
                        gotInVehicle = _pmmInVehicle;
                        location = new Coordinates(_pmmCurrLocation);
                    }
                }
                if (cancelRequested)
                {
                    //Inform the leader we left the group by sending 0 requested seats.
                    BuildHeartbeatTokenizedMsg(_followerGuid, location, 0, 0);
                    //brief wait to deal with improbable timing case
                    //Task.Delay(100).Wait();
                    ////wait for next message send interval to finish
                    //_msgsToWifiSent.Reset();
                    //_msgsToWifiSent.WaitOne();
                    ////wait for sends to flush
                    //Task.Delay(1000).Wait();
                    //reset
                    Reset();
                    //Display to user.
                    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Cancelled", PmmStatusEventArgs.MsgType.Cancelled));
                }
                if (rejected)
                {
                    //reset
                    Reset();
                    //Display to user. 
                    //UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Rejected", PmmStatusEventArgs.MsgType.Rejected)); //Use more detailed status inside loop
                    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Cancelled", PmmStatusEventArgs.MsgType.Cancelled));
                }
                //if (_wirelessDirect.SocketError)
                //{
                //    //reset
                //    Reset();
                //    //Display to user.
                //    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Quit", PmmStatusEventArgs.MsgType.Quit));
                //}
                if (gotInVehicle)
                {
                    //reset
                    Reset();
                    //Display to user.
                    UpdateGroupStatus?.Invoke(this, new PmmStatusEventArgs("Complete", PmmStatusEventArgs.MsgType.Complete));
                }
                //The trip has been ended or completed. Disconnect from the group.
                //Task.Delay(10000).Wait();//test waiting, cancel not being rxed by leader.
                Logger.Debug(TAG, "Trip End (follower)");
            }
            catch (Exception ex)
            {
                Logger.Error(TAG, "Termination of Pmm Follower Loop: " + ex.Message + Environment.NewLine + ex.StackTrace);
                //reset
                Reset();
            }
        }


        public void InitPsmObuSettings()
        {
            _pmManager.SetTotalNumPedestrians(1, 0);//initialize to 1 person as default (for radius of protection in PSM).
        }

        #region wifi communication messages - TODO move elsewhere? manage threadsaftey of _wireless
        //https://forums.xamarin.com/discussion/2400/android-ui-threading
        //https://realm.io/news/android-threading-background-tasks/

        //public static string BasePrefixToken = "$MDEA";
        /// <summary>
        ///Sent from followers to leader on a routine basis so that the leader knows who is active.
        /// Heartbeat syntax: HeartbeatToken, myGuid, myLat, myLong, myRegSeats, myWheelchairSeats
        /// </summary>
        //public static string HeartbeatMessageToken = "$MDEAH";

        /// <summary>
        ///Sent from leaders to specific follower when the status of that follower changes.
        /// Heartbeat syntax: FollowerStatusToken, followerGuid, message
        /// If follower Guid is 0, then all followers will listen. Else, followers will discard if Guid doesn't match their guid.
        /// TODO: message could be string or could be enum type PmmStatusEventArgs.MsgType
        /// </summary>
       // public static string FollowerStatusToken = "$MDEAFS";
        /// <summary>
        ///  /Heartbeat syntax: HeartbeatToken($MDEAH), myGuid, myLat, myLong, myRegSeats, myWheelchairSeats
        /// </summary>
        /// <param name="followerGuid"></param>
        /// <param name="followerLocation"></param>
        /// <param name="regSeats"></param>
        /// <param name="wheelSeats"></param>
        /// <returns></returns>
        private void BuildHeartbeatTokenizedMsg(Guid followerGuid, Coordinates followerLocation, int regSeats, int wheelSeats)
        {
            //string s = HeartbeatMessageToken + "," + followerGuid.ToString() + "," + followerLocation.Latitude.ToString()
            //     + "," + followerLocation.Longitude.ToString()
            //      + "," + regSeats + "," + wheelSeats;
            //SendWirelessDirectInformation(s);

            Heartbeat h = new Heartbeat();
            h.FollowerId = followerGuid;
            h.GroupId = (Guid)_travelRequest.GroupId;
            h.Latitude = followerLocation.Latitude;
            h.Longitude = followerLocation.Longitude;
            h.RegSeats = regSeats;
            h.HcapSeats = wheelSeats;
            SendHeartbeat(h);

            //   return s;
        }
        private void SendHeartbeat(Heartbeat heart)
        {

            Logger.Debug(TAG, "Grouping: Tx: Heartbeat " + heart);
            DbLogger.Instance().Debug("Grouping: Tx: Heartbeat " + heart);

            Task<Heartbeat> update = CloudCommunications.SendHeartbeat(heart);

            update.LogExceptions(TAG);
            if (update.Wait(2000))
            {
                if (update.Result != null)
                {
                    DbLogger.Instance().Debug("Cloud Comm: SendHeartbeat : " + update.Result.ToString());
                }
            }


        }
        //private void SendWirelessDirectInformation(string s)
        //{
        //    //add msg terminator.
        //    s = s + ";";
        //    Logger.Debug(TAG, "Grouping: Tx:" + s);
        //    DbLogger.Instance().Debug("Grouping: Tx: " + s);
        //    //DbLogger.Instance().Debug("Sending wifi coord message: " + s);
        //    //Put message in queue to be sent out wifi to group.
        //    _msgsToWifi.Enqueue(s);
        //    //   
        //}
        private void SendLeaderUpdate(LeaderUpdate leaderUpdate)
        {

            Logger.Debug(TAG, "Grouping: Tx: LeaderUpdate " + leaderUpdate);
            DbLogger.Instance().Debug("Grouping: Tx: LeaderUpdate " + leaderUpdate);

            Task<LeaderUpdate> update = CloudCommunications.SendLeaderUpdate(leaderUpdate);
            update.LogExceptions(TAG);
            if (update.Wait(2000))
            {
                if (update.Result != null)
                {
                    DbLogger.Instance().Debug("Cloud Comm: LeaderUpdate : " + update.Result.ToString());
                }
            }
            else
            {
                Logger.Debug(TAG, "heartbeats2 Wait false");
            }

        }

        private void BuildArrivedTokenizedMsg(string arrivalMsg)
        {
            //Follower status token , 0 to broadcast to all followers, Arrived
            //string s = FollowerStatusToken + ",0," + arrivalMsg;
            //SendWirelessDirectInformation(s);
            LeaderUpdate lu = new LeaderUpdate();
            lu.FollowerId = null;
            lu.Message = arrivalMsg;
            lu.GroupId = (Guid)_travelRequest.GroupId;
            SendLeaderUpdate(lu);
            //  return s;
        }
        private void BuildFollowerUpdateTokenizedMsg(Guid followerGuid, PmmStatusEventArgs.MsgType status)
        {
            //Follower status token , Guid of the follower, the new status 
            //string s = FollowerStatusToken + "," + followerGuid.ToString() + "," + status.ToString();
            //SendWirelessDirectInformation(s);
            LeaderUpdate lu = new LeaderUpdate();
            lu.FollowerId = followerGuid;
            lu.Message = status.ToString();
            lu.GroupId = (Guid)_travelRequest.GroupId;
            SendLeaderUpdate(lu);
            //return lu;
        }
        /// <summary>
        /// Broadcasts the status to all followers.
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        private void BuildBroadcastTokenizedMsg(PmmStatusEventArgs.MsgType status)
        {
            //Follower status token , 0 to broadcast to all followers, the new status 
            //string s = FollowerStatusToken + "," + 0 + "," + status.ToString();
            //SendWirelessDirectInformation(s);
            LeaderUpdate lu = new LeaderUpdate();
            lu.FollowerId = null;
            lu.Message = status.ToString();
            lu.GroupId = (Guid)_travelRequest.GroupId;
            SendLeaderUpdate(lu);
            //return lu;
        }

        #endregion
    }




}
