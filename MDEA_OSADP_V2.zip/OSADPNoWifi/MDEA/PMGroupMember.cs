﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication
{
    public enum MemberPmmStatus
    {
        New,
        Pending,
        Accepted,
        Rejected,
        Quit, //Member elected to Cancel                    -- I don't know if we need to differentiate these 3 reasons people leave, but it probably doesn't hurt.
        Expired, //Member failed to provide heartbeats
        Left, //Members location got too far from pickup location.
        Deleted //When a new pmmRequest has been generated to reflect the absense of the member
    }

    public class PMGroupMember
    {

        public DateTime LastUpdate { get; set; }
        public Guid MemberGuid { get; set; }
        public double MemberLat { get; set; }
        public double MemberLong { get; set; }
        public int RegularSeats { get; set; }
        public int HandicappedSeats { get; set; }
        public MemberPmmStatus Status { get; set; }
        /// <summary>
        /// Request Id that included this member
        /// </summary>
        public int RequestId { get; set; }


        /// <summary>
        /// Tokens in order of MemberGuid,MemberLat,MemberLong,RegularSeats,HandicappedSeats
        /// </summary>
        /// <param name="tokens"></param>
        //public PMGroupMember(string[] tokens)
        //{
        //    LastUpdate = DateTime.Now;
        //    MemberGuid = new Guid(tokens[1]);
        //    MemberLat = Convert.ToDouble(tokens[2]);
        //    MemberLong = Convert.ToDouble(tokens[3]);
        //    RegularSeats = Convert.ToInt32(tokens[4]);
        //    HandicappedSeats = Convert.ToInt32(tokens[5]);
        //    Status = MemberPmmStatus.New;
        //    RequestId = -1; //not yet known.
        //}

        public PMGroupMember(Guid guid, double mLat, double mLong, int regularSeats, int hcapSeats, DateTime updateTime)
        {
            LastUpdate = updateTime;
            MemberGuid =guid;
            MemberLat = mLat;
            MemberLong =mLong;
            RegularSeats = regularSeats;
            HandicappedSeats = hcapSeats;
            Status = MemberPmmStatus.New;
            RequestId = -1; //not yet known.
        }
    }
}
