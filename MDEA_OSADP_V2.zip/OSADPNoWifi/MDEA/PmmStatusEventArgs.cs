﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication
{

    /// <summary>
    /// For updating users the status of their pmm trip.
    /// </summary>
    public class PmmStatusEventArgs : EventArgs
    {
        public enum MsgType
        {
            Unk,
            Accepted,
            Rejected,
            Arrived,
            Cancelling, //used for Leader thread to provide feedback to UI while the PMM-CANCEL is confirmed with VEA.
            Cancelled,
            Quit, //walked away or stopped communicated 
            Complete //All done / got in car
        }
        private readonly string status;
        private readonly MsgType type;

        public PmmStatusEventArgs(string statusMsg, MsgType msgType)
        {
            this.status = statusMsg;
            this.type = msgType;
        }

        public PmmStatusEventArgs(string statusMsg, string msgType)
        {
            this.status = statusMsg;
            MsgType t;

            if (Enum.TryParse(msgType, out t))
            {
                this.type = t;
            }
            else
            {
                type = MsgType.Unk;
            }
        }

        public string Status
        {
            get { return this.status; }
        }
        public MsgType MessageType
        {
            get { return this.type; }
        }
    }

}
