﻿using CITOMobileCommon;
using CITOMobileCommon.Data;
using CITOMobileCommon.J2735.Ext;
using CITOMobileCommon.Logging;
using CITOMobileCommon.Models;
using CITOMobileCommon.Utils;
using MobileDevicesExperimentalApplication.WebApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MobileDevicesExperimentalApplication
{
    public class PmmManager
    {
        private LocomateConnectionManager LocomateConnectionMgr;

        private static String TAG = "MDEA-PMMM";
        private MdeaCloudCommunications CloudCommunications;
       // private bool GotPmmResponse;
        private object PmmResponseLockObj = new object();
        private DsrcSettings ObuSettings;
        private Object ObuSettingsLock;
        private PMM CurrentPmmMsg;
       // private Timer dscrTimer;
        public PmmManager( DsrcSettings obuSettings, object obuSettingsLock, LocomateConnectionManager connectionMgr)
        {
            CloudCommunications = new MdeaCloudCommunications();
            LocomateConnectionMgr = connectionMgr;
            ObuSettings = obuSettings;
            ObuSettingsLock = obuSettingsLock;

         //   SetTotalNumPedestrians(1, 0);//initialize to 1 person as default (for radius of protection in PSM).
        }

        public async Task<PmmRequest> SendPmmReqToCloud(PmmRequest pmmReq)
        {
            DbLogger.Instance().Debug("Cloud Comm: Request : " + pmmReq.ToString());
            Logger.Debug(TAG, "Cloud Comm: Request : " + pmmReq.ToString());

            PmmRequest response = await CloudCommunications.SendPmm(pmmReq);

            return response;
        }


        public PMM SendNewPmmReq(PmmRequest pr)
        {
            //lock (PmmResponseLockObj)
            //{
            //    GotPmmResponse = false;
            //}
           

            PMM pmm = new PMM();

            //Update all the fields that are used for a "new" pmm request.
            pmm.PersonalMobilityMessage.status = "new";

            //This was supposed to be required only for new.  But the 'non required ' fields for various types of pmm never ended up optional. move below.
            //pmm.PersonalMobilityMessage.destination = new PMM_Destination( (double)pr.DestLatitude, (double)pr.DestLongitude);
            //pmm.PersonalMobilityMessage.pickupDate = new PMM_Date((DateTime)pr.PickupDate);

            //pmm.PersonalMobilityMessage.position = new PSM_Position((double)pr.PickupLatitude, (double)pr.PickupLongitude);
            //ModeOfTransportType mot = (ModeOfTransportType)pr.ModeofTransport;
            //pmm.PersonalMobilityMessage.modeOfTransport = mot.ToString();
           


            CurrentPmmMsg = pmm;
            //Pass to SendUpdate to load the rest of the fields, and to send the message.
            SendUpdatePmmReqToDsrc(pr, pmm);

            return pmm;
        }

        /// <summary>
        /// Call for sending updates to a request.
        /// Updated pmms only require a subset of the fields: groupid,requestid, requestdate, and Num seats.
        /// (Called internally for sending new requests as well, ignore second param-Use SendNewPmmReq instead.)
        /// </summary>
        /// <param name="pr">The request to send</param>
        /// <param name="newPmm">Exclude this param for "updates". Used for new entries. </param>
        public void SendUpdatePmmReqToDsrc(PmmRequest pr, PMM newPmm = null)
        {
            DbLogger.Instance().Debug("Dsrc: Tx: PMM: " + pr.ToString());
            Logger.Debug(TAG, "Dsrc: Tx: PMM: " + pr.ToString());
            PMM pmm = new PMM();
            //If newPmm is not null, then load that data to start from that. 
            if (newPmm != null)
            {
                pmm = newPmm;
            }
            else
            {
                pmm.PersonalMobilityMessage.status = "update";
            }
            //Update the fields relevant to both new and updated pmms:
            pmm.PersonalMobilityMessage.requestId = pr.RequestId.ToString();
            pmm.PersonalMobilityMessage.groupId = pr.GroupIdent.ToString();
            //Add seat requests. currently only handling regular and handicapped.
           // if (pr.RegularSeats > 0)
           // {
                pmm.PersonalMobilityMessage.mobilityNeeds.Add(new PMM_MobilityNeed(MobilityNeedsType.noSpecialNeeds.ToString(), pr.RegularSeats.ToString()));
           // }
           // if (pr.HandicappedSeats > 0)
           // {
                pmm.PersonalMobilityMessage.mobilityNeeds.Add(new PMM_MobilityNeed(MobilityNeedsType.wheelchair.ToString(), pr.HandicappedSeats.ToString()));
           // }
            pmm.PersonalMobilityMessage.requestDate = new PMM_Date(pr.RequestDate);

            pmm.PersonalMobilityMessage.destination = new PMM_Destination((double)pr.DestLatitude, (double)pr.DestLongitude);
            pmm.PersonalMobilityMessage.pickupDate = new PMM_Date((DateTime)pr.PickupDate);

            pmm.PersonalMobilityMessage.position = new PSM_Position((double)pr.PickupLatitude, (double)pr.PickupLongitude);
            ModeOfTransportType mot = (ModeOfTransportType)pr.ModeofTransport;
            pmm.PersonalMobilityMessage.modeOfTransport = mot.ToString();

            //First send the PMM over DSRC
            //Send the data
            LocomateConnectionMgr.SendJsonData(pmm);
            //Set the flag to regularly transmit the pmm data until we say not to.
            lock (ObuSettingsLock)
            {
                ObuSettings.SendPmm = true;
            }
            SendCurrentObuSettings();
            ////Set up a timer to wait a period of time for someone to respond over dsrc.
            ////If we didn't get one by the time the timer expires, then send the request over the cloud.
            //dscrTimer = new Timer(TimeSpan.FromSeconds(Settings.DsrcTimeout), async () =>
            //{
            //    bool GotPmmResponseCopy;
            //    lock (PmmResponseLockObj)
            //    {
            //        GotPmmResponseCopy = GotPmmResponse;
            //    }
            //    if (!GotPmmResponseCopy)
            //    {
            //        //The timer elapsed and we have not received a response to our request.  Send the request to the cloud.
            //        PmmRequest reqResp = await SendPmmReqToCloud(pmm.PersonalMobilityMessage.destination.lat,
            //            pmm.PersonalMobilityMessage.destination.lon,
            //             pmm.PersonalMobilityMessage.position.lat,
            //              pmm.PersonalMobilityMessage.position.@long,
            //               0,//TODO pmm.PersonalMobilityMessage.position.elevation,
            //               pickupDateTime, regularSeats, handicappedSeats);
            //        if(reqResp.Id == null)
            //        {
            //            //Error, did not receive response.

            //        }

            //        CommunicateOverCloud(reqResp);

            //    }
            //}, true).Start();

            //Need to poll the cloud for a Response from a vehicle.
            //Should do this 'forever' as long as the user hasn't cancelled. (TODO if pickup time has expired we should likely quit too).
            //If the type was in fact 'cancel', then as long as we know we logged it, we don't have to query for confirmation - I'd think we could just quit.
        }

        //The DSRC response has been received. Stop transmitting the pmm.
        public void CancelDsrcSendPmm()
        {
            //Turn off the master switch in the Arada to stop transmitting the periodic pmm data.
            lock (ObuSettingsLock)
            {
                ObuSettings.SendPmm = false;
            }
            SendCurrentObuSettings();
         
        }
        /// <summary>
        /// todo: this is duplicated from safetymon
        /// </summary>
        public void SendCurrentObuSettings()
        {
            DsrcSettings settings;
            lock (ObuSettingsLock)
            {
                settings = ObuSettings;
            }
          
            DbLogger.Instance().Debug("Dsrc: Tx: (SendPsm: " + settings.SendPsm + ") SendPmm:" + settings.SendPmm);
            Logger.Debug(TAG, "Dsrc: Tx: (SendPsm: " + settings.SendPsm + ") SendPmm:" + settings.SendPmm);
            LocomateConnectionMgr.SendJsonData(settings);
        }


        private object _totalNumPedInGroupLock = new object();
        private int _totalNumberPedestriansInGroup = 0;
       

        public void SetTotalNumPedestrians(int totalRegSeats, int totalHcapSeats)
        {
            int  newTotalNumberPedestriansInGroup = totalRegSeats + totalHcapSeats;
            //Despite a group cancelling with 0, we never want to send less than 1.
            if (newTotalNumberPedestriansInGroup < 1) newTotalNumberPedestriansInGroup = 1;
            //If the number in the group has changed, send update to radio.
            if (newTotalNumberPedestriansInGroup != _totalNumberPedestriansInGroup)
            {
                _totalNumberPedestriansInGroup = newTotalNumberPedestriansInGroup;
                PsmSettings psm = new PsmSettings();
                psm.NumberPedestrians = _totalNumberPedestriansInGroup;
                psm.RadiusOfProtection = CalculateRadiusOfProtection(_totalNumberPedestriansInGroup);
                
                DbLogger.Instance().Debug("Dsrc: Tx: Psm  NumPed: " + psm.NumberPedestrians + "RadProt: " + psm.RadiusOfProtection);
                Logger.Debug(TAG, "Dsrc: Tx: Psm  NumPed: " + psm.NumberPedestrians + "RadProt: " + psm.RadiusOfProtection);
                LocomateConnectionMgr.SendJsonData(psm);
            }
        }

        /// <summary>
        /// Returns clusterRadius for given number of represented group members.
        /// </summary>
        /// <param name="numberOfGroupMembers"></param>
        /// <param name="personalSpace"></param>
        /// <param name="safetyFactor"></param>
        /// <returns></returns>
        public static int CalculateRadiusOfProtection(int numberOfGroupMembers, double personalSpace = 4.67, double safetyFactor = 5.6)//1.5
        {
            // radiusOfProtection = Math.pow((numberOfGroupMembers * personalSpace) / Math.PI) , 0.5)*safetyFactor
            //                     where personalSpace (default = 4.67, circular area assuming 4 ft of personal space around a person) and safetyFactor (default = 1.5) are configurable parameters.

            double radius = Math.Pow(((numberOfGroupMembers * personalSpace) / Math.PI), 0.5) * safetyFactor;
            return (int)Math.Ceiling(radius);
        }


        public async Task<PmmStatusResponse> GetPmmResponseFromCloud(int id)
        {
            List<PmmStatusResponse> response = await CloudCommunications.GetPmmRequestStatus(id);
            //In a production system, there would likely be many responses, and some logic would go into
            //finding one that is acceptance, or closest, etc. but for our prototype purposes we assume
            //only one response.
            if (response != null && response.Count > 0)
            {
                string k = "Id: " + response.First().Id + "PmmRequestId: " + response.First().PmmRequestId + "ResponseDate: " + response.First().ResponseDate
                     + "TotalHandicapSeatsAccptd: " + response.First().TotalHandicapSeatsAccptd + "TotalRegSeatsAccptd: " + response.First().TotalRegSeatsAccptd;
                DbLogger.Instance().Debug("Cloud Comm: Response : " + k);
                Logger.Debug(TAG, "Cloud Comm: Response : " + k);
                return response.First();
            }
            else return null;
        }

 
    }
}
