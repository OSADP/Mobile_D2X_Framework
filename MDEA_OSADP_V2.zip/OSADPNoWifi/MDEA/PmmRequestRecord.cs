﻿using MobileDevicesExperimentalApplication.WebApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication
{
    public enum PmmRequestStatus
    {
        New,
        Pending,
        ResponseRxDsrc,
        ResponseRxCloud
    }
    public class PmmRequestRecord
    {
        public PmmRequest Request { get; set; }
        /// <summary>
        /// If received, else null.
        /// </summary>
        public PmmStatusResponse Response { get; set; }
        public PmmRequestStatus Status { get; set; }

        public PmmRequestRecord(PmmRequest request)
        {
            Request = request;
            //new request with no response yet.
            Response = null;
            Status = PmmRequestStatus.New;
        }
    }
}
