﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;


namespace MobileDevicesExperimentalApplication
{
    class MenuDetailPage : MasterDetailPage
    {
        private static string HOME_PAGE_LABEL_STRING = "Home";
        private static string SETTINGS_LABEL_STRING = "Settings";

        Dictionary<String, Type> MenuPagesDictionary;

        public MenuDetailPage()
        {
            MenuPagesDictionary = new Dictionary<string, Type>();
            MenuPagesDictionary.Add(HOME_PAGE_LABEL_STRING, typeof(HomePage));
            MenuPagesDictionary.Add(SETTINGS_LABEL_STRING, typeof(SettingsPage));


            Master = CreateContentPage();

            StackLayout contentStack = new StackLayout();
            contentStack.Padding = new Thickness(10, 40);


            foreach(String key in MenuPagesDictionary.Keys)
            {
                Button btn = Link(key);
                contentStack.Children.Add(btn);
            }

            ((ContentPage)Master).Content = contentStack;

            
            Detail = new NavigationPage(new HomePage());
            this.MasterBehavior = MasterBehavior.Popover;
        }

        private ContentPage CreateContentPage()
        {
            ContentPage masterContentPage = new ContentPage
            {
                Icon = "menu2.png",
                Title = "Menu",
                BackgroundColor = Color.Gray
            };

            return masterContentPage;
        }

        private Label VersionLabel(string versionString)
        {
            var label = new Label
            {
                Text = versionString,
                TextColor = Color.Black,
                FontSize = 16
            };
            return label;
        }


        private Button Link(string name)
        {
            var button = new Button
            {
                Text = name,
                TextColor = Color.White,
                BackgroundColor = Color.Navy,
                FontSize = 18
            };
            button.Clicked += delegate {

                Type objectType = MenuPagesDictionary[name];
                var tmp = Activator.CreateInstance(objectType);

                ContentPage newPage = (ContentPage)tmp;

                this.Detail = new NavigationPage(newPage);
                this.IsPresented = false;
            };
            return button;
        }
    }
}
