﻿using CITOMobileCommon.Cloud;
using CITOMobileCommon.J2735.Ext;
using CITOMobileCommon.Logging;
using MobileDevicesExperimentalApplication.WebApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileDevicesExperimentalApplication
{
    public class MdeaCloudCommunications : CloudCommunicationBase
    {
        static string BASE_URL = "http://mobiledeviceswebapidev.azurewebsites.net/api";

        public MdeaCloudCommunications() : base(BASE_URL)
        {
        }

        public async Task<PmmRequest> SendPmm(PmmRequest pmmMsg)
        {
            try
            {
                return await PostDataWithResponse<PmmRequest, PmmRequest>(pmmMsg, "/PmmRequest");
            }
            catch(Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }
           
        }

        public async Task<List<PmmStatusResponse>> GetPmmRequestStatus(int id)
        {
            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();

                //The web api evolved to be  bit confusing, the get for the response is on the PmmRequest
                return await GetFromWebService<List<PmmStatusResponse>>("/PmmRequest/" + id, parameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// For coordinating travel with other travelers.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public async Task<TravelRequest> SendTravelRequest(TravelRequest msg)
        {
            try
            {
                return await PostDataWithResponse<TravelRequest, TravelRequest>(msg, "/TravelRequest").ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }

        }

        /// <summary>
        /// Travel group members poll status to see if they are leader or follower and for the group id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<TravelRequest> GetTravelRequestStatus(int id)
        {
            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();

              
                return await GetFromWebService<TravelRequest>("/TravelRequest/" + id, parameters).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// For coordinating travel with other travelers.  Members send heartbeats of status to leader.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public async Task<Heartbeat> SendHeartbeat(Heartbeat msg)
        {
            try
            {
                return await PostDataWithResponse<Heartbeat, Heartbeat>(msg, "/Heartbeat").ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }

        }
        /// <summary>
        /// Travel group leader polls for followers.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<List<Heartbeat>> GetNewHeartbeats(DateTime since, Guid groupId, Guid followerId)
        {
            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                 parameters.Add("dateSince", since);
                  parameters.Add("groupId", groupId);
                parameters.Add("followerId", followerId);


                return await GetFromWebService<List<Heartbeat>>("/Heartbeat", parameters).ConfigureAwait(false);
              //  return await GetFromWebService<List<Heartbeat>>("/Heartbeat", null);
            }
            catch (Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }
        }

        public async Task<List<LeaderUpdate>> GetNewLeaderUpdates(DateTime since, Guid groupId, Guid followerId)
        {
            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("dateSince", since);
                parameters.Add("groupId", groupId);
                parameters.Add("followerId", followerId);


                return await GetFromWebService<List<LeaderUpdate>>("/LeaderUpdate", parameters).ConfigureAwait(false);
               
            }
            catch (Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }
        }

        /// <summary>
        /// For coordinating travel with other travelers. Leader sends updates to group members.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public async Task<LeaderUpdate> SendLeaderUpdate(LeaderUpdate msg)
        {
            try
            {
                return await PostDataWithResponse<LeaderUpdate, LeaderUpdate>(msg, "/LeaderUpdate").ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }

        }

        /// <summary>
        /// Get all transit stops for a transit route.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<List<BusRoute>> GetTransitRoute(string transitRoute)
        {
            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                transitRoute = transitRoute.Replace(' ', '+');
                parameters.Add("transitRoute", transitRoute);

                return await GetFromWebService<List<BusRoute>>("/BusRoute", parameters, false).ConfigureAwait(false);
                //  return await GetFromWebService<List<Heartbeat>>("/Heartbeat", null);
            }
            catch (Exception ex)
            {
                Logger.Error("CloudComs", ex.Message);
                return null;
            }
        }

    }
}
