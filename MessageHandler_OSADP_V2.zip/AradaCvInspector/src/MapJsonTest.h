/*
 * MapJsonTest.h
 *
 *  Created on: Jan 7, 2016
 *      Author: ivp
 */

#ifndef SRC_MAPJSONTEST_H_
#define SRC_MAPJSONTEST_H_

#include <string>

namespace DsrcMobileArada {

class MapJsonTest {
public:
	MapJsonTest();
	virtual ~MapJsonTest();

	std::string GetMapJson();

private:
	void InitializeFromFile();

	std::string _mapJson;
};

} /* namespace DsrcMobileArada */

#endif /* SRC_MAPJSONTEST_H_ */
