/*
 * BluetoothServer.cpp
 *
 *  Created on: Jan 11, 2016
 *      Author: gmb
 */

#include <boost/atomic.hpp>
#include "Bluetooth.h"
#include "XmlToJson.h"

using namespace std;
using namespace DsrcMobileArada;

boost::atomic<bool> txReady;

void BluetoothServer::start(const char *uuid) {
	if (uuid == NULL) return;

	// Initially take the transmit lock.  It is released when the server has started.
	txReady = false;

	registerService(uuid);
	if (!_btServerThread)
		_btServerThread = new boost::thread(&btServer_serverStart, this);

	if (!_converterThread);
		_converterThread = new boost::thread(&start_converter, this);
}

void BluetoothServer::stop()
{
	destroyClients();

	if (_btServerThread != NULL)
	{
		_stopBtServerThread = true;
		_btServerThread->join();
		delete _btServerThread;
		_btServerThread = NULL;
	}

	if (_converterThread != NULL)
	{
		_stopConverterThread = true;
		_converterThread->join();
		delete _converterThread;
		_converterThread = NULL;
	}
}

void BluetoothServer::sendRawMessageToAllClients(const char *message)
{
	if (!txReady)
		return;

	int retvalue;
	int i;

	int msgLength = strlen(message);
	//cout << "Sending " << msgLength << " bytes out bluetooth ..." << endl;

	//scroll through each connected client
	for (i=0; i < MAX_CONNECTIONS; i++)
	{
		if (btClients[i].isConnected)
		{
			retvalue = write(btClients[i].sock, message, msgLength);
			if (retvalue < 0)
			{
				cerr << "Error Sending to BT Connection %d. Setting to DISCONNECTED" << endl;
				btClients[i].isConnected = false;
			}
		}
	}
}

void BluetoothServer::sendXmlMessageToAllClients(const char* xml)
{
	const string msg(xml);

	if (!send_xml_message(msg))
		cerr << "ERROR: Message " << xml << " dropped due to full channel";
}

/***********************************************
 * INTERNAL METHODS
 **********************************************/

void BluetoothServer::registerService(const char *uuid)
{
	sdp_session_t *sdpSession = NULL;

	cout << "BtServer: Registering with UUID: " << uuid << endl;

	sdp_record_t *rec = sdp_record_alloc();
	uuid_t l2cap_uuid, root_uuid, rfcomm_uuid, service_uuid;
	sdp_list_t *service_class_list = 0, *l2cap_list = 0, *rfcomm_list = 0, *root_list = 0, *protocol_list = 0, *access_protocol_list = 0;
	sdp_data_t *channel = 0;
	uint8_t rfcomm_chan = this->getChannel();

	if(!str2uuid(uuid, &service_uuid))
	{
		perror("BtServer: Invalid UUID");
		return;
  	}

	//Create record for service to broadcast (connect with smartphone)
	sdp_set_service_id(rec, service_uuid);
	service_class_list = sdp_list_append(0, &service_uuid);
	sdp_set_service_classes(rec, service_class_list);

	sdp_uuid16_create(&root_uuid, PUBLIC_BROWSE_GROUP);
	root_list = sdp_list_append(0, &root_uuid);
	sdp_set_browse_groups(rec, root_list);

	sdp_uuid16_create(&l2cap_uuid, L2CAP_UUID);
	l2cap_list = sdp_list_append(0, &l2cap_uuid);

	sdp_uuid16_create(&rfcomm_uuid, RFCOMM_UUID);
	channel = sdp_data_alloc(SDP_UINT8, &rfcomm_chan);
	rfcomm_list = sdp_list_append(0, &rfcomm_uuid);
	sdp_list_append(rfcomm_list, channel);
	protocol_list = sdp_list_append(0, rfcomm_list);

	access_protocol_list = sdp_list_append(0, protocol_list);
	sdp_set_access_protos(rec, access_protocol_list);

	sdp_set_info_attr(rec, "INC-ZONE", "Battelle", "INC-ZONE Application for RESCUME");

	sdpSession = sdp_connect(BDADDR_ANY, BDADDR_LOCAL, SDP_RETRY_IF_BUSY);
	if (sdpSession != NULL)
	{
		int error = sdp_record_register(sdpSession, rec, 0);
		cout << "BtServer: SDP Record Registered: " << error << endl;
	}
	else
	{
		cout << "BtServer: Unable to connect to SDP Server." << endl;
	}

	//Free service lists
	sdp_data_free(channel);
	sdp_list_free(l2cap_list, 0);
	sdp_list_free(rfcomm_list, 0);
	sdp_list_free(root_list, 0);
	sdp_list_free(access_protocol_list, 0);

	// If the session is closed here, connections do not work.
	//sdp_close(sdpSession);
}

void BluetoothServer::initAdapter()
{
	// Reset Bluetooth and Initialize
	char cmd[50];

	sprintf(cmd, "/usr/local/bin/hciconfig hci0 up");
	cout << "BtServer: Executing command: " << cmd << endl;
	system(cmd);

	sprintf(cmd, "/usr/local/bin/hciconfig hci0 piscan");
	cout << "BtServer: Executing command: " << cmd << endl;
	system(cmd);
}

void btServer_serverStart(void *arg)
{
	BluetoothServer *srv = (BluetoothServer *) arg;
	srv->initAdapter();

	// Allocate connections
	int i;
	for(i=0;i<MAX_CONNECTIONS;i++)
	{
		srv->btClients[i].sock = (int) NULL;
		srv->btClients[i].isConnected = false;
	}

	// allocate socket
	cout << "BtServer: Allocating Socket." << endl;
	srv->setSocket(socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM));
	if (srv->getSocket() < 1)
		cerr << strerror(errno) << endl;

	struct sockaddr_rc loc_addr = { 0 };
	loc_addr.rc_family = AF_BLUETOOTH;
	loc_addr.rc_bdaddr = *BDADDR_ANY;
	loc_addr.rc_channel = srv->getChannel();

	// Bind to socket
	cout << "BtServer: Binding Socket to channel: " << srv->getChannel() << endl;
	if (bind(srv->getSocket(), (struct sockaddr *)&loc_addr, sizeof(loc_addr)))
		cerr << strerror(errno) << endl;

	// put socket into listening mode
	cout << "BtServer: Listening..." << endl;
	if (listen(srv->getSocket(), 1) < 0)
	{
		cerr << "BtServer: listen() error." << endl;
		return;
	}

	// Release the transmit lock.  The server is up and running.
	txReady = true;

	while (!srv->_stopBtServerThread)
	{
		fd_set readFlags;
		FD_ZERO(&readFlags);
		FD_SET(srv->getSocket(), &readFlags);

		int maxfd = srv->getSocket();

		struct timeval timeout;
		timeout.tv_sec = 0;
		timeout.tv_usec = 100000;

		int activity = select(maxfd + 1, &readFlags, NULL, NULL, &timeout);

		if (activity < 0)
		{
			cerr << "BtServer: Error on server select..." << endl;
			break;
		}
		else if (activity == 0)
		{
			// Timeout.
			continue;
		}

		if (FD_ISSET(srv->getSocket(), &readFlags))
		{
			struct sockaddr_rc rem_addr = { 0 };
			socklen_t opt = sizeof(rem_addr);
			int client = accept(srv->getSocket(), (struct sockaddr *)&rem_addr, &opt);

			cout << "BtServer: Accepting connection..." << endl;

			for (i = 0; (i < MAX_CONNECTIONS) & (srv->btClients[i].sock != 0); i++);	//look for first available socket fd

			if (i < MAX_CONNECTIONS)
			{
				if (client >= 0)
				{
					char buf[30];
					ba2str( &rem_addr.rc_bdaddr, buf );
					cout << "BtServer: Accepted connection " << client << " from " << buf << endl;

					strncpy(srv->btClients[i].macString, buf, BT_MAC_STRING_LENGTH);
					srv->btClients[i].sock = client;
					srv->btClients[i].isConnected = true;
					srv->btClients[i].thread = new boost::thread(&btServer_clientRun, (void *)&srv->btClients[i]);
					cout << "BtServer: Thread started for socket " << srv->btClients[i].sock << endl;
				}
			}
			else
			{
				cerr << "BtServer: Unable to accept new connection.  Max number of connections reached." << endl;
			}
		}
		else
		{
			cout << "BtServer: Not set." << endl;
		}
	}

	cout << "BtServer: Exiting thread." << endl;
}

void btServer_clientRun(void *arg)
{
	BtClient *client = (BtClient *) arg;
	char buffer[1024];

	while (client->isConnected)
	{
		fd_set readFlags;
		FD_ZERO(&readFlags);
		FD_SET(client->sock, &readFlags);

		int maxfd = client->sock;

		struct timeval timeout;
		timeout.tv_sec = 0;
		timeout.tv_usec = 100000;

		int activity = select(maxfd + 1, &readFlags, NULL, NULL, &timeout);

		if (activity < 0)
		{
			cerr << "BtServer: Error on client select..." << endl;
			break;
		}
		else if (activity == 0)
		{
			// Timeout.
			continue;
		}

		if (FD_ISSET(client->sock, &readFlags))
		{
			int readCount = read(client->sock, buffer, sizeof(buffer));

			if (readCount <= 0)
			{
				cout << "BtClient '" << client->macString << "': read " << readCount << " bytes." << endl;
				cout << "BtClient '" << client->macString << "': Connection Closed." << endl;
				client->isConnected = false;
			}
			else
			{
				client->jsonParser.ProcessInput(buffer, 0, readCount);
			}
		}

		sched_yield();
	}

	//TODO: Shut socket down
	int retvalue = close(client->sock);
	if (retvalue < 0)
	{
		cerr << "BtClient '" << client->macString << "': Error Closing Socket..." << endl;
	}
	else
	{
		cout << "BtClient '" << client->macString << "': Bluetooth Socket Closed" << endl;
	}
	client->sock = 0;

	cout << "BtClient '" << client->macString << "': Exiting thread." << endl;
}

void BluetoothServer::destroyClients()
{
	disconnect();

	for (int i=0; i < MAX_CONNECTIONS; i++)
	{
		// If it is not null then it exist so try to cancel it.
		if (btClients[i].sock != 0)
		{
			btClients[i].isConnected = false;
			shutdown(btClients[i].sock, SHUT_RD);

			if (btClients[i].thread != NULL)
			{
				btClients[i].thread->join();
				delete btClients[i].thread;
				btClients[i].thread = NULL;
			}
		}
	}
}

int BluetoothServer::str2uuid(const char *uuid_str, uuid_t *uuid)
{
    uint32_t uuid_int[4];
    char *endptr;

    if( strlen( uuid_str ) == 36 ) {
        // Parse uuid128 standard format: 12345678-9012-3456-7890-123456789012
        char buf[9] = { 0 };

        if( uuid_str[8] != '-' && uuid_str[13] != '-' &&
            uuid_str[18] != '-'  && uuid_str[23] != '-' ) {
            return 0;
        }
        // first 8-bytes
        strncpy(buf, uuid_str, 8);
        uuid_int[0] = htonl( strtoul( buf, &endptr, 16 ) );
        if( endptr != buf + 8 ) return 0;

        // second 8-bytes
        strncpy(buf, uuid_str+9, 4);
        strncpy(buf+4, uuid_str+14, 4);
        uuid_int[1] = htonl( strtoul( buf, &endptr, 16 ) );
        if( endptr != buf + 8 ) return 0;

        // third 8-bytes
        strncpy(buf, uuid_str+19, 4);
        strncpy(buf+4, uuid_str+24, 4);
        uuid_int[2] = htonl( strtoul( buf, &endptr, 16 ) );
        if( endptr != buf + 8 ) return 0;

        // fourth 8-bytes
        strncpy(buf, uuid_str+28, 8);
        uuid_int[3] = htonl( strtoul( buf, &endptr, 16 ) );
        if( endptr != buf + 8 ) return 0;

        if( uuid != NULL ) sdp_uuid128_create( uuid, uuid_int );
    } else if ( strlen( uuid_str ) == 8 ) {
        // 32-bit reserved UUID
        uint32_t i = strtoul( uuid_str, &endptr, 16 );
        if( endptr != uuid_str + 8 ) return 0;
        if( uuid != NULL ) sdp_uuid32_create( uuid, i );
    } else if( strlen( uuid_str ) == 4 ) {
        // 16-bit reserved UUID
        int i = strtol( uuid_str, &endptr, 16 );
        if( endptr != uuid_str + 4 ) return 0;
        if( uuid != NULL ) sdp_uuid16_create( uuid, i );
    } else {
        return 0;
    }

    return 1;
}
