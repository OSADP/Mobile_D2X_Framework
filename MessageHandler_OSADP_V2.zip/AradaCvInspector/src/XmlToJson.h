/*
 * XmlToJson.h
 *
 *  Created on: Feb 22, 2016
 *      Author: gmb
 */

#ifndef SRC_XMLTOJSON_H_
#define SRC_XMLTOJSON_H_

#define MAX_MESSAGES 10

#include "Bluetooth.h"

#include <cstdlib>
#include <cxxabi.h>
#include <memory>
#include <sstream>

#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/algorithm/string.hpp>

namespace DsrcMobileArada {

void start_converter(void *arg);
bool send_xml_message(const std::string &xml);
void expand_bsm(boost::property_tree::ptree &msgTree);
std::string get_RTCMInfoData(boost::property_tree::ptree &msgTree, unsigned int uptime_ms);

static inline std::string demangle_type(const char *mangled) {
    int status = 0;
    char *realname;
    realname = abi::__cxa_demangle(mangled, 0, 0, &status);

    std::stringstream ss;

    if (!status) {
    	ss << realname;
    } else {
    	ss << "Unknown demangling error: " << status;
    }

    free(realname);

    return ss.str();
}

template <typename Type>
static inline std::string type_id_name() {
	typedef Type myType;
	const std::type_info &info = typeid(myType);
	return demangle_type(info.name());
}


template <typename Type>
static inline std::string type_name() {
	std::string full_name = type_id_name<Type>();
	size_t index = full_name.find_last_of("::");
	if (index <= 0 || index + 1 >= full_name.length())
		return full_name;
	else
		return full_name.substr(index + 1);
}

template<typename Type>
static inline std::string type_name(Type &type) {
	return type_name<Type>();
}

/**
 * Converter function to change XML arrays to JSON arrays, removing the extra key
 */
struct fix_xml_arrays {
	template<typename Tree>
	void operator()(Tree &pt) {
		Tree copy(pt);

		pt.clear();
		for (typename Tree::iterator i = copy.begin(); i != copy.end(); i++) {
			pt.push_back(
					std::pair<typename Tree::key_type, Tree>("", i->second));
		}
	}
};

/**
 * Converter function to take an entire sub-tree up one level, effectively deleting unnecessary keys
 */
struct del_unnecessary_nodes {
	template<typename Tree>
	void operator()(Tree &pt) {
		Tree copy(pt);

		pt.clear();
		for (typename Tree::iterator i = copy.begin(); i != copy.end(); i++) {
			for (typename Tree::iterator j = i->second.begin();
					j != i->second.end(); j++) {
				pt.push_back(
						std::pair<typename Tree::key_type, Tree>(j->first,
								j->second));
			}
		}

	}
};

/**
 * Converter function to take make the key of a sub-tree a new value in the parent level,
 * effectively deleting unnecessary sub-objects
 */
struct flatten_node {
	template<typename Tree>
	void operator()(Tree &pt) {
		Tree copy(pt);

		//std::cout << "In the flatten_node function with:" << std::endl;
		//boost::property_tree::write_xml(std::cout, copy);
		//std::cout << copy.begin()->first << std::endl;

		pt.clear();
		pt.put_value(copy.begin()->first);
	}
};

template<typename Functor, typename Tree>
void repairAlongTree(Functor &fn, Tree &pt, typename Tree::path_type path) {
	if (path.empty()) {
		return;
	}

	if (path.single()) {
		boost::optional<Tree &> child = pt.get_child_optional(path);
		if (child)
			fn(child.get());
	} else {
		typename Tree::key_type head = path.reduce();
		for (typename Tree::iterator i = pt.begin(); i != pt.end(); i++) {
			if (i->first == head) {
				repairAlongTree<Functor, Tree>(fn, i->second, path);
			}
		}
	}
}

template<typename Tree>
std::string get_typeId(Tree &msgTree, Tree &helper) {
	typename Tree::value_type &root = msgTree.front();
	boost::optional<std::string> id = helper.template get_optional<std::string>(
			typename Tree::path_type("TreeRepair." + root.first + ".typeId"));
	if (id)
		return id.get();
	else
		return root.first;
}

template<typename Functor, typename Tree>
void cleanupTree(Tree &msgTree, Tree &helper)
{
	Functor fn;
	typename Tree::value_type &root = msgTree.front();
	typename Tree::iterator i;

	boost::optional<Tree &> subTree = helper.get_child_optional(
			typename Tree::path_type("TreeRepair." + root.first + "." + type_name(fn)));
	if (subTree)
	{
		for (i = subTree.get().begin(); i != subTree.get().end(); i++)
			repairAlongTree(fn, msgTree,
					typename Tree::path_type(i->second.template get_value<std::string>()));
	}
}

template<typename Tree>
void cleanupTree(Tree &msgTree, Tree &helper) {
	cleanupTree<fix_xml_arrays>(msgTree, helper);
	cleanupTree<del_unnecessary_nodes>(msgTree, helper);
	cleanupTree<flatten_node>(msgTree, helper);
}

} /* End namespace */
#endif /* SRC_XMLTOJSON_H_ */

