/*
 * MapJsonTest.cpp
 *
 *  Created on: Jan 7, 2016
 *      Author: ivp
 */

#include "MapJsonTest.h"

#include <fstream>
#include <iostream>
#include <string>
#include <sys/stat.h>

#include <streambuf>
#include <cerrno>

using namespace std;

namespace DsrcMobileArada {

inline bool FileExists(const string& filename)
{
	struct stat buffer;
	return (stat (filename.c_str(), &buffer) == 0);
}

string GetSelfFullPath()
{
	char buffer[2048];
	ssize_t length = ::readlink("/proc/self/exe", buffer, sizeof(buffer)-1);

	if (length != -1)
	{
		buffer[length] = '\0';
		return string(buffer);
	}

	return "";
}

string GetSelfFolder()
{
	string path = GetSelfFullPath();
	if (path.empty())
		return path;
	return path.substr(0, path.find_last_of("\\/"));
}

MapJsonTest::MapJsonTest()
{
	InitializeFromFile();
}

MapJsonTest::~MapJsonTest()
{

}

void MapJsonTest::InitializeFromFile()
{
	string selfFolder = GetSelfFolder();
	if (selfFolder.empty())
	{
		cout << "Test file could not be found, because path to self folder not found." << endl;
		return;
	}

	string filename = selfFolder + "/map.json";
	if (!FileExists(filename))
	{
		cout << "Test file could not be found: " << filename << endl;
		return;
	}

	cout << "Reading map json: " << filename << endl;

	ifstream ifs(filename.c_str());
	string content((istreambuf_iterator<char>(ifs) ), (istreambuf_iterator<char>()));

	if (content.empty())
	{
		cout << "Test file is empty: " << filename << endl;
		_mapJson = "";
		return;
	}

	_mapJson = content;
}

std::string MapJsonTest::GetMapJson()
{
	return _mapJson;
}

} /* namespace DsrcMobileArada */
