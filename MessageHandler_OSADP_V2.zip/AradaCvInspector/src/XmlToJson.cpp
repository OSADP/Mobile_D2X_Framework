/*
 * XmlToJson.cpp
 *
 *  Created on: Feb 23, 2016
 *      Author: gmb
 */

#include "XmlToJson.h"

#include <vector>
#include <boost/chrono.hpp>
#include <boost/lockfree/spsc_queue.hpp>
#include <boost/optional/optional.hpp>
#include <boost/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <BsmConverter.h>
#include <DecodedBsmMessage.h>

using namespace std;
using namespace DsrcMobileArada;
using namespace boost::lockfree;
using namespace boost::property_tree;
using namespace boost::chrono;

typedef boost::mutex mutex;

uint64_t UptimeMilliseconds();
string UptimeHeader();

static spsc_queue<string, capacity<10240> > messageQueue;

void DsrcMobileArada::start_converter(void *arg)
{
	BluetoothServer *srv = (BluetoothServer *) arg;

	boost::property_tree::ptree helper;

	try
	{
		read_xml("/var/bin/treerepair.xml", helper);
	}
	catch (boost::property_tree::xml_parser_error &ex)
	{
		cerr << ex.what() << endl;
	}

	system_clock::time_point startPTree;


	while (!srv->_stopConverterThread)
	{
		string xmlMsg;

		if (!messageQueue.pop(xmlMsg))
		{
			usleep(1000);
			continue;
		}

		// Load an attributes container from XML
		boost::property_tree::ptree msgTree;
		istringstream input(xmlMsg);
		boost::property_tree::read_xml(input, msgTree, boost::property_tree::xml_parser::trim_whitespace);

		// Clean up array structures that came in from XML to make them more JSON-like
		cleanupTree(msgTree, helper);

		// Expand the BSM blob and remove any unneeded nodes.
		expand_bsm(msgTree);

		string typeId = get_typeId(msgTree, helper);

		// Get the JSON message that is the payload.
		std::string msg;
		if (typeId == "RTCM-Corrections")
		{
			// For RTCM, use a completely custom message.
			msg = get_RTCMInfoData(msgTree, UptimeMilliseconds());
			typeId = "RTCMInfo";
		}
		else
		{
			// Serialize the ptree to JSON.
			std::stringstream ss;
			try
			{
				boost::property_tree::write_json(ss, msgTree, false);
			}
			catch (boost::property_tree::json_parser::json_parser_error &ex)
			{
//				cerr << ex.what() << ": On message: ";
//				boost::property_tree::write_xml(cerr, msgTree);
//				cerr << endl;
				usleep(1000);
				continue;
			}
			msg = ss.str();
		}

		boost::algorithm::trim(msg);
		std::stringstream ss;
		ss << "{" <<
		"\"typeId\":\"" << typeId << "\"," <<
		"\"contentType\":\"JSON\"," <<
		"\"contentLength\":\"" << msg.length() << "\"," <<
		"\"content\":" << msg <<
		"}";

		std::string message = ss.str();

		//cout << UptimeHeader() << typeId << " - sending " << message.length() << " bytes." << endl;

		//cout<< message <<endl;
		
		if (typeId != "BSM")
		{
			//cout << UptimeHeader() << xmlMsg << endl;
			//cout << UptimeHeader() << " - " << message << endl;
		}

		srv->sendRawMessageToAllClients(message.c_str());
//		milliseconds elapsed_mseconds = duration_cast<milliseconds>(system_clock::now() - startPTree);
//		printf("PTree Elapsed:%d \n", elapsed_mseconds.count());
	}

	cout << "Converter: Exiting thread." << endl;
}

bool DsrcMobileArada::send_xml_message(const std::string &xml)
{
	messageQueue.push(xml);

	return true;
}

void DsrcMobileArada::expand_bsm(boost::property_tree::ptree &msgTree)
{
	// Return immediately if this is not a BSM.
	boost::optional<ptree&> child = msgTree.get_child_optional("BasicSafetyMessage");
	if (!child)
		return;

	ptree& childTree = child.get();

	// Get blob1 as an ascii hex string and remove spaces between bytes.
	string hex = childTree.get<string>("blob1");
	hex.erase(std::remove(hex.begin(),hex.end(),' '),hex.end());

	// Convert the ascii string into an array of bytes.
	unsigned int byteCount = hex.length() / 2;
	unsigned char blob1[byteCount];
	for (unsigned int i = 0; i < byteCount; i++)
	{
		string byteString = hex.substr(i*2, 2);
		blob1[i] = (unsigned char)strtol(byteString.c_str(), NULL, 16);
	}

	tmx::messages::DecodedBsmMessage bsm;
	tmx::utils::BsmConverter::ToDecodedBsmMessage(blob1, bsm);

	childTree.put("MsgCount", bsm.get_MsgCount());
	childTree.put("TemporaryId", bsm.get_TemporaryId());
	childTree.put("Latitude", bsm.get_Latitude());
	childTree.put("Longitude", bsm.get_Longitude());
	childTree.put("Elevation_m", bsm.get_Elevation_m());
	childTree.put("Speed_mph", bsm.get_Speed_mph());
	childTree.put("Heading", bsm.get_Heading());
	childTree.put("SteeringWheelAngle", bsm.get_SteeringWheelAngle());
	childTree.put("SecondMark", bsm.get_SecondMark());
	childTree.put("IsOutgoing", bsm.get_IsOutgoing());
	childTree.put("IsLocationValid", bsm.get_IsLocationValid());
	childTree.put("IsElevationValid", bsm.get_IsElevationValid());
	childTree.put("IsSpeedValid", bsm.get_IsSpeedValid());
	childTree.put("IsHeadingValid", bsm.get_IsHeadingValid());
	childTree.put("IsSteeringWheelAngleValid", bsm.get_IsSteeringWheelAngleValid());

	//cout << "\tBSM - ID: " << bsm.get_TemporaryId() << ", Location: (" << bsm.get_Latitude() << "," << bsm.get_Longitude() << ")" << endl;

	// Remove unneeded nodes.
	childTree.erase("msgID");
	childTree.erase("blob1");

	// BSM part 2 is not needed for now either.
	childTree.erase("status");
}

std::string DsrcMobileArada::get_RTCMInfoData(boost::property_tree::ptree &msgTree, unsigned int uptime_ms)
{
	static unsigned int msgCount = 0;

	// Get the payload as an ascii hex string of bytes and remove spaces between bytes.
	string hex = msgTree.get<string>("RTCM-Corrections.rtcmSets.RTCMmsg.payload");
	hex.erase(std::remove(hex.begin(),hex.end(),' '),hex.end());

	// Format the RTCMInfoData JSON and return it.

	msgCount++;

	unsigned int byteCount = hex.length() / 2;

	std::stringstream ss;

	ss << "{" <<
	"\"RTCMInfoData\":{" <<
	"\"MsgCount\":\"" << msgCount << "\"," <<
	"\"LastMsgByteReceived\":\"" << byteCount << "\"," <<
	"\"LastMsgTimeStampUTC\":\"" << uptime_ms << "\"" <<
	"}}";

	return ss.str();
}
