/*
 * JsonMessageParser.cpp
 *
 *  Created on: Oct 27, 2016
 *      Author: ivp
 */

#include "JsonMessageParser.h"

#include <iostream>
#include <sstream>
#include <boost/property_tree/json_parser.hpp>

using namespace std;
namespace pt = boost::property_tree;

namespace DsrcMobileArada {

// Max reasonable header length.
const uint MaxHeaderLength = 150;

JsonMessageParser::JsonMessageParser() :
	_contentLength(0)
{
	// Pre-allocate space in header for efficiency, since data is added 1 char at a time.
	_header.reserve(MaxHeaderLength);
}

JsonMessageParser::~JsonMessageParser()
{
}

void JsonMessageParser::ProcessInput(const std::string& input)
{
	ProcessInput(input.c_str(), 0, input.length());
}

// Parse input with the following format:
//
//   {"typeId": "TypeXYZ","contentType": "JSON","contentLength": "489","content":<payload>}
//
// where <payload> is a number of characters equal to the value of "contentLength".
//
void JsonMessageParser::ProcessInput(const char* input, int offset, int length)
{
	// Min possible header length.
	// Computed from the length of the following string: {"typeId":"?","contentType":"?","contentLength":"?","content":
	const uint MinHeaderLength = 62;

	// Current position within input array.
	int position = offset;

	// The end position within input.
	int inputEnd = offset + length;

	// DEBUG print all input.
//	cout << "ProcessInput: ";
//	for (int i = offset; i < length; i++)
//	{
//		cout << input[i];
//	}
//	cout << endl;

	string typeId;
	string contentType;

	// If content length has not been read from the header, then the header has not been received yet.
	if (_contentLength == 0)
	{
		// Get header.
		while (position < inputEnd)
		{
			char ch = input[position++];

			// Do not let the header grow larger than MaxHeaderLength.
			// If it is larger than MaxHeaderLength, then we are likely in the payload.
			if (_header.length() >= MaxHeaderLength)
			{
				cerr << "ProcessInput: Header much larger than expected size: " << MaxHeaderLength << endl;
				_header.clear();
				return;
			}

			// Add current char to header buffer.
			_header.append(1, ch);

			// A complete header ends in a ':'.
			// Try to parse it.
			if (ch == ':' && _header.length() >= MinHeaderLength)
			{
				// The header always ends with "content", so look for it first.
				size_t posContent = _header.find("\"content\"");
				if (posContent == string::npos)
					continue;

				// Find the position of the last comma (i.e. the comma preceding the "content" tag).
				size_t posLastComma = _header.find_last_of(",");
				if (posLastComma == string::npos)
					return;

				// Find "typeId".  This tag MUST be the first tag of the header or this parsing algorithm will fail.
				size_t posTypeId = _header.find("\"typeId\"");
				if (posTypeId == string::npos)
					return;

				//cout << "Positions: " << posContent << ", " << posLastComma << ", " << posTypeId <<endl;

				// Put the header containing the 3 tags (typeId, contentType, contentLength)
				// into a valid JSON string, then parse using a ptree.

				stringstream ss;
				ss << "{" << _header.substr(posTypeId, posLastComma - posTypeId) << "}";

				//cout << "Header Found: " << ss.str() << endl;

				pt::ptree root;

				try
				{
					istringstream input(ss.str());
					pt::read_json(input, root);
				}
				catch (pt::json_parser::json_parser_error &ex)
				{
					cerr << "Error parsing json header: " << ss.str() << endl;
					_header.clear();
					return;
				}

				try
				{
					typeId = root.get<string>("typeId");
					contentType = root.get<string>("contentType");
					_contentLength = root.get<int>("contentLength");
				}
				catch (pt::ptree_bad_path &ex)
				{
					cerr << "Invalid header.  All 3 tags not found (typeId, contentType, contentLength). " << ex.what() << endl;
					_header.clear();
					_contentLength = 0;
					return;
				}

				_payload.reserve(_contentLength);
				break;
			}
		}
	}

	// If content length is still 0, then header not found yet.
	if (_contentLength == 0)
		return;

	// Accumulate bytes into the payload.

	int available = inputEnd - position;
	int remaining = _contentLength - _payload.length();
	int lengthToCopy = min(remaining, available);

	_payload.append(&(input[position]), lengthToCopy);

	position += lengthToCopy;
	available -= lengthToCopy;
	remaining -= lengthToCopy;

	// Return if all bytes used, but entire payload not received yet.
	if (remaining > 0)
		return;

	// Entire payload received, process the payload and reset data.
	ProcessPayload(typeId, contentType, _payload);
	_header.clear();
	_payload.clear();
	_contentLength = 0;

	// Cleanup any remaining end braces or whitespace.
	while (available > 0 && (input[position] == '}' || isspace(input[position])))
	{
		position++;
		available--;
	}

	// If more data is still available, process it using recursive call.
	if (available > 0)
	{
		ProcessInput(input, position, available);
	}
}

void JsonMessageParser::ProcessPayload(const std::string& typeId, const std::string& contentType, const std::string& payload)
{
	if (contentType != "JSON")
	{
		cerr << "Unknown contentType received: " << contentType << endl;
		return;
	}

	//cout << "Payload: " << payload << endl;

	pt::ptree root;

	try
	{
		istringstream input(payload);
		pt::read_json(input, root);
	}
	catch (pt::json_parser::json_parser_error &ex)
	{
		cerr << "JSON Exception parsing json payload to ptree: " << ex.what() << endl;
		cerr << payload << endl;
		return;
	}
	catch (pt::ptree_error &ex)
	{
		cerr << "Ptree Exception parsing json payload to ptree: " << ex.what() << endl;
		cerr << payload << endl;
		return;
	}

	if (_callback)
		_callback(typeId, root);
}

} /* namespace DsrcMobileArada */
