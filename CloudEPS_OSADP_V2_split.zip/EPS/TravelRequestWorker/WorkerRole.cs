using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Storage;
using EPS.DataModel;
using Ninject;

namespace TravelRequestWorker
{
    public class WorkerRole : RoleEntryPoint
    {
        private readonly CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private readonly ManualResetEvent runCompleteEvent = new ManualResetEvent(false);
        public static IKernel Kernel = new StandardKernel();
        const int DefaultWorkerSleepTimeSec = 10;


        private TravelGroupManager _TravelGroupMgr;

        public override void Run()
        {
            Trace.TraceInformation("TravelRequestWorker is running");

            try
            {
                this.RunAsync(this.cancellationTokenSource.Token).Wait();
            }
            finally
            {
                this.runCompleteEvent.Set();
            }
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections
            ServicePointManager.DefaultConnectionLimit = 12;

            // For information on handling configuration changes
            // see the MSDN topic at https://go.microsoft.com/fwlink/?LinkId=166357.

            RegisterServices();

            bool result = base.OnStart();

            Trace.TraceInformation("TravelRequestWorker has been started");

            return result;
        }

        public override void OnStop()
        {
            Trace.TraceInformation("TravelRequestWorker is stopping");

            this.cancellationTokenSource.Cancel();
            this.runCompleteEvent.WaitOne();

            base.OnStop();

            Trace.TraceInformation("TravelRequestWorker has stopped");
        }

        private async Task RunAsync(CancellationToken cancellationToken)
        {
            // This is a sample worker implementation. Replace with your logic.
            Trace.TraceInformation("DataProcessorWorkerRole RunAsync called");


            bool runTravelGroupProcessor = Convert.ToBoolean(RoleEnvironment.GetConfigurationSettingValue("RunTravelGroupProcessor"));
        
            if (runTravelGroupProcessor)
            {
                //Diagnostics.WriteMainDiagnosticInfo(TraceEventType.Information, TraceEventId.TraceGeneral, "Starting Module Log Processor Manager");
                _TravelGroupMgr = new TravelGroupManager();
                _TravelGroupMgr.ProcessWorker.SecondsBetweenIterations = GetSleepTimeForWorker("TravelGroup");
                _TravelGroupMgr.Start();
            }

            while (!cancellationToken.IsCancellationRequested)
            {
                if (runTravelGroupProcessor && !_TravelGroupMgr.IsRunning())
                {
                    _TravelGroupMgr.Start();
                }

              

                await Task.Delay(10000);
            }
        }
        /// <summary>
        /// Load your modules or register bindings.
        /// </summary>
        private static void RegisterServices()
        {
            //Get connection string
            string connectionString = RoleEnvironment.GetConfigurationSettingValue("EPSDatabaseConnectionString");

            //This binding means that whenever Ninject encounters a dependency on IUnitOfWork, it will resolve an instance of UnitOfWork and inject it using the connection string as an arg. 
            //Kernel.Bind<IUnitOfWork>().To<UnitOfWork>().WithConstructorArgument("connectionString", connectionString);
            Kernel.Bind<EPSContext>().To<EPSContext>().WithConstructorArgument("connectionString", connectionString);

            EPSContext con = Kernel.Get<EPSContext>();
        }
        private int GetSleepTimeForWorker(string workerName)
        {
            try
            {
                string sleepTimeInSecondsAsAString = RoleEnvironment.GetConfigurationSettingValue(workerName + "SleepTimeSec");

                int sleepTimeInSeconds;
                if (int.TryParse(sleepTimeInSecondsAsAString, out sleepTimeInSeconds))
                {
                    return sleepTimeInSeconds;
                }
            }
            catch (Exception)
            {
                Trace.TraceError("Unable to retreive SleepTime value for worker " + workerName);
            }
            return DefaultWorkerSleepTimeSec;
        }
    }
}
