﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using EPS.DataModel;


namespace TravelRequestWorker
{
    public class TravelGroupManager : BaseProcManager
    {
        public TravelGroupManager()
            : base(new TravelGroupWorker())
        {}
    }
}
