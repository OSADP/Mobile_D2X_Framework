﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;

using Newtonsoft.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Storage;
using System.Text;
using Ninject;

using EPS.DataModel;
using System.Globalization;
using System.IO;
using EPS.DataModel.Classes;

namespace TravelRequestWorker
{
    public class TravelGroupWorker : BaseProcWorker
    {
        Timer maint;
        public TravelGroupWorker()
        {
             maint = new System.Threading.Timer(
    e => MaintainQueue(),
    null,
    TimeSpan.Zero,
    TimeSpan.FromSeconds(30));
            
            
        }

        public override async void PerformWork()
        {
            Trace.TraceInformation("TravelGroupWorker called");
           

            try
            {


                EPSContext db = WorkerRole.Kernel.Get<EPSContext>();

                var routes = db.BusRoutes.Where(u => u.Id == 1);

                int maxGroupSize = db.Settings.First().TravelGroupMaxMember;

                //Query table for all new entries where GroupId is null.
                List<TravelRequest> newRequests = db.TravelRequests.Where(t => t.GroupId == null).ToList();
                //2.Foreach new entry E:
                foreach (var e in newRequests)
                {
                    //Determine if taxi or transit (only transitRoute(transitPickupStop) OR taxiPickupLat(/Long, taxDestLat/Long) will be specified, not both)
                    bool isTransit = e.TransitRoute != "";
                    if (isTransit)
                    {
                        //a.Query TravelRequests for same TransitRoute and TransitPickupStop and GroupID != null (e.g has been assigned).  and is Active.
                        var similarReq = db.TravelRequests.Where(s => s.TransitRoute == e.TransitRoute && s.TransitPickupStop == e.TransitPickupStop
                        && s.GroupId != null && s.Status == EPS.DataModel.Classes.TravelReqStatus.Active);//.OrderBy(s=>s.GroupId);
                        if (similarReq.Count() > 0)
                        {
                            //Find a group that has less than max members (e.g. has room for more)
                            var byOpenGroup = similarReq.GroupBy(g => g.GroupId).Select(group => new
                            {
                                GroupId = group.Key,
                                Count = group.Count()
                            }).Where(o => o.Count < maxGroupSize).FirstOrDefault();
                            if (byOpenGroup != null)
                            {
                                //Become a member of this existing group
                                Trace.TraceInformation("Joining Group as Follower for Transit request.  TravelerRequest.Id=" + e.Id);
                                e.GroupId = byOpenGroup.GroupId;
                                e.IsLeader = false;
                            }
                            else
                            {
                                //All matching groups are full. Create a new group and make this member Leader
                                Trace.TraceInformation("Creating Group as Leader for Transit request. Current Groups Full.  TravelerRequest.Id=" + e.Id);
                                e.GroupId = Guid.NewGuid();
                                e.IsLeader = true;

                            }
                            await db.SaveChangesAsync();  //Save so next newRequest will have updated counts to reflect change.
                        }
                        else
                        {
                            //No matching group.  Create New GroupId, Record new GroupId for E, IsLeader = true.
                            Trace.TraceInformation("Creating Group as Leader for Transit request.  TravelerRequest.Id=" + e.Id);
                            e.GroupId = Guid.NewGuid();
                            e.IsLeader = true;
                            await db.SaveChangesAsync();  //Save so next newRequest will have updated counts to reflect change.
                        }
                    }
                    else//taxi
                    {
                        //Taxi requests can have any pickup lat/long and any destination lat/long.
                        //Here is where the lat/long of the pickup would have to be compared to be "near" another traveler's pickup.
                        //And even eventually, that their destination is also the same or along the same route (very future dev).
                        //However, none of this is supported for this first draft cloud grouping. For now, there is no 'near' algorithm
                        //yet here so every taxi traveler will be considered as different and will become leader of their own group of 1.

                        Trace.TraceInformation("Creating Group as Leader for Taxi request.  TravelerRequest.Id=" + e.Id);
                        //Create New GroupId, Record new GroupId , IsLeader = true.
                        e.GroupId = Guid.NewGuid();
                        e.IsLeader = true;
                        await db.SaveChangesAsync();  //Save so next newRequest will have updated counts to reflect change.

                    }
                }

              

            }
            catch (Exception ex)
            {
                Trace.TraceError("Exception occurred in TravelGroupWorker performWork. " +
                               ex.Message + " " + ex.StackTrace);
            }
          
        }

        /// <summary>
        ///  //Do some queue maintenance every so often.
        /// </summary>
        private async void MaintainQueue()
        {
            EPSContext db = WorkerRole.Kernel.Get<EPSContext>();

            int seconds = GetExpireTravelRequestSec();

            TimeSpan heartbeatMin = new TimeSpan(0, 0, seconds); //could causes issues when debugging ending things we're still using! Prb in release we'd want a number more like 30 sec. 
                                                          
            //For each active member, query their latest heartbeat. If heartbeat older than X seconds, set status to not active.
            //If leader, cancel trip and and cancel followers.
            foreach (var x in db.TravelRequests.Where(i => i.Status == TravelReqStatus.Active))
            {
                var latest = db.Heartbeats.Where(j => j.FollowerId == x.FollowerId).OrderByDescending(d => d.Time).FirstOrDefault();
                if (latest != null)
                {
                    //See if time of latest heartbeat is close enough to now.
                    if (DateTime.UtcNow > latest.Time + heartbeatMin)
                    {
                        //Haven't heard from them in time. End their request.
                        x.Status = TravelReqStatus.Expired;
                        Trace.TraceInformation("Expiring travel request due to old heatbeat. TravelerRequest.Id=" + x.Id);
                    }
                }
                else
                {
                    //No heartbeats yet for this user. See if time of travel request is close enough to now.
                    if (DateTime.UtcNow > x.Time + heartbeatMin)
                    {
                        //Haven't heard from them in time. End their request.
                        x.Status = TravelReqStatus.Expired;
                        Trace.TraceInformation("Expiring travel request due to no heatbeat. TravelerRequest.Id=" + x.Id);
                    }
                }
            }
            await db.SaveChangesAsync();
        }

        /// <summary>
        /// Keep in mind, the thread only fires to check every 30 seconds (hardcoded) , so values less than that can't be enforced except through luck /coincidence.
        /// </summary>
        /// <returns></returns>
        private int GetExpireTravelRequestSec()
        {
            try
            {
                string timeInSecondsAsAString = RoleEnvironment.GetConfigurationSettingValue("ExpireTravelRequestSec");

                int timeInSeconds;
                if (int.TryParse(timeInSecondsAsAString, out timeInSeconds))
                {
                    return timeInSeconds;
                }
            }
            catch (Exception)
            {
                Trace.TraceError("Unable to retreive ExpireTravelRequestSec value. Using 30.");
            }
            return 30;
        }
    }


}
