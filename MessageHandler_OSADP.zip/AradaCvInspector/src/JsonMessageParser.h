/*
 * JsonMessageParser.h
 *
 *  Created on: Oct 27, 2016
 *      Author: ivp
 */

#ifndef SRC_JSONMESSAGEPARSER_H_
#define SRC_JSONMESSAGEPARSER_H_

#include <string>
#include <boost/function.hpp>
#include <boost/property_tree/ptree.hpp>

namespace DsrcMobileArada {

typedef boost::function<void (const std::string&, boost::property_tree::ptree&)> ReceivePtreeMessage;

class JsonMessageParser {
public:
	JsonMessageParser();
	virtual ~JsonMessageParser();

	void SetReceiveCallback(ReceivePtreeMessage callback)
	{
		_callback = callback;
	}

	void ProcessInput(const std::string& input);
	void ProcessInput(const char* input, int offset, int length);

private:
	ReceivePtreeMessage _callback;

	std::string _header;
	std::string _payload;
	int _contentLength;

	void ProcessPayload(const std::string& typeId, const std::string& contentType, const std::string& payload);
};

} /* namespace DsrcMobileArada */

#endif /* SRC_JSONMESSAGEPARSER_H_ */
