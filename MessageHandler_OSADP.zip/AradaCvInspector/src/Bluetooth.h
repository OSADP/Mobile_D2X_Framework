/*
 * Bluetooth.h
 *
 *  Created on: Jan 8, 2016
 *      Author: gmb
 */

#ifndef SRC_BLUETOOTH_H_
#define SRC_BLUETOOTH_H_

#define MAX_CONNECTIONS 1
#define BT_MAC_STRING_LENGTH 50
#define MAX_DEVICES 100
#define MAX_QUERY_DELAY_SEC 5
#define DELAY_LENGTH_SEC 1.28
#define MAX_TIMEOUT 8000

#include "SocketStream.h"
#include <iostream>
#include <string>
#include <map>
#include <cerrno>
#include <cmath>
#include <boost/atomic.hpp>
#include <boost/thread.hpp>
#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
#include <bluetooth/rfcomm.h>
#include <bluetooth/sdp.h>
#include <bluetooth/sdp_lib.h>

#include "JsonMessageParser.h"

void btServer_serverStart(void *arg);
void btServer_clientRun(void *arg);

namespace DsrcMobileArada {

typedef struct
{
	bool isConnected;
	int sock;
	boost::thread *thread;
	char macString[BT_MAC_STRING_LENGTH];
	JsonMessageParser jsonParser;
} BtClient;

/**
 * This class is the base class for both the server and client side Bluetooth connection.
 */
class BluetoothBase {
public:
	// Constructor
	BluetoothBase() :
			dev(-1), devSock(-1), btoothChannel(-1), btoothSocket(-1) {	};

	// Bluetooth connection functions
	int openHCIDevice();
	int closeHCIDevice();
	int connect(const char* bdAddress, int channel);
	int disconnect();

	// Getters and setters
	int getHCIDeviceId();
	void setHCIDeviceId(int id) { if (id > 0) this->dev = id; };
	int getChannel() { return this->btoothChannel; };
	int getSocket() { return this->btoothSocket; };
	void setSocket(int socket) { if (socket >=0) this->btoothSocket = socket; };
	bool isConnected() { return (this->getSocket() >= 0); };
private:
	int dev;
	int devSock;
protected:
	int btoothChannel;
	int btoothSocket;
};

/**
 * The Bluetooth "server" class
 */
class BluetoothServer : public BluetoothBase {
public:
	BluetoothServer(int channel) :
		BluetoothBase::BluetoothBase(),
		_stopBtServerThread(false), _stopConverterThread(false),
		_btServerThread(NULL), _converterThread(NULL)
	{
		btoothChannel = channel;
	};

	BtClient btClients[MAX_CONNECTIONS];

	void SetReceiveCallback(ReceivePtreeMessage callback)
	{
		for (int i=0; i < MAX_CONNECTIONS; i++)
			btClients[i].jsonParser.SetReceiveCallback(callback);
	}

	// Server administration functions
	void start(const char* uuid);
	void stop();
	bool isRunning();
	void initAdapter();

	// Communication stream
	void sendRawMessageToAllClients(const char* message);
	void sendXmlMessageToAllClients(const char* xml);

	// Friend functions
	friend void btServer_serverStart(void *arg);
	friend void btServer_clientRun(void *arg);

	boost::atomic<bool> _stopBtServerThread;
	boost::atomic<bool> _stopConverterThread;

private:
	// Shared data members
	boost::thread *_btServerThread;
	boost::thread *_converterThread;

	// Internal functions
	void registerService(const char* uuid);
	void destroyClients();
	int str2uuid(const char* uuid_str, uuid_t* uuid);
};



} // namespace
#endif /* SRC_BLUETOOTH_H_ */
