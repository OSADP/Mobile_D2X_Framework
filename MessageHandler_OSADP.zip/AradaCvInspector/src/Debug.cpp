#include "Debug.h"


const int dbgm_verbose= (DBGM_GEN | DBGM_CF | DBGM_RES | DBGM_ON | DBGM_APP);
const int dbgm_info= (DBGM_GEN | DBGM_BT | DBGM_UI | DBGM_CF | DBGM_WR | DBGM_RES | DBGM_ON | DBGM_APP);
const int dbgm_warning= (DBGM_GEN | DBGM_GPS | DBGM_BT | DBGM_UI | DBGM_CF | DBGM_WR | DBGM_RES | DBGM_ON | DBGM_APP);
const int dbgm_error = (DBGM_GEN | DBGM_GPS | DBGM_BT | DBGM_UI | DBGM_CF | DBGM_WR | DBGM_RES | DBGM_ON | DBGM_APP);

