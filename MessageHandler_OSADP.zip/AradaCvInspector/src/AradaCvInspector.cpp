//============================================================================
// Name        : AradaCvInspector.cpp
// Author      : 
// Version     :
// Copyright   : 
// Description : Receive DSRC messages on Arada and send to mobile application
//               via Bluetooth.
//============================================================================

#include <getopt.h>
#include <map>
#include <iostream>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sstream>
#include <unistd.h>
#include <vector>
#include <asn_j2735_r41/BasicSafetyMessage.h>
#include <asn_j2735_r41/MapData.h>
#include <asn_j2735_r41/PersonalSafetyMessage.h>
#include <asn_j2735_r41/PersonalMobilityMessage.h>
#include <asn_j2735_r41/RoadSideAlert.h>
#include <asn_j2735_r41/RTCM-Corrections.h>
#include <asn_j2735_r41/SPAT.h>
#include <asn_j2735_r41/TravelerInformation.h>
#include <asn_j2735_r41/UPERframe.h>
#include <asn_j2735_r41/DSRCmsgID.h>
#include <boost/atomic.hpp>
#include <boost/chrono.hpp>
#include <boost/foreach.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <tmx/TmxApiMessages.h>
#include <DecodedBsmMessage.h>
#include <BsmConverter.h>
#include <PmmDocument.h>
#include <PsmDocument.h>

#include "MapJsonTest.h"
#include "Bluetooth.h"
#include "FrequencyThrottle.h"
#include "JsonMessageParser.h"
#include "XmlToJson.h"

#include "GpsAdapter.h"

#ifdef __cplusplus
extern "C"
{
#endif
	#include <wave.h>
#ifdef __cplusplus
}
#endif

#undef XML
#undef __USE_MISC

using namespace std;
using namespace boost::chrono;
using namespace tmx::utils;
using namespace tmx::messages;
using namespace DsrcMobileArada;

typedef boost::mutex mutex;

namespace pt = boost::property_tree;

#define CHANNEL_ACCESS_MODE CHACCESS_CONTINUOUS
//#define CHANNEL_ACCESS_MODE CHACCESS_ALTERNATIVE

#define CHAN_BSM 172
#define CHAN_RTCM 172
#define CHAN_MAP_SPAT 172
#define CHAN_RSA_TIM 172
#define CHAN_PSM 172
#define CHAN_PMM 172

#define PSID_BSM 0x20
#define PSID_RTCM 0x8000
#define PSID_MAP_SPAT 0x8002
#define PSID_RSA_TIM 0x8003
#define PSID_PSM 0x8030
#define PSID_PMM 0x8031

struct ChanPsidIndex
{
	uint32_t psid;
	uint16_t chan;

	bool operator== (const ChanPsidIndex &cmp) const
	{
		return this->psid == cmp.psid && this->chan == cmp.chan;
	}

	bool operator< (const ChanPsidIndex &cmp) const
	{
		std::stringstream ss1, ss2;
		ss1 << this->psid << "||" << this->chan;
		ss2 << cmp.psid << "||" << cmp.chan;
		return ss1.str() < ss2.str();
	}
};

system_clock::time_point _startTime;
pid_t _pid;
map<ChanPsidIndex, WMEApplicationRequest> _providers;

map<string, uint64_t> _messageCounts;
mutex _mutexMessageCounts;

int _flagBsm = 0;
int _flagMap = 0;
int _flagSpat = 0;
int _flagTim = 0;
int _flagRsa = 0;
int _flagRtcm = 0;
int _flagPsm = 0;
int _flagPmm = 0;
int _flagTxBsm = 1;
int _flagTxPmm = 0;
int _flagTxPsm = 0;

boost::atomic<int> _newFlagTxBsm(1);
boost::atomic<int> _newFlagTxPmm(0);
boost::atomic<int> _newFlagTxPsm(0);

FrequencyThrottle<uint32_t> _bsmFrequencyThrottle(milliseconds(500));
FrequencyThrottle<std::string> _mapFrequencyThrottle(milliseconds(2000));
FrequencyThrottle<std::string> _spatFrequencyThrottle(milliseconds(200));
FrequencyThrottle<uint32_t> _timFrequencyThrottle(milliseconds(500));
FrequencyThrottle<uint32_t> _psmFrequencyThrottle(milliseconds(500));
FrequencyThrottle<uint32_t> _myLocationFrequencyThrottle(milliseconds(250));
FrequencyThrottle<uint32_t> _sendBsmFrequencyThrottle(milliseconds(100));
FrequencyThrottle<uint32_t> _sendPmmFrequencyThrottle(milliseconds(1000));
FrequencyThrottle<uint32_t> _sendPsmFrequencyThrottle(milliseconds(100));

PmmDocument _pmmDoc;
mutex _mutexPmmDoc;

PsmDocument _psmDoc;
mutex _mutexPsmDoc;
system_clock::time_point _lastPsmDocUpdateTime = system_clock::now() - hours(1);
const milliseconds _psmDocStaleTimeout(4000);

boost::thread *_btThread = NULL;
boost::atomic<bool> _stopBtThread(false);
FILE *_pipeInput = NULL;

void (*oldsig_int)(int);
void (*oldsig_kill)(int);
void (*oldsig_quit)(int);
void (*oldsig_term)(int);
void (*oldsig_segv)(int);

void sig(int sig)
{
	cerr << endl << "interrupt signal: " << sig << ", cleaning up." << endl;

	if (_btThread != NULL)
	{
		_stopBtThread = true;
		if (_pipeInput != NULL)
		{
			fputc(EOF, _pipeInput);
			fflush(_pipeInput);
		}
		_btThread->join();
		delete _btThread;
		_btThread = NULL;
	}

	gps_destroy();

	signal(SIGINT, oldsig_int);
	signal(SIGKILL, oldsig_kill);
	signal(SIGQUIT, oldsig_quit);
	signal(SIGTERM, oldsig_term);
	signal(SIGSEGV, oldsig_segv);

	for (map<ChanPsidIndex, WMEApplicationRequest>::iterator itr = _providers.begin(); itr != _providers.end(); itr++)
	{
		removeProvider(_pid, &(itr->second));
	}

	closeWAVEDevice();

	raise(sig);
}

// Helper method to convert a channel/psid to a string.
std::string ChanPsidToString(uint16_t channel, uint32_t psid, bool includePsidAndChan)
{
	stringstream ss;

	if (channel == CHAN_BSM && psid == PSID_BSM)
		ss << "BSM";
	else if (channel == CHAN_RTCM && psid == PSID_RTCM)
		ss << "RTCM";
	else if (channel == CHAN_MAP_SPAT && psid == PSID_MAP_SPAT)
		ss << "MAP & SPAT";
	else if (channel == CHAN_RSA_TIM && psid == PSID_RSA_TIM)
		ss << "RSA & TIM";
	else if (channel == CHAN_PSM && psid == PSID_PSM)
		ss << "PSM";
	else if (channel == CHAN_PMM && psid == PSID_PMM)
		ss << "PMM";
	else
	{
		// If there is not a friendly name, always return channel and psid.
		ss << "Channel " << channel << ", PSID 0x" << hex << psid;
		return ss.str();
	}

	if (includePsidAndChan)
		ss << ", Channel " << channel << ", PSID 0x" << hex << psid;

	return ss.str();
}

uint64_t UptimeMilliseconds()
{
	milliseconds uptime_ms = duration_cast<milliseconds>(system_clock::now() - _startTime);
	return uptime_ms.count();
}

string UptimeHeader()
{
	float uptimeSec = (float)UptimeMilliseconds() / 1000.0;
	stringstream ss;
	ss.precision(2);
	ss << std::fixed << uptimeSec << " - ";
	ss.precision(8);
	return ss.str();
}

void AddMessageCount(const string &name)
{
	boost::lock_guard<mutex> lock(_mutexMessageCounts);

	map<string, uint64_t>::iterator entry = _messageCounts.find(name);

	if (entry == _messageCounts.end())
		_messageCounts.insert(pair<string, uint64_t>(name, 1));
	else
		entry->second = entry->second + 1;
}

// Returns true on success; false otherwise.
bool AddProviderEntry(int channel, int psid)
{
	ChanPsidIndex index;
	index.chan = channel;
	index.psid = psid;

	map<ChanPsidIndex, WMEApplicationRequest>::iterator providerEntry = _providers.find(index);

	if (providerEntry == _providers.end())
	{
		// Add app request entry to the map first, so that it is constructed in the map.
		// Then get a reference to the entry of the map, since a pointer to it is passed to registerProvider.

		WMEApplicationRequest base;
		_providers.insert(pair<ChanPsidIndex, WMEApplicationRequest>(index, base));
		WMEApplicationRequest &entry = _providers[index];

		entry.psid = index.psid;
		entry.priority = 31;
		entry.channel = index.chan;
		entry.serviceport = 0;
		entry.ipservice = 0;
		entry.repeatrate = 50;
		entry.linkquality = 1;
		entry.channelaccess = CHANNEL_ACCESS_MODE;

		// Register the provider.

		int registerStatus = registerProvider(_pid, &entry);

		bool success = registerStatus >= 0;

		cout << "Register Provider (" << ChanPsidToString(entry.channel, entry.psid, true) << "): ";
		if (success)
			cout << "Success" << endl;
		else
			cout << "Failed (" << registerStatus << ")" << endl;

		if (!success)
			_providers.erase(index);

		return success;
	}

	return true;
}

// Add provider entry, retrying on error.
void AddProviderEntryWithRetry(int channel, int psid)
{
	for (int i=0; i < 10; i++)
	{
		if (AddProviderEntry(channel, psid))
			return;

		usleep(100000);
	}
}

void RemoveProviderEntry(int channel, int psid)
{
	ChanPsidIndex index;
	index.chan = channel;
	index.psid = psid;

	map<ChanPsidIndex, WMEApplicationRequest>::iterator providerEntry = _providers.find(index);

	if (providerEntry != _providers.end())
	{
		removeProvider(_pid, &(providerEntry->second));
		_providers.erase(index);
	}
}

void Receive_WSMIndication(WSMIndication *rxpkt)
{
	//printf("Received WSM Packet: Channel = %d, PSID = %d\n", rxpkt->chaninfo.channel, rxpkt->psid);

	// Track how many times a message has been received.
	// **** This is no longer done here, but instead when the received message is processed ****
	//AddMessageCount(ChanPsidToString(rxpkt->chaninfo.channel, rxpkt->psid, false));
}

void Receive_WMENotifIndication(WMENotificationIndication *wmeindication)
{

}

void Receive_WRSSIndication(WMEWRSSRequestIndication *wrssindication)
{
	printf("WRSS receive Channel = %d   Report = %d\n",
			(u_int8_t) wrssindication->wrssreport.channel,
			(u_int8_t) wrssindication->wrssreport.wrss);
}

void Receive_sfIndication(TSFTimer *timer)
{
	printf("TSF Timer: Result=%d, Timer=%llu",
			(u_int8_t) timer->result,
			(u_int64_t) timer->timer);
}

void PrintMessageCounts()
{
	boost::lock_guard<mutex> lock(_mutexMessageCounts);

	map<string, uint64_t>::iterator iter;

	if (_messageCounts.size() == 0) return;

	cout << UptimeHeader();
	bool isFirst = true;

	for (iter = _messageCounts.begin(); iter != _messageCounts.end(); iter++)
	{
		if (!isFirst)
			cout << ", ";

		cout << iter->first << ": " << iter->second;

		isFirst = false;
	}

	cout << endl;
}

void ProcessBsm(FILE *pFile, const void* rawData, unsigned long rawDataLength)
{
	AddMessageCount("BSM");

	BasicSafetyMessage_t *bsm = NULL;
	asn_dec_rval_t rval = ber_decode(NULL, &asn_DEF_BasicSafetyMessage, (void **)&bsm, rawData, rawDataLength);

	if (rval.code == RC_OK)
	{
		// Get the BSM's temporary ID to uniquely identify it and use it to throttle
		// the frequency of BSMs sent.
		uint32_t tempId = ntohl(*(uint32_t*)(bsm->blob1.buf+1));
		//printf("Received and decoded BSM message with id: %x\n", tempId);

		if (_bsmFrequencyThrottle.Monitor(tempId))
		{
			//milliseconds ms = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
			//std::cout << ms.count() << " - BSM to JSON: " << tempId << std::endl;
			xer_fprint(pFile, &asn_DEF_BasicSafetyMessage, bsm);
			fputc(EOF, pFile);
			fflush(pFile);
		}
	}
	else
	{
		printf("Could not BER decode BSM\n");
	}
	ASN_STRUCT_FREE(asn_DEF_BasicSafetyMessage, bsm);
}

void ProcessMap(FILE *pFile, const void* rawData, unsigned long rawDataLength)
{
	AddMessageCount("MAP");

	MapData *map = NULL;
	asn_dec_rval_t rval = uper_decode_complete(NULL, &asn_DEF_MapData, (void **)&map, rawData, rawDataLength);

	if (rval.code == RC_OK)
	{
		// Get a unique ID for throttling by combining all intersection or roadway IDs into a string.
		std::ostringstream id;

		for (int i=0; map->intersections != NULL && i < map->intersections->list.count; i++)
		{
			if (!id.str().empty()) id << ",";
			id << map->intersections->list.array[i]->id.id;
		}

		for (int i=0; map->roadSegments != NULL && i < map->roadSegments->list.count; i++)
		{
			if (!id.str().empty()) id << ",";
			id << map->roadSegments->list.array[i]->id.id;
		}

		//printf("Received and decoded MAP message: %s.\n", id.str().c_str());

		if (_mapFrequencyThrottle.Monitor(id.str()))
		{
			//milliseconds ms = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
			//std::cout << ms.count() << " - MAP to JSON: " << id.str() << std::endl;
			xer_fprint(pFile, &asn_DEF_MapData, map);
			fputc(EOF, pFile);
			fflush(pFile);
		}
	}
	else
	{
		printf("Could not UPER decode MAP\n");
	}
	ASN_STRUCT_FREE(asn_DEF_MapData, map);

}

void ProcessSpat(FILE *pFile, const void* rawData, unsigned long rawDataLength)
{
	AddMessageCount("SPAT");

	SPAT *spat = NULL;
	asn_dec_rval_t rval = uper_decode_complete(NULL, &asn_DEF_SPAT, (void **)&spat, rawData, rawDataLength);

	if (rval.code == RC_OK)
	{
		// Get a unique ID for throttling by combining all intersection IDs into a string.
		std::ostringstream id;
		for (int i=0; i < spat->intersections.list.count; i++)
		{
			if (i > 0) id << ",";
			id << spat->intersections.list.array[i]->id.id;
		}

		//printf("Received and decoded SPAT message: %s.\n", id.str().c_str());

		if (_spatFrequencyThrottle.Monitor(id.str()))
		{
			//milliseconds ms = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
			//std::cout << ms.count() << " - SPAT to JSON: " << id.str() << std::endl;
			xer_fprint(pFile, &asn_DEF_SPAT, spat);
			fputc(EOF, pFile);
			fflush(pFile);
		}
	}
	else
	{
		printf("Could not UPER decode SPAT\n");
	}
	ASN_STRUCT_FREE(asn_DEF_SPAT, spat);
}

void ProcessTim(FILE *pFile, const void* rawData, unsigned long rawDataLength)
{
	AddMessageCount("TIM");

	TravelerInformation_t *tim = NULL;
	asn_dec_rval_t rval = ber_decode(NULL, &asn_DEF_TravelerInformation, (void **)&tim, rawData, rawDataLength);

	if (rval.code == RC_OK)
	{
		// Get the TIM's packet ID to uniquely identify it and use it to throttle
		// the frequency of TIMs sent.
		uint32_t packetId = ntohl(*(uint32_t*)(tim->packetID->buf));
		//printf("****** TODO: TEST and DETERMINE whether packet ID is a good value to use !!!!! *****");
		//printf("Received and decoded TIM message.\n");

		if (_timFrequencyThrottle.Monitor(packetId))
		{
			xer_fprint(pFile, &asn_DEF_TravelerInformation, tim);
			fputc(EOF, pFile);
			fflush(pFile);
		}
	}
	else
	{
		printf("Could not BER decode TIM\n");
	}
	ASN_STRUCT_FREE(asn_DEF_TravelerInformation, tim);
}

void ProcessRsa(FILE *pFile, const void* rawData, unsigned long rawDataLength)
{
	AddMessageCount("RSA");

	RoadSideAlert_t *rsa = NULL;
	asn_dec_rval_t rval = ber_decode(NULL, &asn_DEF_RoadSideAlert, (void **)&rsa, rawData, rawDataLength);

	if (rval.code == RC_OK)
	{
		xer_fprint(pFile, &asn_DEF_RoadSideAlert, rsa);
		fputc(EOF, pFile);
		fflush(pFile);
	}
	else
	{
		printf("Could not BER decode RSA\n");
	}
	ASN_STRUCT_FREE(asn_DEF_RoadSideAlert, rsa);
}

void ProcessRtcm(FILE *pFile, const void* rawData, unsigned long rawDataLength)
{
	AddMessageCount("RTCM");

	RTCM_Corrections_t *rtcm = NULL;
	asn_dec_rval_t rval = ber_decode(NULL, &asn_DEF_RTCM_Corrections, (void **)&rtcm, rawData, rawDataLength);

	if (rval.code == RC_OK)
	{
		//milliseconds ms = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
		//std::cout << ms.count() << " - RTCM to JSON. " << std::endl;
		xer_fprint(pFile, &asn_DEF_RTCM_Corrections, rtcm);
		fputc(EOF, pFile);
		fflush(pFile);
	}
	else
	{
		printf("Could not BER decode RTCM\n");
	}
	ASN_STRUCT_FREE(asn_DEF_RTCM_Corrections, rtcm);
}

void ProcessPsm(FILE *pFile, const void* rawData, unsigned long rawDataLength)
{
	AddMessageCount("PSM");

	PersonalSafetyMessage_t *psm = NULL;
	asn_dec_rval_t rval = uper_decode_complete(NULL, &asn_DEF_PersonalSafetyMessage, (void **)&psm, rawData, rawDataLength);

	if (rval.code == RC_OK)
	{
		// Get the BSM's temporary ID to uniquely identify it and use it to throttle
		// the frequency of BSMs sent.
		uint32_t tempId = ntohl(*(uint32_t*)(psm->id.buf));
		//printf("Received and decoded BSM message with id: %x\n", tempId);

		if (_psmFrequencyThrottle.Monitor(tempId))
		{
			//milliseconds ms = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
			//std::cout << " - PSM to JSON: " << id.str() << std::endl;
			xer_fprint(pFile, &asn_DEF_PersonalSafetyMessage, psm);
			fputc(EOF, pFile);
			fflush(pFile);
		}
	}
	else
	{
		printf("Could not UPER decode PSM\n");
	}
	ASN_STRUCT_FREE(asn_DEF_PersonalSafetyMessage, psm);
}

void ProcessPmm(FILE *pFile, const void* rawData, unsigned long rawDataLength)
{
	AddMessageCount("PMM");

	PersonalMobilityMessage_t *pmm = NULL;
	asn_dec_rval_t rval = uper_decode_complete(NULL, &asn_DEF_PersonalMobilityMessage, (void **)&pmm, rawData, rawDataLength);

	if (rval.code == RC_OK)
	{
		//milliseconds ms = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
		//std::cout << " - PMM to JSON: " << id.str() << std::endl;
		xer_fprint(pFile, &asn_DEF_PersonalMobilityMessage, pmm);
		fputc(EOF, pFile);
		fflush(pFile);
	}
	else
	{
		printf("Could not UPER decode PMM\n");
	}
	ASN_STRUCT_FREE(asn_DEF_PersonalMobilityMessage, pmm);
}

void SendMyLocationMessage(FILE *pFile)
{
	GPSData gpsData;
	gpsDevice_getData(gps_getDefaultDevice(), &gpsData);

	//printf("<LocationMessage><Latitude>%f</Latitude><Longitude>%f</Longitude><Speed>%f</Speed><Heading>%f</Heading></LocationMessage>",
	//		gpsData.latitude, gpsData.longitude, gpsData.speed, gpsData.course);
	//printf("\n");

	if (gpsData.latitude!=0 && gpsData.longitude!=0)
	{
		//cout << "SendMyLocationMessage" << endl;

		fprintf(pFile, "<LocationMessage><Latitude>%f</Latitude><Longitude>%f</Longitude><Speed>%f</Speed><Heading>%f</Heading></LocationMessage>",
			gpsData.latitude, gpsData.longitude, gpsData.speed, gpsData.course);

		fputc(EOF, pFile);
		fflush(pFile);

		AddMessageCount("BtTxLoc");
	}
}

/**
 * Decode the packet that was received over the radio into a message.
 * Throttle the frequency based on message type and a unique identifier.
 * Send an XML version of the message to the pipe associated with the file pointer argument.
 */
void DecodePacketAndSendToPipe(FILE *pFile, WSMIndication &rxpkt)
{
	// Grab the message ID from the DER-encoded bytes.  Should be within 6 bytes.
	int id = 0;
	int count = 0;

	int bIx;
	for (bIx = 0; bIx < rxpkt.data.length && rxpkt.data.contents[bIx] != (char)0x80 && count <= 6; bIx++, count++);
	if (count <= 6)
	{
		if (bIx < rxpkt.data.length) bIx++;

		// Next byte is length, should be one byte.
		if (bIx < rxpkt.data.length && rxpkt.data.contents[bIx] == (char)0x01)
		{
			bIx++;
			id = rxpkt.data.contents[bIx];
		}
	}

	// Print out the bytes
	/*
	for (int i = 0; i < rxpkt.data.length; i++)
		printf("%x ", (unsigned char)rxpkt.data.contents[i]);
	printf("\n");
	*/

	asn_dec_rval_t rval;

	switch (id)
	{
	case 0x11:
		// UPERframe encoded, need to decode to determine message ID.
		{
			UPERframe *frame = NULL;
			rval = ber_decode(NULL, &asn_DEF_UPERframe, (void **)&frame, rxpkt.data.contents, rxpkt.data.length);

			//cout << "contentID = " << hex << frame->contentID << endl;
			if (rval.code == RC_OK)
			{
				switch (frame->msgID)
				{
					case 0x11:
						switch (frame->contentID)
						{
							case 0x12: // MAP message.
							if (_flagMap)
							{
								ProcessMap(pFile, frame->msgBlob.buf, frame->msgBlob.size);
							}
							break;
						case 0x13: // SPAT message.
							if (_flagSpat)
							{
								ProcessSpat(pFile, frame->msgBlob.buf, frame->msgBlob.size);
							}
							break;
						case 0x20: // PSM message.
							if (_flagPsm)
							{
								ProcessPsm(pFile, frame->msgBlob.buf, frame->msgBlob.size);
							}
							break;
						case 0xF5: // PMM message
							if (_flagPmm)
							{
								ProcessPmm(pFile, frame->msgBlob.buf, frame->msgBlob.size);
							}
							break;
						default:
							printf("Invalid message type %ld\n", frame->msgID);
							break;
						}
						break;
					default:
						printf("Other type of message\n");
						break;
				}
			}
			else
			{
				printf("Could not BER decode message.\n");
			}
			ASN_STRUCT_FREE(asn_DEF_UPERframe, frame);
		}
		break;
	case DSRCmsgID_basicSafetyMessage:
		if (_flagBsm)
		{
			ProcessBsm(pFile, rxpkt.data.contents, rxpkt.data.length);
		}
		break;
	case DSRCmsgID_travelerInformation:
		if (_flagTim)
		{
			ProcessTim(pFile, rxpkt.data.contents, rxpkt.data.length);
		}
		break;
	case DSRCmsgID_rtcmCorrections:
		if (_flagRtcm)
		{
			ProcessRtcm(pFile, rxpkt.data.contents, rxpkt.data.length);
		}
		break;
	case DSRCmsgID_roadSideAlert:
		if (_flagRsa)
		{
			ProcessRsa(pFile, rxpkt.data.contents, rxpkt.data.length);
		}
		break;
	default:
		printf("Message type %d received and ignored.\n", id);
		break;
	}
}

void ReceiveDsrcSettings(pt::ptree& tree)
{
	try
	{
		// The thread-safe flags are set for TxBsm and TxPsm.
		// Then the provider is added/removed as appropriate from the main thread.
		_newFlagTxBsm = tree.get<bool>("SendBsm");
		_newFlagTxPmm = tree.get<bool>("SendPmm");
		_newFlagTxPsm = tree.get<bool>("SendPsm");
	}
	catch (pt::ptree_error &ex)
	{
		cerr << "Invalid DsrcSettings received: " << ex.what() << endl;
		pt::write_json(cerr, tree, true);
		return;
	}

	cout << "DsrcSettings: SendBsm: " << _newFlagTxBsm << ", SendPmm: " << _newFlagTxPmm << ", SendPsm: " << _newFlagTxPsm << endl;
}

void ReceivePsmSettings(pt::ptree& tree)
{
	int numberPedestrians = -1;
	int radiusOfProtection = -1;

	try
	{
		numberPedestrians = tree.get<int>("NumberPedestrians");
		radiusOfProtection = tree.get<int>("RadiusOfProtection");

		boost::lock_guard<mutex> lock(_mutexPsmDoc);

		_psmDoc.set_ClusterSizeFromNumberOfParticipants(numberPedestrians);
		_psmDoc.set_ClusterRadius(radiusOfProtection);
	}
	catch (pt::ptree_error &ex)
	{
		cerr << "Invalid PsmSettings received: " << ex.what() << endl;
		pt::write_json(cerr, tree, true);
		return;
	}

	cout << "PsmSettings: NumberPedestrians: " << numberPedestrians << ", RadiusOfProtection: " << radiusOfProtection << " m" << endl;
}

void ReceiveLocation(pt::ptree& tree)
{
	try
	{
		pt::ptree& message = tree.get_child("LocationMessage");

		boost::lock_guard<mutex> lock(_mutexPsmDoc);

		_psmDoc.set_BasicType(PersonalDeviceUserType_aPEDESTRIAN);
		_psmDoc.set_Latitude(message.get<double>("Latitude"));
		_psmDoc.set_Longitude(message.get<double>("Longitude"));
		_psmDoc.set_Elevation(message.get<double>("Elevation"));
		_psmDoc.set_Speed_kmph(message.get<double>("Speed"));
		_psmDoc.set_Heading_deg(message.get<double>("Heading"));

		_psmDoc.set_PathPredictionToStraight(1);
		_psmDoc.update_PathHistory(false);

		_lastPsmDocUpdateTime = system_clock::now();

		AddMessageCount("BtRxLoc");

		//cout << "Location: " << message.get<double>("Latitude") << ", " << message.get<double>("Longitude") << endl;
	}
	catch (pt::ptree_error &ex)
	{
		cerr << "Invalid Location received: " << ex.what() << endl;
		pt::write_json(cerr, tree, true);
		return;
	}
}

void ReceivePmm(pt::ptree& tree)
{
	try
	{
		pt::ptree& message = tree.get_child("PersonalMobilityMessage");

		boost::lock_guard<mutex> lock(_mutexPmmDoc);
		_pmmDoc.set_GroupId(message.get<string>("groupId"));
		_pmmDoc.set_RequestId(message.get<string>("requestId"));
		_pmmDoc.set_Status(message.get<string>("status"));
		_pmmDoc.set_Position(message.get<int>("position.lat"), message.get<int>("position.long"));

		pt::ptree& requestDate = message.get_child("requestDate");
		_pmmDoc.set_RequestDate(requestDate.get<int>("year"), requestDate.get<int>("month"),
				requestDate.get<int>("day"), requestDate.get<int>("hour"), requestDate.get<int>("minute"));

		pt::ptree& pickupDate = message.get_child("pickupDate");
		_pmmDoc.set_PickupDate(pickupDate.get<int>("year"), pickupDate.get<int>("month"),
				pickupDate.get<int>("day"), pickupDate.get<int>("hour"), pickupDate.get<int>("minute"));

		_pmmDoc.set_Destination(message.get<int>("destination.lat"), message.get<int>("destination.lon"));

		vector<MobilityNeed> mobilityNeeds;
		BOOST_FOREACH(pt::ptree::value_type &mobilityNeed, message.get_child("mobilityNeeds"))
		{
			MobilityNeed need;
			need.Type = mobilityNeed.second.get<string>("type");
			need.Count = mobilityNeed.second.get<int>("count");
			mobilityNeeds.push_back(need);
		}
		_pmmDoc.set_MobilityNeeds(mobilityNeeds);

		_pmmDoc.set_ModeOfTransport(message.get<string>("modeOfTransport"));
		_pmmDoc.set_Eta(message.get<int>("eta"));
		_pmmDoc.set_IsDsrcEquipped(message.get<bool>("isDSRCEquipped"));
		_pmmDoc.set_VehicleDesc(message.get<string>("vehicleDesc"));

		AddMessageCount("BtRxPmm");
	}
	catch (pt::ptree_error &ex)
	{
		cerr << "Invalid PMM received: " << ex.what() << endl;
		pt::write_json(cerr, tree, true);
		return;
	}
}

void ReceiveClientData(const std::string& typeId, pt::ptree& tree)
{
	if (typeId == "DsrcSettings")
		ReceiveDsrcSettings(tree);
	else if (typeId == "PsmSettings")
		ReceivePsmSettings(tree);
	else if (typeId == "Location")
		ReceiveLocation(tree);
	else if (typeId == "PMM")
		ReceivePmm(tree);
	else
		cout << "Unknown client message received: " << typeId << endl;
}

void JsonParserTest()
{
	JsonMessageParser parser;
	parser.SetReceiveCallback(&ReceiveClientData);

	string json1 = "{\"typeId\": \"Location\",\"contentType\": \"JSON\",\"contentLength\":\"126\",\"content\":{\"LocationMessage\":{\"Latitude\":39.98929439,\"Longitude\":-83.02066332,\"Speed\":0.25317975878715515,\"Heading\":237.19999694824219}}}";
	string json2 = "{\"typeId\": \"Location\",\"contentType\": \"JSON\",\"contentLength\":\"95\",\"content\":{\"LocationMessage\":{\"Latitude\":39.97870252,\"Longitude\":-83.01997871,\"Speed\":0.0,\"Heading\":0.0}}  }fs sdfs sas {\"typeId\": \"TypeXYZ\",\"contentType\": \"JSON\",\"contentLength\":\"95\",\"content\":{\"LocationMessage\":{\"Latitude\":39.96870252,\"Longitude\":-83.01997871,\"Speed\":0.0,\"Heading\":0.0}}  }";
	string json3 = "{\"typeId\": \"Location\",\"contentType\": \"JSON\",\"contentLength\":\"9";
	string json4 = "5\",\"content\":{\"LocationMessage\":{\"Latitude\":39.95870252,\"Longitude\":-83.01997871,\"Speed\":0.0,\"Heading\":0.0}}}";
	string jsonPmm = "{\"typeId\":\"PMM\",\"contentType\":\"JSON\",\"contentLength\":\"546\",\"content\":{\"PersonalMobilityMessage\":{\"groupId\":\"01234567-89ab-cdef-0123-456789abcdef\",\"requestId\":\"1\",\"status\":\"new\",\"position\":{\"lat\":\"432222220\",\"long\":\"-839999990\"},\"requestDate\":{\"year\":\"2016\",\"month\":\"9\",\"day\":\"24\",\"hour\":\"14\",\"minute\":\"33\"},\"pickupDate\":{\"year\":\"2016\",\"month\":\"9\",\"day\":\"24\",\"hour\":\"15\",\"minute\":\"33\"},\"destination\":{\"lon\":\"-837777770\",\"lat\":\"431111110\"},\"mobilityNeeds\":[{\"type\":\"noSpecialNeeds\",\"count\":\"4\"}],\"modeOfTransport\":\"noPreference\",\"eta\":\"0\",\"isDSRCEquipped\":\"false\",\"vehicleDesc\":\"THis is a description\",\"regional\":\"\"}}}";
	string jsonPmm2 = "{\"typeId\":\"PMM\",\"contentType\":\"JSON\",\"contentLength\":\"575\",\"content\":{\"PersonalMobilityMessage\":{\"groupId\":\"a0ef14b8-f84c-4503-99ec-245f3c285d14\",\"requestId\":\"1\",\"status\":null,\"position\":{\"lat\":39.98878801,\"Latitude\":3.9988788010000004E-06,\"long\":-83.02081206,\"Longitude\":-8.302081206E-06},\"requestDate\":{\"year\":2016,\"month\":12,\"day\":13,\"hour\":13,\"minute\":53},\"pickupDate\":{\"year\":2016,\"month\":12,\"day\":13,\"hour\":13,\"minute\":53},\"destination\":{\"lon\":-83.020869679749012,\"lat\":39.987961879642633},\"mobilityNeeds\":[{\"type\":\"NoSpecialNeeds\",\"count\":\"1\"}],\"modeOfTransport\":\"0\",\"eta\":null,\"isDSRCEquipped\":false,\"vehicleDesc\":null,\"regional\":null}}}";
	string jsonPmm3 = "{\"typeId\":\"PMM\",\"contentType\":\"JSON\",\"contentLength\":\"574\",\"content\":{\"PersonalMobilityMessage\":{\"groupId\":\"a0ef14b8-f84c-4503-99ec-245f3c285d14\",\"requestId\":\"1\",\"status\":null,\"position\":{\"lat\":39.98878801,\"Latitude\":3.9988788010000004E-06,\"long\":-83.02081206,\"Longitude\":-8.302081206E-06},\"requestDate\":{\"year\":2016,\"month\":12,\"day\":13,\"hour\":13,\"minute\":53},\"pickupDate\":{\"year\":2016,\"month\":12,\"day\":13,\"hour\":13,\"minute\":53},\"destination\":{\"lon\":-83.020869679749012,\"lat\":39.987961879642633},\"mobilityNeeds\":[{\"type\":\"NoSpecialNeeds\",\"count\":\"1\"}],\"modeOfTransport\":\"0\",\"eta\":\"0\",\"isDSRCEquipped\":false,\"vehicleDesc\":null,\"regional\":null}}}";

	string settings1 = "{\"typeId\": \"DsrcSettings\",\"contentType\": \"JSON\",\"contentLength\":\"31\",\"content\":{\"SendBsm\":true,\"SendPsm\":true}}";
	string settings2 = "{\"typeId\": \"DsrcSettings\",\"contentType\": \"JSON\",\"contentLength\":\"33\",\"content\":{\"SendBsm\":false,\"SendPsm\":false}}";

	//parser.ProcessInput(json1);
	//parser.ProcessInput(json2);
	//parser.ProcessInput(json3);
	//parser.ProcessInput(json4);
	parser.ProcessInput(jsonPmm3);

	//parser.ProcessInput(settings1);
	//parser.ProcessInput(settings2);
}

/**
 * Thread that starts the bluetooth worker.
 * It reads XML messages from the pipe (from the main thread) and
 * then sends the messages over bluetooth (after it is translated into JSON).
 * It also receives messages from the bluetooth client.
 */

void BluetoothThread(int pipefd)
{
	cout << "Starting Bluetooth Thread." << endl;

	BluetoothServer srv(13);
	srv.SetReceiveCallback(&ReceiveClientData);
	srv.start("6ba50000-7c6a-11e3-9b95-0002a5d5c51b");

	stringstream ss;
	string jsonMsg;

	char buf;
	while (read(pipefd, &buf, 1) > 0)
	{
		if (_stopBtThread)
			break;

		if (buf == EOF)
		{
			srv.sendXmlMessageToAllClients(ss.str().c_str());

			ss.seekp(0);
			ss.seekg(0);
			ss.str("");
			ss.clear();
		}
		else
		{
			ss << buf;
		}
	}

	srv.stop();

	cout << "Bluetooth: Exiting thread." << endl;
}

bool TransmitPacket(asn_TYPE_descriptor_t *msgType, void *msgStruct, int txChannel, uint32_t psid)
{
	// Fill request header information.
	WSMRequest request;
	request.chaninfo.channel = txChannel;
	request.chaninfo.rate = 6;
	request.chaninfo.txpower = 14;
	request.version = 2;
	request.psid = psid;
	request.wsmps = 0;
	request.txpriority = 2;
	request.security = 0;
	request.macaddr[0] = 255;
	request.macaddr[1] = 255;
	request.macaddr[2] = 255;
	request.macaddr[3] = 255;
	request.macaddr[4] = 255;
	request.macaddr[5] = 255;
	//request.expirytime = ? ;

	getMACAddr(request.srcmacaddr, txChannel);

	memset(&request.data, 0, sizeof(WSMData));

	asn_enc_rval_t rvalenc = der_encode_to_buffer(msgType, msgStruct, &request.data.contents, HALFK);

	if (rvalenc.encoded == -1)
	{
		cout << "TransmitPacket: Error encoding structure." << endl;
		return false;
	}

	request.data.length = rvalenc.encoded;
	int ret = txWSMPacket(getpid(), &request);
	if (ret < 0)
	{
		cout << "TransmitPacket: Error transmitting packet." << endl;
		return false;
	}

	return true;
}

uint32_t GetTempId()
{
	// Use last 4 octets of mac address for the temporary id.
	u_int8_t mac[IEEE80211_ADDR_LEN];
	getMACAddr(mac, CHAN_BSM);
	uint32_t tempId = ntohl(*(uint32_t*)(mac+2));
	//printf("Temp ID: 0x%x\n", tempId);
	return tempId;
}

void SendBsm()
{
	static BasicSafetyMessage_t bsmJ2735;
	static tmx::messages::DecodedBsmMessage bsm;
	static uint32_t tempId = GetTempId();

	GPSData gpsData;
	gpsDevice_getData(gps_getDefaultDevice(), &gpsData);

	if (gpsData.latitude != 0 && gpsData.longitude != 0)
	{
		bsm.set_TemporaryId(tempId);

		bsm.set_Latitude(gpsData.latitude);
		bsm.set_Longitude(gpsData.longitude);
		bsm.set_Speed_mph(gpsData.speed);
		bsm.set_Heading(gpsData.course);

		bsm.set_IsLocationValid(true);
		bsm.set_IsSpeedValid(true);
		bsm.set_IsHeadingValid(true);

		bsm.IncrementMsgCount();

		BsmConverter::ToBasicSafetyMessage(bsm, bsmJ2735);

		if (TransmitPacket(&asn_DEF_BasicSafetyMessage, &bsmJ2735, CHAN_BSM, PSID_BSM))
		{
			//cout << "BSM Transmitted." << endl;
			AddMessageCount("TxBsm");
		}

		ASN_STRUCT_FREE_CONTENTS_ONLY(asn_DEF_BasicSafetyMessage, &bsmJ2735);
	}
}

bool UperEncodeAndSendXml(const string &xml, DSRCmsgID2_t contentId,
		struct asn_TYPE_descriptor_s *type_descriptor, void **struct_ptr,
		int txChannel, uint32_t psid)
{
	// Decode the XML representation of the message to an ASN structure.

	asn_dec_rval_t rval;

	rval = xer_decode(NULL, type_descriptor, struct_ptr, xml.c_str(), xml.size());
	if (rval.code != RC_OK)
	{
		cout << "Unable to decode from XML: " << xml << endl;
		return false;
	}

	// UPER encode the ASN structure into a buffer of bytes.

	std::vector<uint8_t> buffer(4000);
	asn_enc_rval_t ueRet = uper_encode_to_buffer(type_descriptor, *struct_ptr, buffer.data(), buffer.max_size());
	if (ueRet.encoded <= 0)
	{
		cout << "Unable to encode UPER frame: " << xml << endl;
		return false;
	}

	// Resize the buffer to the actual number of bytes that were used.
	size_t encoded = (ueRet.encoded + 7) / 8;
	buffer.resize(encoded);

	// Create the UPER frame.  It must be static for it to work.
	static UPERframe frame;
	frame.msgID = (int)api::uperFrame_D;
	frame.contentID = contentId;
	frame.msgBlob.buf = buffer.data();
	frame.msgBlob.size = encoded;

	bool success = TransmitPacket(&asn_DEF_UPERframe, &frame, txChannel, psid);

	ASN_STRUCT_FREE_CONTENTS_ONLY(*type_descriptor, *struct_ptr);

	return success;
}

void SendPmm()
{
	// Extract XML from the _pmmDoc.
	// _pmmDoc properties are continuously updated with data from the mobile application elsewhere.
	string xml;

	{
		boost::lock_guard<mutex> lock(_mutexPmmDoc);

		xml = _pmmDoc.ToXml();

		//cout << "PMM XML Doc: " << xml << endl;
	}

	PersonalMobilityMessage_t *pmm = NULL;

	if (UperEncodeAndSendXml(xml, (int)api::personalMobilityMessage,
			&asn_DEF_PersonalMobilityMessage, (void **)&pmm, CHAN_PMM, PSID_PMM))
	{
		AddMessageCount("TxPmm");
	}
}

void SendPsm()
{
	static uint32_t tempId = GetTempId();

	// Extract XML from the _psmDoc.
	// _psmDoc properties are continuously updated with data from the mobile application elsewhere.
	string xml;

	{
		boost::lock_guard<mutex> lock(_mutexPsmDoc);

		if (system_clock::now() - _lastPsmDocUpdateTime > _psmDocStaleTimeout)
		{
			//cout << "PSM Doc is stale. " << endl;
			return;
		}

		_psmDoc.set_Id(tempId);

		xml = _psmDoc.ToXml();

		//cout << "PSM XML Doc: " << xml << endl;
	}

	PersonalSafetyMessage_t *psm = NULL;

	if (UperEncodeAndSendXml(xml, (int)api::personalSafetyMessage,
			&asn_DEF_PersonalSafetyMessage, (void **)&psm, CHAN_PSM, PSID_PSM))
	{
		AddMessageCount("TxPsm");
	}
}

void UpdateProviders()
{
	if (_flagTxBsm != _newFlagTxBsm)
	{
		_flagTxBsm = _newFlagTxBsm;

		// If receiving BSMs, then the provider entry is already added and is never removed.
		if (!_flagBsm)
		{
			if (_flagTxBsm)
				AddProviderEntry(CHAN_BSM, PSID_BSM);
			else
				RemoveProviderEntry(CHAN_BSM, PSID_BSM);
		}
	}

	if (_flagTxPmm != _newFlagTxPmm)
	{
		_flagTxPmm = _newFlagTxPmm;

		// If receiving PMMs, then the provider entry is already added and is never removed.
		if (!_flagPmm)
		{
			if (_flagTxPmm)
				AddProviderEntry(CHAN_PMM, PSID_PMM);
			else
				RemoveProviderEntry(CHAN_PMM, PSID_PMM);
		}
	}

	if (_flagTxPsm != _newFlagTxPsm)
	{
		_flagTxPsm = _newFlagTxPsm;

		// If receiving PSMs, then the provider entry is already added and is never removed.
		if (!_flagPsm)
		{
			if (_flagTxPsm)
				AddProviderEntry(CHAN_PSM, PSID_PSM);
			else
				RemoveProviderEntry(CHAN_PSM, PSID_PSM);
		}
	}
}

int main(int argc, char *argv[])
{
	cout << "AradaCvInspector v" << AradaCvInspector_VERSION << endl;

	_startTime = system_clock::now();

	WSMIndication rxpkt;

	int flagHelp = 0;
	int flagNoTxBsm = 0;
	int flagSpoof =0;
	std::string spoofFile;

	struct option long_options[] =
	{
		{"help", no_argument, &flagHelp, 1},
		{"notxbsm", no_argument, &flagNoTxBsm, 1},
		{"bsm", no_argument, &_flagBsm, 1},
		{"map", no_argument, &_flagMap, 1},
		{"spat", no_argument, &_flagSpat, 1},
		{"tim", no_argument, &_flagTim, 1},
		{"rsa", no_argument, &_flagRsa, 1},
		{"rtcm", no_argument, &_flagRtcm, 1},
		{"psm", no_argument, &_flagPsm, 1},
		{"pmm", no_argument, &_flagPmm, 1},
		{"spoof", required_argument, NULL, 'o'},
		{0, 0, 0, 0}
	};

	int c;
	int option_index = 0;
	while ((c = getopt_long (argc, argv, ":o:", long_options, &option_index)) !=-1)
	{
		switch(c)
		{
			case 'o':
				flagSpoof = 1;
				spoofFile = optarg;
			break;
			case 0:
				/* getopt_long() set the flag variable, keep going*/
			break;
		}
	}

	if (flagHelp)
	{
		printf("Usage: %s [--bsm] [--map] [--spat] [--tim] [--rtcm] [--psm] [--pmm] [--notxbsm] [--spoof]\n", argv[0]);
		printf("\tIf no parameters are specified, all messages are received.\n");
		printf("\tOtherwise only the specified messages are received.\n");
		printf("\tBSMs are transmitted unless notxbsm is specified or if settings changed via bluetooth.\n");
		exit(0);
	}

	if (flagNoTxBsm)
	{
		_flagTxBsm = 0;
		_newFlagTxBsm = 0;
	}

	// If none were specified, receive all of them.
	if (!(_flagBsm || _flagMap || _flagSpat || _flagTim || _flagRsa || _flagRtcm || _flagPsm || _flagPmm))
	{
		_flagBsm = 1;
		_flagMap = 1;
		_flagSpat = 1;
		_flagTim = 1;
		_flagRsa = 1;
		_flagRtcm = 1;
		_flagPsm = 1;
		_flagPmm = 1;

		printf("No command line options specified.  Receiving all messages.\n");
	}

	printf("Receive BSM: %s\n", _flagBsm ? "yes" : "no");
	printf("Receive MAP: %s\n", _flagMap ? "yes" : "no");
	printf("Receive SPAT: %s\n", _flagSpat ? "yes" : "no");
	printf("Receive TIM: %s\n", _flagTim ? "yes" : "no");
	printf("Receive RSA: %s\n", _flagRsa ? "yes" : "no");
	printf("Receive RTCM: %s\n", _flagRtcm ? "yes" : "no");
	printf("Receive PSM: %s\n", _flagPsm ? "yes" : "no");
	printf("Receive PMM: %s\n", _flagPmm ? "yes" : "no");
	printf("Transmit BSM: %s\n", _flagTxBsm ? "yes" : "no");
	printf("Transmit PMM: %s\n", _flagTxPmm ? "yes" : "no");
	printf("Transmit PSM: %s\n", _flagTxPsm ? "yes" : "no");
	printf("Spoof Location: %s\n", flagSpoof ? "yes" : "no");
	
	if(flagSpoof)
		std::cout<<"Spoof File: "<<spoofFile<<endl;

	_pid = getpid();

	oldsig_int = signal(SIGINT, sig);
	oldsig_kill = signal(SIGKILL, sig);
	oldsig_quit = signal(SIGQUIT, sig);
	oldsig_term = signal(SIGTERM, sig);
	oldsig_segv = signal(SIGSEGV, sig);

	registerWSMIndication(Receive_WSMIndication);

	if (invokeWAVEDevice(WAVEDEVICE_LOCAL, 0) < 0)
	{
		printf("Open Failed. Quitting\n");
		exit(-1);
	}

	registerWMENotifIndication(Receive_WMENotifIndication);
	registerWRSSIndication(Receive_WRSSIndication);
	registertsfIndication(Receive_sfIndication);

	if (_flagBsm || _flagTxBsm)
		AddProviderEntry(CHAN_BSM, PSID_BSM);
	if (_flagRsa || _flagTim)
		AddProviderEntry(CHAN_RSA_TIM, PSID_RSA_TIM);
	if (_flagSpat || _flagMap)
		AddProviderEntry(CHAN_MAP_SPAT, PSID_MAP_SPAT);
	if (_flagRtcm)
		AddProviderEntry(CHAN_RTCM, PSID_RTCM);
	if (_flagPmm)
		AddProviderEntry(CHAN_PMM, PSID_PMM);
	if (_flagPsm)
		AddProviderEntry(CHAN_PSM, PSID_PSM);

	// The J2735 library can convert a J2735 structure to XML using a method (xer_fprint)
	// that takes a file descriptor as a parameter.
	// The following code creates a pipe, then starts a thread so that the
	// writer can call xer_fprint to send XML to the pipe.  The reader then takes the XML
	// and loads it into a ptree, manipulates it, then sends JSON to all clients over bluetooth.

	int pipefd[2];

	if (pipe(pipefd) < 0)
	{
		perror("ERROR: Pipe creation failed");
		exit(EXIT_FAILURE);
	}

	// Start the bluetooth thread.
	_btThread = new boost::thread(&BluetoothThread, pipefd[0]);

	if(flagSpoof)
		gps_enableSpoofDevice((char*)spoofFile.c_str());

	GpsDevice *gps = gps_getDefaultDevice();
	if (!gps)
		printf("Application: Unable to get GPS Device.\n");

	// Wait for a few so the bluetooth thread is up and ready.
	usleep(5000);

	// Get a file pointer that writes to the pipe.
	_pipeInput = fdopen(pipefd[1], "w");

	system_clock::time_point lastPrintTime = system_clock::now() - hours(1);
	system_clock::time_point lastCleanupTime = system_clock::now() - hours(1);

	while (true)
	{
		int ret = rxWSMPacket(_pid, &rxpkt);

		bool wasPacketReceived = (ret > 0);

		if (wasPacketReceived)
		{
			//printf("Received packet with Length: %d\n",rxpkt.data.length);
			Receive_WSMIndication(&rxpkt);

			DecodePacketAndSendToPipe(_pipeInput, rxpkt);
			//printf("DecodedPacketAndSentToPipe\n");
		}

		system_clock::time_point now = system_clock::now();

		UpdateProviders();

		// The location of this radio is sent to the CV Inspector device.
		if (_myLocationFrequencyThrottle.Monitor(1))
		{
			SendMyLocationMessage(_pipeInput);
		}

		// Send a BSM for this device out the radio.
		if (_flagTxBsm && _sendBsmFrequencyThrottle.Monitor(1))
		{
			SendBsm();
		}

		// Send a PMM out the radio for the mobile device.
		if (_flagTxPmm && _sendPmmFrequencyThrottle.Monitor(1))
		{
			SendPmm();
		}

		// Send a PSM out the radio for the mobile device.
		if (_flagTxPsm && _sendPsmFrequencyThrottle.Monitor(1))
		{
			SendPsm();
		}

		// Cleanup stale data periodically.
		if (now - lastCleanupTime > seconds(1))
		{
			// Remove stale keys.
			// Note that if the ID used by the frequency throttle never changes then cleanup is
			// not needed (e.g. myLocaiton and sendBsm throttles).
			_bsmFrequencyThrottle.RemoveStaleKeys();
			_mapFrequencyThrottle.RemoveStaleKeys();
			_spatFrequencyThrottle.RemoveStaleKeys();
			_timFrequencyThrottle.RemoveStaleKeys();
			_psmFrequencyThrottle.RemoveStaleKeys();
			lastCleanupTime = now;
		}

		// Print message counts every 5 seconds.
		if (now - lastPrintTime > seconds(5))
		{
			PrintMessageCounts();
			lastPrintTime = now;
		}

		if (wasPacketReceived)
			sched_yield();
		else
			usleep(1000);
	}

	return EXIT_SUCCESS;
}
