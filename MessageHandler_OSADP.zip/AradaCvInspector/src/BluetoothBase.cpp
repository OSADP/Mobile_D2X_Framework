/*
 * BluetoothClient.cpp
 *
 *  Created on: Jan 8, 2016
 *      Author: baumgardner@battelle.org
 */

#include "Bluetooth.h"

using namespace std;
using namespace DsrcMobileArada;

int str2uuid(const char *uuid_str, uuid_t *uuid) {
	uint32_t uuid_int[4];
	char *endptr;

	if (strlen(uuid_str) == 36) {
		// Parse uuid128 standard format: 12345678-9012-3456-7890-123456789012
		char buf[9] = { 0 };

		if (uuid_str[8] != '-' && uuid_str[13] != '-' && uuid_str[18] != '-'
				&& uuid_str[23] != '-') {
			return 0;
		}
		// first 8-bytes
		strncpy(buf, uuid_str, 8);
		uuid_int[0] = htonl(strtoul(buf, &endptr, 16));
		if (endptr != buf + 8)
			return 0;

		// second 8-bytes
		strncpy(buf, uuid_str + 9, 4);
		strncpy(buf + 4, uuid_str + 14, 4);
		uuid_int[1] = htonl(strtoul(buf, &endptr, 16));
		if (endptr != buf + 8)
			return 0;

		// third 8-bytes
		strncpy(buf, uuid_str + 19, 4);
		strncpy(buf + 4, uuid_str + 24, 4);
		uuid_int[2] = htonl(strtoul(buf, &endptr, 16));
		if (endptr != buf + 8)
			return 0;

		// fourth 8-bytes
		strncpy(buf, uuid_str + 28, 8);
		uuid_int[3] = htonl(strtoul(buf, &endptr, 16));
		if (endptr != buf + 8)
			return 0;

		if (uuid != NULL)
			sdp_uuid128_create(uuid, uuid_int);
	} else if (strlen(uuid_str) == 8) {
		// 32-bit reserved UUID
		uint32_t i = strtoul(uuid_str, &endptr, 16);
		if (endptr != uuid_str + 8)
			return 0;
		if (uuid != NULL)
			sdp_uuid32_create(uuid, i);
	} else if (strlen(uuid_str) == 4) {
		// 16-bit reserved UUID
		int i = strtol(uuid_str, &endptr, 16);
		if (endptr != uuid_str + 4)
			return 0;
		if (uuid != NULL)
			sdp_uuid16_create(uuid, i);
	} else {
		return 0;
	}

	return 1;
}

int BluetoothBase::getHCIDeviceId() {
	if (this->dev < 0)
		this->dev = hci_get_route(NULL);

	return this->dev;
}

int BluetoothBase::openHCIDevice() {
	if (this->devSock < 0)
		this->devSock = hci_open_dev(getHCIDeviceId());

	return devSock;
}

int BluetoothBase::closeHCIDevice() {
	if (this->devSock < 0)
		return hci_close_dev(this->devSock);

	return -1;
}

int BluetoothBase::connect(const char* bdAddress, int channel) {
	struct sockaddr_rc remoteAddr;
	remoteAddr.rc_family = AF_BLUETOOTH;
	remoteAddr.rc_channel = channel;
	if (str2ba(bdAddress, &remoteAddr.rc_bdaddr) < 0) {
		cerr << "ERROR: Unknown Bluetooth address " << bdAddress << ": " << strerror(errno) << endl;
		return -1;
	}

	this->btoothChannel = channel;
	this->btoothSocket = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
	if (this->btoothSocket < 0) {
		cerr << "ERROR: Could not open Bluetooth socket: " << strerror(errno) << endl;
		return this->btoothSocket;
	}

	int status = ::connect(this->btoothSocket, (const sockaddr *)&remoteAddr, sizeof(remoteAddr));
	if (status < 0) {
		cerr << "ERRROR: Could not connect to Bluetooth socket on address " << bdAddress
			 << " on channel " << channel << ": " << strerror(errno) << endl;
		this->disconnect();
	}

	return status;
}

int BluetoothBase::disconnect() {
	if (this->btoothSocket >= 0)
		::close(this->btoothSocket);

	this->closeHCIDevice();

	this->btoothChannel = -1;
	this->btoothSocket = -1;
	this->devSock = -1;

	return (1);
}

/*
map<string, string> getRemoteDevices() {

	cout << "Getting remote devices." << endl;

	int devSock = openHCIDevice();

	map<string, string> devices;

	inquiry_info* info = new inquiry_info[MAX_DEVICES];
	char buffer[1024];
	memset(buffer, 0, sizeof(buffer));

	int num = hci_inquiry(0, 4, //(int)round(1.0 * MAX_QUERY_DELAY_SEC / DELAY_LENGTH_SEC),
			MAX_DEVICES, NULL, &info, 0);

	cout << "Found " << num << " devices." << endl;

	for (int i = 0; i < num; i++) {
		// Get the name of the device from its address
		string name = "Unknown";
		if (hci_read_remote_name(devSock, &(info[i].bdaddr), sizeof(buffer), buffer, MAX_TIMEOUT) >= 0)
			name = buffer;

		if (ba2str(&(info[i].bdaddr), buffer) > 0)
			devices[string(buffer)] = name;
	}

	delete[] info;

	closeHCIDevice(devSock);
	return devices;
}

int getCommChannel(const char* bdAddr, const char* uuid) {
	if (!bdAddr)
		return (-1);

	int devSock = openHCIDevice();

	bdaddr_t addr;
	str2ba(bdAddr, &addr);
	sdp_session_t* session = NULL;
	session = sdp_connect(BDADDR_ANY, &addr, 0);
	if (!session) {
		closeHCIDevice(devSock);
		return (-1);
	}

	uint32_t range = 0x0000ffff;
	uuid_t uuidNum = { 0 };
	str2uuid(uuid, &uuidNum);

	sdp_list_t* search_list = sdp_list_append(NULL, &uuidNum);
	sdp_list_t* attrid_list = sdp_list_append(NULL, &range);
	sdp_list_t* response_list = NULL;

	sdp_service_search_attr_req(session, search_list, SDP_ATTR_REQ_RANGE,
			attrid_list, &response_list); //search for attributes from list
	sdp_list_t *r = response_list;
	int responses = 0;

	// go through each of the service records
	int loco_channel = 0;
	for (; r; r = r->next) {
		responses++;
		sdp_record_t *rec = (sdp_record_t*) r->data;
		sdp_list_t *proto_list;

		// get a list of the protocol sequences
		if (sdp_get_access_protos(rec, &proto_list) == 0) {
			sdp_list_t *p = proto_list;

			// go through each protocol sequence
			for (; p; p = p->next) {
				sdp_list_t *pds = (sdp_list_t*) p->data;

				// go through each protocol list of the protocol sequence
				for (; pds; pds = pds->next) {

					// check the protocol attributes
					sdp_data_t *d = (sdp_data_t*) pds->data;
					int proto = 0;
					for (; d; d = d->next) {
						switch (d->dtd) {
						case SDP_UUID16:
						case SDP_UUID32:
						case SDP_UUID128:
							proto = sdp_uuid_to_proto(&d->val.uuid);
							break;
						case SDP_UINT8:
							if (proto == RFCOMM_UUID) {
								printf("rfcomm channel: %d\n", d->val.int8);
								loco_channel = d->val.int8;
							}
							break;
						} // switch(t->dtd)
					} // for( ; d; d = d->next)
				} // for( ; pds ; pds = pds->next)
				sdp_list_free((sdp_list_t*) p->data, 0);
			} // for( ; p; p = p->next)
			sdp_list_free(proto_list, 0);
		} // if(sdp_get_access_protos(rec, &proto_list))
		sdp_record_free(rec);
		if (loco_channel > 0) {
			break;
		}
	} // for (; r; r = r->next)

	sdp_list_free(response_list, 0);
	sdp_list_free(search_list, 0);
	sdp_list_free(attrid_list, 0);

	closeHCIDevice(devSock);
	return loco_channel;
}

int btWrite(const char* bdAddr, int channel, string data) {
	if (!bdAddr) return (-1);


	struct sockaddr_rc remoteAddr;
	remoteAddr.rc_family = AF_BLUETOOTH;
	remoteAddr.rc_channel = channel;
	if (str2ba(bdAddr, &remoteAddr.rc_bdaddr) < 0) {
		cerr << "ERROR: Unknown Bluetooth address " << bdAddr << ": " << strerror(errno) << endl;
		return (-1);
	}

	int btoothSock = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
	if (btoothSock < 0) {
		cerr << "ERROR: Could not open Bluetooth socket: " << strerror(errno) << endl;
		return btoothSock;
	}

	int status = connect(btoothSock, (const sockaddr *)&remoteAddr, sizeof(remoteAddr));
	if (status < 0) {
		cerr << "ERRROR: Could not connect to Bluetooth socket on address " << bdAddr
			 << " on channel " << channel << ": " << strerror(errno) << endl;
		close(btoothSock);
		return status;
	}

	// TODO: Use Boost library to compress stream and count bytes
	socketstream out(btoothSock);
	out << data.c_str() << flush;
	return data.length();
}

int btWrite(const char* uuid, string data) {
	// Discover the correct ID from the available devices and then write the data
	map<string, string> devices = getRemoteDevices();

	for (map<string, string>::iterator i = devices.begin(); i != devices.end(); i++) {
		// See if the uuid exists on this address
		cout << "Searching " << i->second << " (" << i->first << ") for " << uuid << endl;
		int channel = getCommChannel(i->first.c_str(), uuid);
		if (channel > 0) {
			cout << "Writing " << data.size() << " bytes to channel " << channel << endl;
			return btWrite(i->first.c_str(), channel, data);
		}
	}

	return (-1);
}

*/
