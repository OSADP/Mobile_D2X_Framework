//============================================================================
// Name        : VeaRideRequestPlugin.cpp
// Author      : Battelle Memorial Institute - Ben Paselsky (paselsky@battelle.org)
// Version     :
// Copyright   : Copyright (c) 2014 Battelle Memorial Institute. All rights reserved.
// Description : Plugin that monitors DSRC traffic and the Azure database to see
//               if new rides have been requested and responds to requests
//============================================================================

#include <atomic>
#include <thread>
#include <queue>
#include <curl/curl.h>
#include <boost/regex.hpp>

#include "PluginClient.h"
#include <LocationMessage.h>
#include <PmmRequestMessage.h>
#include <cpprest/http_client.h>
#include <tmx/j2735_messages/PersonalMobilityMessage.hpp>
#include <tmx/messages/message_document.hpp>
#include <asn_j2735_r41/DFullTime.h>
#include <asn_j2735_r41/DestinationType.h>
#include <asn_j2735_r41/MobilityNeedsList.h>
#include <asn_j2735_r41/MobilityNeeds.h>
#include <GeoVector.h>

using namespace std;
using namespace tmx;
using namespace tmx::utils;
using namespace tmx::messages;
using namespace tmx::messages::pmmrequestmessage;
using namespace std;
using namespace web;
using namespace utility;
using namespace http;
using namespace http::client;

namespace VeaRideRequestPlugin
{

#define THREADSLEEPTIMEMS 100

/*
 * Struct for holding PSM messages and the time they were received, used for FIFO queue
 */
struct PmmMsgQueueStruct
{
	uint64_t pmmMsgTime;
	PmmMessage pmmMsg;
};

/*
 * Struct for holding accepted pickups
 * Check pmmMsgCloud to determine if we saved DSRC or Cloud PMM
 * If pmmMsgCloud is empty string then pmmMsgDSRC is valid otherwise pmmMsgCloud contains json from web request
 */
struct AcceptedPickupsStruct
{
	string groupId;
	RequestID_t requestId;
	PersonalMobilityMessageStatusType_t status;
	PmmMessage pmmMsgDSRC;
	string pmmMsgCloud;
};


/**
 * This plugin monitors DSRC traffic and the Azure database to see
 * if new rides have been requested and responds to requests
 */
class VeaRideRequestPlugin: public PluginClient
{
public:
	VeaRideRequestPlugin(std::string);
	virtual ~VeaRideRequestPlugin();
	int Main();
protected:
	void UpdateConfigSettings();
	// Virtual method overrides.
	void OnConfigChanged(const char *key, const char *value);
	void OnStateChange(IvpPluginState state);
	uint64_t GetMsTimeSinceEpoch();
	void HandlePmmMessage(PmmMessage &msg, routeable_message &routeableMsg);
	void HandleLocationMessage(LocationMessage &msg, routeable_message &routeableMsg);
	void SendPmmMessage(string &groupId, RequestID_t requestId,
			PersonalMobilityMessageStatusType_t status, string vehicleDescription, PmmMessage requestMessage);
	void SendPmmMessage(string &groupId, RequestID_t requestId,
			PersonalMobilityMessageStatusType_t status, string vehicleDescription, string requestMessageCloud);
	SeatCount_t GetTotalSeatCount(PmmMessage &msg);
	SeatCount_t GetRegularSeatCount(PmmMessage &msg);
	SeatCount_t GetHandicappedSeatCount(PmmMessage &msg);

	void CloudThread();
	void NextDestinationThread();
	void ArrivedThread();

	static size_t HandleResponseOutput(void *buffer, size_t size, size_t nmemb, void *userp);

private:
	// locks
	mutex _pmmLock;
	mutex _locationLock;
	mutex _apiUrlLock;
	mutex _vehicleDescriptionLock;
	mutex _acceptedPickupsLock;
	mutex _setContentsLock;

	atomic<bool> _newConfigValues{false};
	atomic<uint64_t> _cloudFrequency{3000};
	atomic<uint64_t> _nextDestinationFrequency{3000};
	atomic<uint64_t> _arrivedFrequency{3000};
	atomic<uint64_t> _arrivedRadius{5};
	atomic<uint64_t> _locationMsgExpireMs{5000};
	string _mobileDevicesApiUrl = "http://mobiledeviceswebapidev.azurewebsites.net";
	string _vehicleDescription = "Vehicle";
	atomic<bool> _cancelAllRequests{false};

	LocationMessage _locationMsg;
	uint64_t _locationMsgTime{0};
	std::queue<PmmMsgQueueStruct> _pmmMsgQueue;
	std::map<string, AcceptedPickupsStruct> _acceptedPickups;
	std::vector<string> _acceptedPickupsOrder;

	thread _cloudThread;
	thread _nextDestinationThread;
	thread _arrivedThread;
	atomic<bool> _stopThreads{false};

};

/**
 * Construct a new VeaRideRequestPlugin with the given name.
 *
 * @param name The name to give the plugin for identification purposes
 */
VeaRideRequestPlugin::VeaRideRequestPlugin(string name) : PluginClient(name)
{

	// Add a message filter and handler for each message this plugin wants to receive.
	AddMessageFilter<PmmMessage>(this, &VeaRideRequestPlugin::HandlePmmMessage);
	AddMessageFilter<LocationMessage>(this, &VeaRideRequestPlugin::HandleLocationMessage);

	// Subscribe to all messages specified by the filters above.
	SubscribeToMessages();

	// Start threads thread
	_cloudThread = thread(&VeaRideRequestPlugin::CloudThread, this);
	_nextDestinationThread = thread(&VeaRideRequestPlugin::NextDestinationThread, this);
	_arrivedThread = thread(&VeaRideRequestPlugin::ArrivedThread, this);
}

VeaRideRequestPlugin::~VeaRideRequestPlugin()
{
	//stop threads cleanly and wait for them to die
	_stopThreads = true;
	_cloudThread.join();
	_nextDestinationThread.join();
	_arrivedThread.join();
}

void VeaRideRequestPlugin::UpdateConfigSettings()
{
	string mobileDevicesApiUrl;
	string vehicleDescription;
	GetConfigValue("CloudFrequency", _cloudFrequency);
	GetConfigValue("NextDestinationFrequency", _nextDestinationFrequency);
	GetConfigValue("ArrivedFrequency", _arrivedFrequency);
	GetConfigValue("ArrivedRadius", _arrivedRadius);
	GetConfigValue("LocationMsgExpiration", _locationMsgExpireMs);
	{
		lock_guard<mutex> lock(_apiUrlLock);
		GetConfigValue("MobileDevicesApiUrl", _mobileDevicesApiUrl);
		mobileDevicesApiUrl = _mobileDevicesApiUrl;
	}
	{
		lock_guard<mutex> lock(_vehicleDescriptionLock);
		GetConfigValue("VehicleDescription", _vehicleDescription);
		vehicleDescription = _vehicleDescription;
	}
	GetConfigValue("CancelAllRequests",_cancelAllRequests);

	PLOG(logDEBUG) << "    Config data - CloudFrequency: " << _cloudFrequency <<
			", NextDestinationFrequency: " << _nextDestinationFrequency << ", ArrivedFrequency: " <<
			_arrivedFrequency << ", ArrivedRadius: " << _arrivedRadius << ", LocationMsgExpiration: " << _locationMsgExpireMs <<
			", URL: " << mobileDevicesApiUrl << ", VehicleDescription: " << vehicleDescription << ", CancelAllRequests: " << _cancelAllRequests;

	_newConfigValues = true;
}

void VeaRideRequestPlugin::OnConfigChanged(const char *key, const char *value)
{
	PluginClient::OnConfigChanged(key, value);
	UpdateConfigSettings();
}


void VeaRideRequestPlugin::OnStateChange(IvpPluginState state)
{
	PluginClient::OnStateChange(state);

	if (state == IvpPluginState_registered)
	{
		UpdateConfigSettings();
	}
}

uint64_t VeaRideRequestPlugin::GetMsTimeSinceEpoch()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return (uint64_t) ((double) (tv.tv_sec) * 1000
			+ (double) (tv.tv_usec) / 1000);
}

int VeaRideRequestPlugin::Main()
{
	PLOG(logINFO) << "Starting plugin.";
	bool havePmmData;
	PmmMessage pmmCopy;
	//uint64_t currentPmmMessageTime;
	string groupId;
	RequestID_t requestId;
	PersonalMobilityMessageStatusType_t pmmStatus;
	bool processPMMRequest;
	bool sendResponse;
	SeatCount_t seatCount;
	bool pickupFound;

	while (_plugin->state != IvpPluginState_error)
	{
		if (_newConfigValues)
		{
			{
				//check PMM queue
				lock_guard<mutex> lock(_pmmLock);
				havePmmData = !_pmmMsgQueue.empty();
			}
			//loop through all messages in queue
			while (havePmmData)
			{
				//get PMM message off queue
				{
					lock_guard<mutex> lock(_pmmLock);
					//PLOG(logDEBUG) << "Have PMM data, queue length: " << _pmmMsgQueue.size();
					//currentPmmMessageTime = _pmmMsgQueue.front().pmmMsgTime;
					pmmCopy = _pmmMsgQueue.front().pmmMsg;
					_pmmMsgQueue.pop();
				}

				//get PMM fields
				PersonalMobilityMessage *pmmData = pmmCopy.get_j2735_data();
				groupId = string((const char*)pmmData->groupId.buf, pmmData->groupId.size);
				requestId = pmmData->requestId;
				pmmStatus = pmmData->status;
				seatCount = GetTotalSeatCount(pmmCopy);

				PLOG(logDEBUG1) << "PMM data: groupId: " << groupId << ", requestId: " << requestId << ", pmmStatus: " << pmmStatus;

				processPMMRequest = true;
				sendResponse = false;

				{  // lock accepted pickups map in this block
					lock_guard<mutex> lock(_acceptedPickupsLock);

					//check is we have a saved request
					//if we do then process new request only if requestId > saved requestId
					pickupFound = false;
					if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
					{
						pickupFound = true;
						if (_acceptedPickups[groupId].requestId >= requestId)
						{
							//process request if new request id
							processPMMRequest = false;
						}
						if (_acceptedPickups[groupId].requestId == requestId)
						{
							//just send response if this request id already processed
							sendResponse = true;
						}
					}

					//process request into accepted pickups map, dont send response just yet
					if (processPMMRequest)
					{
						//process pmm
						if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_new)
						{
							sendResponse = true;
							if (seatCount > 0)
							{
								PLOG(logDEBUG) << "Add (DSRC), groupId: " << groupId << "  requestId: " << requestId;
								//new
								AcceptedPickupsStruct acceptedPickup;
								acceptedPickup.groupId = groupId;
								acceptedPickup.requestId = requestId;
								acceptedPickup.status = pmmStatus;
								acceptedPickup.pmmMsgDSRC = pmmCopy;
								acceptedPickup.pmmMsgCloud = "";
								_acceptedPickups[groupId] = acceptedPickup;
								if (!pickupFound)
								{
									//add groupId to end of order vector
									_acceptedPickupsOrder.push_back(groupId);
								}
							}
							else
							{
								//cancel because requested seat count = 0
								if (pickupFound)
								{
									PLOG(logDEBUG) << "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request cancelled";
									_acceptedPickups.erase(groupId);
								}
								else
								{
									PLOG(logDEBUG)<< "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request not found!";
								}
							}
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
						{
							sendResponse = true;
							if (seatCount > 0)
							{
								PLOG(logDEBUG) << "Update (DSRC), groupId: " << groupId << "  requestId: " << requestId;
								//update
								AcceptedPickupsStruct acceptedPickup;
								acceptedPickup.groupId = groupId;
								acceptedPickup.requestId = requestId;
								acceptedPickup.status = pmmStatus;
								acceptedPickup.pmmMsgDSRC = pmmCopy;
								acceptedPickup.pmmMsgCloud = "";
								_acceptedPickups[groupId] = acceptedPickup;
								if (!pickupFound)
								{
									//add groupId to end of order vector
									_acceptedPickupsOrder.push_back(groupId);
								}
							}
							else
							{
								//cancel because requested seat count = 0
								if (pickupFound)
								{
									PLOG(logDEBUG) << "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request cancelled";
									_acceptedPickups.erase(groupId);
								}
								else
								{
									PLOG(logDEBUG)<< "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request not found!";
								}
							}
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_cancel)
						{
							sendResponse = true;
							//cancel
							if (pickupFound)
							{
								PLOG(logDEBUG) << "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request cancelled";
								_acceptedPickups.erase(groupId);
							}
							else
							{
								PLOG(logDEBUG) << "Cancel (DSRC), groupId: " << groupId << "  requestId: " << requestId << " *** Request not found!";
							}
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_completed)
						{
							//completed
							//PLOG(logDEBUG) << "Ignore (DSRC) 'Completed' message, groupId: " << groupId << "  requestId: " << requestId;
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
						{
							//arrival
							//PLOG(logDEBUG) << "Ignore (DSRC) 'Arrival' message, groupId: " << groupId << "  requestId: " << requestId;
						}
						else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_response)
						{
							//response
							//PLOG(logDEBUG) << "Ignore (DSRC) 'Response' message, groupId: " << groupId << "  requestId: " << requestId;
						}
						else
						{
							//PLOG(logDEBUG) << "Ignore (DSRC) unknown status message, groupId: " << groupId << "  requestId: " << requestId << "  status: " << pmmStatus;
						}
					}
				}

				if (sendResponse)
				{
					//send response
					if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_new)
					{
						//new
						SendPmmMessage(groupId, requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_response,
								_vehicleDescription, pmmCopy);
						PLOG(logDEBUG) << "Send PMM (DSRC) response";
					}
					else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
					{
						//update
						SendPmmMessage(groupId, requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_response,
								_vehicleDescription, pmmCopy);
						PLOG(logDEBUG) << "Send PMM (DSRC) response";
					}
					else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_cancel)
					{
						//cancel
					}
					else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_completed)
					{
						//completed
					}
					else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
					{
						//arrival
					}
					else if (pmmStatus == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_response)
					{
						//response
					}
					else
					{
						//unknown status
					}
				}

				{
					//check PMM queue
					lock_guard<mutex> lock(_pmmLock);
					havePmmData = !_pmmMsgQueue.empty();
				}
			}
		}

		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}

	return (EXIT_SUCCESS);
}

SeatCount_t VeaRideRequestPlugin::GetTotalSeatCount(PmmMessage &msg)
{
	SeatCount_t count = 0;
	PersonalMobilityMessage *pmm;
	//count total number of seats
	pmm = msg.get_j2735_data();
	if (pmm != NULL)
	{
		if (pmm->mobilityNeeds != NULL)
		{
			if (pmm->mobilityNeeds->list.count > 0)
			{
				for (int i = 0;i < pmm->mobilityNeeds->list.count;i++)
				{
					count += pmm->mobilityNeeds->list.array[i]->count;
				}
			}
		}

	}
	return count;
}

SeatCount_t VeaRideRequestPlugin::GetRegularSeatCount(PmmMessage &msg)
{
	SeatCount_t count = 0;
	PersonalMobilityMessage *pmm;
	pmm = msg.get_j2735_data();
	if (pmm != NULL)
	{
		if (pmm->mobilityNeeds != NULL)
		{
			if (pmm->mobilityNeeds->list.count > 0)
			{
				for (int i = 0;i < pmm->mobilityNeeds->list.count;i++)
				{
					if (pmm->mobilityNeeds->list.array[i]->type == MobilityNeedsType_noSpecialNeeds)
					{
						return pmm->mobilityNeeds->list.array[i]->count;
					}
				}
			}
		}
	}
	return count;
}

SeatCount_t VeaRideRequestPlugin::GetHandicappedSeatCount(PmmMessage &msg)
{
	SeatCount_t count = 0;
	PersonalMobilityMessage *pmm;
	pmm = msg.get_j2735_data();
	if (pmm != NULL)
	{
		if (pmm->mobilityNeeds != NULL)
		{
			if (pmm->mobilityNeeds->list.count > 0)
			{
				for (int i = 0;i < pmm->mobilityNeeds->list.count;i++)
				{
					if (pmm->mobilityNeeds->list.array[i]->type == MobilityNeedsType_wheelchair)
					{
						return pmm->mobilityNeeds->list.array[i]->count;
					}
				}
			}
		}
	}
	return count;
}

void VeaRideRequestPlugin::HandlePmmMessage(PmmMessage &msg, routeable_message &routeableMsg)
{
	PmmMsgQueueStruct pmmQeueItem;
	PersonalMobilityMessage *pmm;

	// Must be in the registered state in order to know the parameter values
	if (_plugin->state != IvpPluginState_registered)
		return;

	pmm = msg.get_j2735_data();

	if (pmm->position.lat == 0 && pmm->position.Long == 0)
		return;

	{
		lock_guard<mutex> lock(_pmmLock);
		//Save the timestamp of this message.
		pmmQeueItem.pmmMsgTime = routeableMsg.get_timestamp();
		pmmQeueItem.pmmMsg = msg;
		_pmmMsgQueue.push(pmmQeueItem);
	}

	PLOG(logDEBUG) << "HandlePmmMessage receiving DSRC PmmMessage from TMX Core, received on: " << GetMsTimeSinceEpoch();
	//PLOG(logDEBUG) << "Got PMM";
}

void VeaRideRequestPlugin::HandleLocationMessage(LocationMessage &msg, routeable_message &routeableMsg)
{
	// Must be in the registered state in order to know the parameter values
	if (_plugin->state != IvpPluginState_registered)
		return;

	if (msg.get_Latitude() == 0 && msg.get_Longitude() == 0)
		return;

	//Save to member variable for later use.
	{
		lock_guard<mutex> lock(_locationLock);
		_locationMsgTime = routeableMsg.get_timestamp();
		_locationMsg = msg;
	}
}

/*
 * This method is used to send the PMM response to the passed in request. The response
 * body is filled in with information from the DSRC request (most of which is not needed) which
 * insures that the message successfully builds from the XML.
 */
void VeaRideRequestPlugin::SendPmmMessage(string &groupId, RequestID_t requestId,
		PersonalMobilityMessageStatusType_t status, string vehicleDescription, PmmMessage requestMessage)
{
	stringstream ss;
	string currentWeather;
	PmmMessage pmmMsg;
	message_container_type xmlDoc;
	PmmEncodedMessage encMsg;
	string accuracy;
	string vehicleDesc;
	PersonalMobilityMessage *pmm;

	PLOG(logDEBUG) << "Send PMM (for DSRC request), Status: " << status;

	pmm = requestMessage.get_j2735_data();

	ss.clear();
	ss.str(string());
	ss << "<PersonalMobilityMessage>";
	ss << "<groupId>" << groupId << "</groupId>";
	ss << "<requestId>" << requestId << "</requestId>";
	ss << "<status>" << status << "</status>";
	ss << "<position>" <<
			"<lat>" << pmm->position.lat << "</lat>" <<
			"<long>" << pmm->position.Long << "</long>" <<
			"</position>";

/*  adding accuracy throws an exception

	if (requestMessage.get_j2735_data()->accuracy != NULL)
	{
		accuracy = string((const char*)requestMessage.get_j2735_data()->accuracy->buf,
				requestMessage.get_j2735_data()->accuracy->size);
		ss << "<accuracy>" << accuracy << "</accuracy>";
	}
	else
	{
		ss << "<accuracy></accuracy>";
	}
*/

	if (pmm->requestDate != NULL)
	{
		ss << "<requestDate>" <<
				"<year>" << pmm->requestDate->year << "</year>" <<
				"<month>" << pmm->requestDate->month << "</month>" <<
				"<day>" << pmm->requestDate->day << "</day>" <<
				"<hour>" << pmm->requestDate->hour << "</hour>" <<
				"<minute>" << pmm->requestDate->minute << "</minute>" <<
				"</requestDate>";
	}
	else
	{
		ss << "<requestDate></requestDate>";
	}

	if (pmm->pickupDate != NULL)
	{
		ss << "<pickupDate>" <<
				"<year>" << pmm->pickupDate->year << "</year>" <<
				"<month>" << pmm->pickupDate->month << "</month>" <<
				"<day>" << pmm->pickupDate->day << "</day>" <<
				"<hour>" << pmm->pickupDate->hour << "</hour>" <<
				"<minute>" << pmm->pickupDate->minute << "</minute>" <<
				"</pickupDate>";
	}
	else
	{
		ss << "<pickupDate></pickupDate>";
	}

	if (pmm->destination != NULL)
	{
		ss << "<destination>" <<
				"<lon>" << pmm->destination->lon << "</lon>" <<
				"<lat>" << pmm->destination->lat << "</lat>" <<
				"</destination>";
	}
	else
	{
		ss << "<destination></destination>";
	}

	ss << "<mobilityNeeds>";
	if (pmm->mobilityNeeds != NULL)
	{
		if (pmm->mobilityNeeds->list.count > 0)
		{
			for (int i = 0;i < pmm->mobilityNeeds->list.count;i++)
			{
				ss << "<MobilityNeeds>" <<
						"<type>" << pmm->mobilityNeeds->list.array[i]->type << "</type>" <<
						"<count>" << pmm->mobilityNeeds->list.array[i]->count << "</count>" <<
						"</MobilityNeeds>";
			}
		}
	}
	ss << "</mobilityNeeds>";

	if (pmm->modeOfTransport != NULL)
	{
		ss << "<modeOfTransport>" << *(pmm->modeOfTransport) << "</modeOfTransport>";
	}
	else
	{
		ss << "<modeOfTransport></modeOfTransport>";
	}

	if (pmm->eta != NULL)
	{
		ss << "<eta>" << *(pmm->eta) << "</eta>";
	}
	else
	{
		//default to 0
		ss << "<eta>0</eta>";
	}

	if (pmm->isDSRCEquipped != NULL)
	{
		if (*(pmm->isDSRCEquipped) == 0)
		{
			ss << "<isDSRCEquipped><false/></isDSRCEquipped>";
		}
		else
		{
			ss << "<isDSRCEquipped><true/></isDSRCEquipped>";
		}
	}
	else
	{
		//default to false
		ss << "<isDSRCEquipped><false/></isDSRCEquipped>";
	}

/*
 	if (requestMessage.get_j2735_data()->vehicleDesc != NULL)
	{
		vehicleDesc = string((const char*)requestMessage.get_j2735_data()->vehicleDesc->buf,
				requestMessage.get_j2735_data()->vehicleDesc->size);
		ss << "<vehicleDesc>" << vehicleDesc << "</vehicleDesc>";
	}
	else
	{
		ss << "<vehicleDesc></vehicleDesc>";
	}
*/

	//use this vehicles description
	//dont allow empty string (causes exception)
	if (vehicleDescription.length() == 0)
	{
		ss << "<vehicleDesc>Vehicle</vehicleDesc>";
	}
	else
	{
		ss << "<vehicleDesc>" << vehicleDescription << "</vehicleDesc>";
	}

	ss << "<regional></regional>";

	ss << "</PersonalMobilityMessage>";

	PLOG(logDEBUG) << "PMM XML: " << ss.str();

	try
	{
		xmlDoc.load<XML>(ss);
		{
			lock_guard<mutex> lock(_setContentsLock);
			pmmMsg.set_contents(xmlDoc);
			encMsg.initialize(pmmMsg);
		}
		encMsg.set_flags(IvpMsgFlags_RouteDSRC);
		encMsg.addDsrcMetadata(172, 0x8031);
		BroadcastMessage(static_cast<routeable_message &>(encMsg));
		PLOG(logDEBUG) << "SendPmmMessage sending DSRC Pmm Message to TMX Core (for DSRC request), sent on: " << GetMsTimeSinceEpoch() << " - PMM fields: " << pmmMsg.to_string();
	}
	catch (exception &ex)
	{
		PLOG(logERROR) << "Exception thrown in VeaRideRequestPlugin::SendPmmMessage: " << ex.what();
	}
}

/*
 * This method is used to send the PMM response to the passed in request. The response
 * body is filled in with information from the Cloud request (most of which is not needed) which
 * insures that the message successfully builds from the XML.
 */
void VeaRideRequestPlugin::SendPmmMessage(string &groupId, RequestID_t requestId,
		PersonalMobilityMessageStatusType_t status, string vehicleDescription, string requestMessage)
{
	stringstream ss;
	string currentWeather;
	PmmMessage pmmMsg;
	message_container_type xmlDoc;
	PmmEncodedMessage encMsg;
	string accuracy;
	string vehicleDesc;
	tmx::message bodyTMX;
	boost::regex r("^(2[0-9][0-9][0-9])-([0-1][0-9])-([0-3][0-9])T([0-2][0-9]):([0-5][0-9])");
	boost::smatch m;

	PLOG(logDEBUG) << "Send PMM (for Cloud request), Status: " << status;

	//parse json
	//bodyTMX.clear();
	{
		lock_guard<mutex> lock(_setContentsLock);
		bodyTMX.set_contents(requestMessage);
	}

	ss.clear();
	ss.str(string());
	ss << "<PersonalMobilityMessage>";
	ss << "<groupId>" << groupId << "</groupId>";
	ss << "<requestId>" << requestId << "</requestId>";
	ss << "<status>" << status << "</status>";
	ss << "<position>" <<
			"<lat>" << (long)(bodyTMX.get<double>("PickupLatitude", 0) * 10000000.0) << "</lat>" <<
			"<long>" << (long)(bodyTMX.get<double>("PickupLongitude", 0) * 10000000.0) << "</long>" <<
			"</position>";

/*  adding accuracy throws an exception

	if (requestMessage.get_j2735_data()->accuracy != NULL)
	{
		accuracy = string((const char*)requestMessage.get_j2735_data()->accuracy->buf,
				requestMessage.get_j2735_data()->accuracy->size);
		ss << "<accuracy>" << accuracy << "</accuracy>";
	}
	else
	{
		ss << "<accuracy></accuracy>";
	}
*/

	if (boost::regex_search(bodyTMX.get<string>("RequestDate", ""), m, r))
	{
		ss << "<requestDate>" <<
				"<year>" << m[1] << "</year>" <<
				"<month>" << m[2] << "</month>" <<
				"<day>" << m[3] << "</day>" <<
				"<hour>" << m[4] << "</hour>" <<
				"<minute>" << m[5] << "</minute>" <<
				"</requestDate>";
	}
	else
	{
		ss << "<requestDate></requestDate>";
	}

	if (boost::regex_search(bodyTMX.get<string>("PickupDate", ""), m, r))
	{
		ss << "<pickupDate>" <<
				"<year>" << m[1] << "</year>" <<
				"<month>" << m[2] << "</month>" <<
				"<day>" << m[3] << "</day>" <<
				"<hour>" << m[4] << "</hour>" <<
				"<minute>" << m[5] << "</minute>" <<
				"</pickupDate>";
	}
	else
	{
		ss << "<pickupDate></pickupDate>";
	}

	ss << "<destination>" <<
			"<lon>" << (long)(bodyTMX.get<double>("DestLongitude", 0) * 10000000.0) << "</lon>" <<
			"<lat>" << (long)(bodyTMX.get<double>("DestLatitude", 0) * 10000000.0) << "</lat>" <<
			"</destination>";

	ss << "<mobilityNeeds>";
	if (bodyTMX.get<uint32_t>("RegularSeats", 0) > 0)
	{
		ss << "<MobilityNeeds>" <<
				"<type>" << MobilityNeedsType::MobilityNeedsType_noSpecialNeeds << "</type>" <<
				"<count>" << bodyTMX.get<uint32_t>("RegularSeats", 0) << "</count>" <<
				"</MobilityNeeds>";
	}
	if (bodyTMX.get<uint32_t>("HadicappedSeats", 0) > 0)
	{
		ss << "<MobilityNeeds>" <<
				"<type>" << MobilityNeedsType::MobilityNeedsType_wheelchair << "</type>" <<
				"<count>" << bodyTMX.get<uint32_t>("HadicappedSeats", 0) << "</count>" <<
				"</MobilityNeeds>";
	}
	ss << "</mobilityNeeds>";

	ss << "<modeOfTransport>" << bodyTMX.get<uint32_t>("ModeOfTransport", 0) << "</modeOfTransport>";

	// no eta field to copy, pass it in?
	//default to 0
	ss << "<eta>0</eta>";

	// no isDSRC field to copy
	//default to false
	ss << "<isDSRCEquipped><false/></isDSRCEquipped>";

	//use this vehicles description
	//dont allow empty string (causes exception)
	if (vehicleDescription.length() == 0)
	{
		ss << "<vehicleDesc>Vehicle</vehicleDesc>";
	}
	else
	{
		ss << "<vehicleDesc>" << vehicleDescription << "</vehicleDesc>";
	}

	ss << "<regional></regional>";

	ss << "</PersonalMobilityMessage>";

	PLOG(logDEBUG) << "PMM XML: " << ss.str();

	try
	{
		{
			lock_guard<mutex> lock(_setContentsLock);
			xmlDoc.load<XML>(ss);
			pmmMsg.set_contents(xmlDoc);
		}
		encMsg.initialize(pmmMsg);
		BroadcastMessage(static_cast<routeable_message &>(encMsg));
		PLOG(logDEBUG) << "SendPmmMessage sending DSRC Pmm Message to TMX Core (for Cloud request), sent on: " << GetMsTimeSinceEpoch() << " - PMM fields: " << pmmMsg.to_string();
	}
	catch (exception &ex)
	{
		PLOG(logERROR) << "Exception thrown in VeaRideRequestPlugin::SendPmmMessage: " << ex.what();
	}
}

void VeaRideRequestPlugin::CloudThread()
{
	bool isApiUrlValid;
	uint64_t lastSendTime = 0;
	bool MessageNotShown = true;
	utility::string_t address;
	http::uri uri;
	uint64_t time;
	http_response response;
	string body;
	status_code responseCode;
	size_t pos, nextPos;
	string responseArray;
	ostringstream oss;
	CURL *curlHandle;
	CURLcode curlRC = CURLE_OK;
	string curlResponse;
	string curlURL = "";
	string postData;
	struct curl_slist *headerList = NULL;
	string bodyLength;
	bool processPMMRequest;
	string mobileDevicesApiUrl;
	bool pickupFound;

	string groupIdent;
	uint32_t requestId;
	uint32_t status;
	uint32_t isDSRCEquipped = 1;
	uint32_t eta = 30;
	uint32_t regularSeats;
	uint32_t handicappedSeats;

	curl_global_init(CURL_GLOBAL_SSL);

	while (_plugin->state != IvpPluginState_error && !_stopThreads)
	{
		time = GetMsTimeSinceEpoch();
		if (_newConfigValues && _cloudFrequency > 0 && (time - lastSendTime) > _cloudFrequency)
		{
			//get cloud requests
			{
				//copy URL
				lock_guard<mutex> lock(_apiUrlLock);
				mobileDevicesApiUrl = _mobileDevicesApiUrl;
			}
			isApiUrlValid = !mobileDevicesApiUrl.empty();
			if (isApiUrlValid)
			{
				MessageNotShown = true;
				body = "";
				responseCode = 0;
				try
				{
					address = U(mobileDevicesApiUrl);
					uri = http::uri(address);
					http_client rideRequester(http::uri_builder(uri).append_path(U("/api/PmmRequest")).to_uri());
					lastSendTime = time;
					response = rideRequester.request(methods::GET).get();
					//PLOG(logDEBUG) << "HTTP Response: " << response.to_string();
					responseCode = response.status_code();
					body = response.extract_string().get();
					//PLOG(logDEBUG) << "HTTP Response - Code: " << responseCode << ", Body: " << body;
				}
				catch (exception &ex)
				{
					PLOG(logDEBUG) << "Exception getting cloud requests: " << ex.what();
				}
				if (responseCode < 200 || responseCode >= 300)
				{
					PLOG(logDEBUG) << "HTTP Error, Response Code: " << responseCode;
				}
				//parse arrays out and process
				if (responseCode >= 200 && responseCode < 300 && body.length() > 2)
				{
					body = body.substr(1, body.length() - 2);
					pos = body.find("{\"Id\":", 0);
					while (pos != string::npos)
					{
						nextPos = body.find("{\"Id\":", pos + 1);
						if (nextPos == string::npos)
						{
							//last array
							responseArray = body.substr(pos, body.length() - pos);
						}
						else
						{
							//not last array
							responseArray = body.substr(pos, nextPos - pos - 1);
						}
						PLOG(logDEBUG) << "responseArray: " << responseArray;
						//parse json
						tmx::message bodyTMX;
						//bodyTMX.clear();
						{
							lock_guard<mutex> lock(_setContentsLock);
							bodyTMX.set_contents(responseArray);
						}

						PLOG(logDEBUG) << "CloudThread receiving PmmRequest from the Cloud API, received on: " << GetMsTimeSinceEpoch() << " - PMM fields: " << bodyTMX.to_string();
						groupIdent = bodyTMX.get<string>("GroupIdent", "");
						//PLOG(logDEBUG) << "GroupIdent: " << groupIdent;

						requestId = bodyTMX.get<uint32_t>("RequestId", 0);
						status = bodyTMX.get<uint32_t>("Status", 0);
						regularSeats = bodyTMX.get<uint32_t>("RegularSeats", 0);
						handicappedSeats = bodyTMX.get<uint32_t>("HandicappedSeats", 0);

						processPMMRequest = true;

						{  // lock accepted pickups map in this block
							lock_guard<mutex> lock(_acceptedPickupsLock);

							//check is we have a saved request
							//if we do then process new request only if requestId > saved requestId
							pickupFound = false;
							if (_acceptedPickups.find(groupIdent) != _acceptedPickups.end())
							{
								pickupFound = true;
								if (_acceptedPickups[groupIdent].requestId >= requestId)
								{
									processPMMRequest = false;
								}
							}

							//process request into accepted pickups map, dont send response just yet
							if (processPMMRequest)
							{
								//process pmm
								if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_new)
								{
									if (regularSeats + handicappedSeats > 0)
									{
										PLOG(logDEBUG) << "Add (Cloud), groupId: " << groupIdent << "  requestId: " << requestId;
										//new
										AcceptedPickupsStruct acceptedPickup;
										acceptedPickup.groupId = groupIdent;
										acceptedPickup.requestId = requestId;
										acceptedPickup.status = status;
										acceptedPickup.pmmMsgCloud = responseArray;
										_acceptedPickups[groupIdent] = acceptedPickup;
										if (!pickupFound)
										{
											//add groupId to end of order vector
											_acceptedPickupsOrder.push_back(groupIdent);
										}
									}
									else
									{
										//cancel because requested seat count = 0
										if (pickupFound)
										{
											PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request cancelled";
											_acceptedPickups.erase(groupIdent);
										}
										else
										{
											PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request not found!";
										}
									}
								}
								else if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
								{
									if (regularSeats + handicappedSeats > 0)
									{
										PLOG(logDEBUG) << "Update (Cloud), groupId: " << groupIdent << "  requestId: " << requestId;
										//update
										AcceptedPickupsStruct acceptedPickup;
										acceptedPickup.groupId = groupIdent;
										acceptedPickup.requestId = requestId;
										acceptedPickup.status = status;
										acceptedPickup.pmmMsgCloud = responseArray;
										_acceptedPickups[groupIdent] = acceptedPickup;
										if (!pickupFound)
										{
											//add groupId to end of order vector
											_acceptedPickupsOrder.push_back(groupIdent);
										}
									}
									else
									{
										//cancel because requested seat count = 0
										if (pickupFound)
										{
											PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request cancelled";
											_acceptedPickups.erase(groupIdent);
										}
										else
										{
											PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request not found!";
										}
									}
								}
								else if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_cancel)
								{
									//cancel
									if (pickupFound)
									{
										PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request cancelled";
										_acceptedPickups.erase(groupIdent);
									}
									else
									{
										PLOG(logDEBUG) << "Cancel (Cloud), groupId: " << groupIdent << "  requestId: " << requestId << " *** Request not found!";
									}
								}
								else if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_completed)
								{
									//completed
								}
								else if (status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
								{
									//arrival
								}
							}
						}

						//build response
						oss.clear();
						oss.str(string());
						oss << "{\"GroupId\":\"" << groupIdent << "\",";
						oss << "\"RequestId\":" << requestId << ",";
						oss << "\"Latitude\":" << setprecision(8) << bodyTMX.get<double>("Latitude", 0.0) << ",";
						oss << "\"Longitude\":" << setprecision(8) << bodyTMX.get<double>("Longitude", 0.0) << ",";
						oss << "\"Elevation\":" << setprecision(8) << bodyTMX.get<double>("Elevation", 0.0) << ",";
						oss << "\"PosAccuracy\":" << setprecision(8) << bodyTMX.get<double>("PosAccuracy", 0.0) << ",";
						oss << "\"IsDSRCEquipped\":" << isDSRCEquipped << ",";
						oss << "\"ETA\":" << eta << ",";
						oss << "\"TotalRegSeatsAccepted\":" << regularSeats << ",";
						oss << "\"TotalMobilityNeedsSeatsAccepted\":" << handicappedSeats << "}";

						postData = oss.str();

						//PLOG(logDEBUG) << "Response: " << postData;
						PLOG(logDEBUG) << "Send PMM (Cloud) response";

						//always send response

						curlHandle = curl_easy_init();
						if (curlHandle)
						{
							curlResponse = "";
							//build URL
							curlURL = mobileDevicesApiUrl;
							curlURL.append("/api/PmmResponse");
							curl_easy_setopt(curlHandle, CURLOPT_URL, curlURL.c_str());
							curl_easy_setopt(curlHandle, CURLOPT_WRITEFUNCTION, HandleResponseOutput);
							curl_easy_setopt(curlHandle, CURLOPT_WRITEDATA, &curlResponse);
							curl_easy_setopt(curlHandle, CURLOPT_POSTFIELDS, postData.c_str());
							curl_easy_setopt(curlHandle, CURLOPT_POSTFIELDSIZE, postData.length());
							//modify header
							headerList = NULL;
							//headerList = curl_slist_append(headerList, "Host: mobiledeviceswebapidev.azurewebsites.net");
							headerList = curl_slist_append(headerList, "Content-Type: application/json");
							//oss.clear();
							//oss.str(string());
							//oss << "Content-Length: " << postData.length();
							//bodyLength = oss.str();
							//headerList = curl_slist_append(headerList, bodyLength.c_str());
							curl_easy_setopt(curlHandle, CURLOPT_HTTPHEADER, headerList);

							//send response
							curlRC = curl_easy_perform(curlHandle);
							curl_slist_free_all(headerList);
							if (curlRC == CURLE_OK)
							{
								//PLOG(logDEBUG) << "Curl response: " << curlResponse;
							}
							else
							{
								PLOG(logDEBUG) << "Curl error: " << curlRC;
							}
							PLOG(logDEBUG) << "CloudThread sending PmmResponse to the Cloud API, sent on: " << GetMsTimeSinceEpoch() << " - PMM fields: " << postData;
							curl_easy_cleanup(curlHandle);
						}
						else
						{
							PLOG(logDEBUG) << "curl_easy_init failed";
						}

						pos = nextPos;
					}

				}
			}
			else
			{
				if (MessageNotShown)
				{
					MessageNotShown = false;
					PLOG(logWARNING)
							<< "Invalid Mobile Devices WebApi URL configuration.  Mobile_Devices_Api_Url is empty or incorrect.";
				}
			}
		}
		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}

	curl_global_cleanup();
}

size_t VeaRideRequestPlugin::HandleResponseOutput(void *buffer, size_t size, size_t nmemb, void *userp)
{
	string *response = (string*)userp;
	response->append((const char *)buffer, size * nmemb);
	return size * nmemb;
}

void VeaRideRequestPlugin::NextDestinationThread()
{
	uint64_t lastSendTime = 0;
	uint64_t currentTime;
	AcceptedPickupsStruct pickup;
	string groupId;
	PmmRequestMessage message;
	bool sendMessage;
	ostringstream oss;
	StatusTypes status;
	ModeOfTransportTypes modeOfTransport;
	PmmRequestMessage::SeatsByType seats;
	PersonalMobilityMessage *pmm;
	boost::smatch m;
	string pmmMsgCloudCopy;

	while (_plugin->state != IvpPluginState_error && !_stopThreads)
	{
		currentTime = GetMsTimeSinceEpoch();
		if (_newConfigValues && _nextDestinationFrequency > 0 && (currentTime - lastSendTime) > _nextDestinationFrequency)
		{
			sendMessage = false;
			//check queue
			{
				lock_guard<mutex> lock(_acceptedPickupsLock);
				while (!_acceptedPickupsOrder.empty() && !sendMessage)
				{
					groupId = _acceptedPickupsOrder.front();
					if (_cancelAllRequests)
					{
						//config parameter indicates we should cancel all requests
						_acceptedPickupsOrder.erase(_acceptedPickupsOrder.begin());
						if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
						{
							_acceptedPickups.erase(groupId);
						}
					}
					else if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
					{
						//found destination
						pickup = _acceptedPickups[groupId];
						pmmMsgCloudCopy = pickup.pmmMsgCloud;
						sendMessage = true;
					}
					else
					{
						//cant find destination, remove from order list
						_acceptedPickupsOrder.erase(_acceptedPickupsOrder.begin());
					}
				}
			}
			if (sendMessage)
			{
				try
				{

					//build message
					if (pmmMsgCloudCopy.empty())
					{
						//use DSRC message
						pmm = pickup.pmmMsgDSRC.get_j2735_data();
						if (pmm == NULL)
						{
							PLOG(logERROR) << "Send Next Destination TMXPmm (for DSRC request) failed, jget_2735_data is NULL";
						}
						else
						{
							message.set_Id(NewGuid());
							message.set_GroupId(groupId);
							message.set_RequestId(pickup.requestId);
							//use ISO 8601 YYYY-MM-DD
							if (pmm->requestDate != NULL)
							{
								oss.clear();
								oss.str(string());
								oss << pmm->requestDate->year << "-";
								oss << left << setfill('0') << setw(2) << pmm->requestDate->month << "-";
								oss << left << setfill('0') << setw(2) << pmm->requestDate->day << "T";
								oss << left << setfill('0') << setw(2) << pmm->requestDate->hour << ":";
								oss << left << setfill('0') << setw(2) << pmm->requestDate->minute;
								message.set_RequestDate(oss.str());
							}
							if (pmm->pickupDate != NULL)
							{
								oss.clear();
								oss.str(string());
								oss << pmm->pickupDate->year << "-";
								oss << left << setfill('0') << setw(2) << pmm->pickupDate->month << "-";
								oss << left << setfill('0') << setw(2) << pmm->pickupDate->day << "T";
								oss << left << setfill('0') << setw(2) << pmm->pickupDate->hour << ":";
								oss << left << setfill('0') << setw(2) << pmm->pickupDate->minute;
								message.set_PickupDate(oss.str());
							}
							status = New;
							if (pickup.status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_update)
								status = Updated;
							else if (pickup.status == PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival)
								status = Arrive;
							message.set_Status(status);
							modeOfTransport = noPreference;
							if (pmm->modeOfTransport != NULL)
							{
								if (*(pmm->modeOfTransport) == ModeOfTransportType::ModeOfTransportType_rideShare)
									modeOfTransport = rideShare;
								else if (*(pmm->modeOfTransport) == ModeOfTransportType::ModeOfTransportType_taxi)
									modeOfTransport = taxi;
								else if (*(pmm->modeOfTransport) == ModeOfTransportType::ModeOfTransportType_transit)
									modeOfTransport = transit;
							}
							message.set_ModeOfTransport(modeOfTransport);
							message.set_PickupLatitude(pmm->position.lat);
							message.set_PickupLongitude(pmm->position.Long);
							//set elevation to 0 since not found in DSRC message
							message.set_PickupElevation(0);
							if (pmm->destination != NULL)
							{
								message.set_DestLatitude(pmm->destination->lat);
								message.set_DestLongitude(pmm->destination->lon);
							}
							//set elevation to 0 since not found in DSRC message
							message.set_DestElevation(0);
							//set seat counts
							message.erase_SeatsByTypes();
							seats.Type = 0;
							seats.Count = GetRegularSeatCount(pickup.pmmMsgDSRC);
							message.add_to_SeatsByTypes(seats);
							seats.Type = 1;
							seats.Count = GetHandicappedSeatCount(pickup.pmmMsgDSRC);
							message.add_to_SeatsByTypes(seats);
							PLOG(logDEBUG) << "Send Next Destination TMXPmm (for DSRC request)";
						}
					}
					else
					{
						//use Cloud message
						//parse json
						//PLOG(logDEBUG) << "NextDestinationThread use cloud before set_contents";
						//tmx::message bodyTMX;
						//{
						//	lock_guard<mutex> lock(_setContentsLock);
						//	bodyTMX.set_contents(pickup.pmmMsgCloud);
						//}
						//PLOG(logDEBUG) << "NextDestinationThread use cloud after set_contents";
						//set fields
						message.set_Id(NewGuid());
						message.set_GroupId(groupId);
						message.set_RequestId(pickup.requestId);
						//message.set_GroupId(bodyTMX.get<string>("GroupIdent", ""));
						//if (boost::regex_search(pickup.pmmMsgCloud, m, boost::regex("\"GroupIdent\":\"([^\"]+)\"")))
							//message.set_GroupId(m[1]);
						//message.set_RequestId((int)bodyTMX.get<uint32_t>("RequestId", 0));
						//if (boost::regex_search(pickup.pmmMsgCloud, m, boost::regex("\"RequestId\":([^,}]+),|\\}")))
							//message.set_RequestId(stoi(m[1]));
						//message.set_RequestDate(bodyTMX.get<string>("RequestDate", ""));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"RequestDate\":\"([^\"]+)\"")))
							message.set_RequestDate(m[1]);
						//message.set_PickupDate(bodyTMX.get<string>("PickupDate", ""));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupDate\":\"([^\"]+)\"")))
							message.set_PickupDate(m[1]);
						status = New;
						if (pickup.status == Updated)
							status = Updated;
						else if (pickup.status == Arrive)
							status = Arrive;
						message.set_Status(status);
						PLOG(logDEBUG) << "NextDestinationThread use cloud after set_Status";
						modeOfTransport = noPreference;
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"ModeofTransport\":([^,}]+),|\\}")))
						{
							if (stoi(m[1]) == rideShare)
								modeOfTransport = rideShare;
							else if (stoi(m[1]) == taxi)
								modeOfTransport = taxi;
							else if (stoi(m[1]) == transit)
								modeOfTransport = transit;
						}
						//f (bodyTMX.get<uint32_t>("ModeofTransport", 0) == rideShare)
						//	modeOfTransport = rideShare;
						//else if (bodyTMX.get<uint32_t>("ModeofTransport", 0) == taxi)
						//	modeOfTransport = taxi;
						//else if (bodyTMX.get<uint32_t>("ModeofTransport", 0) == transit)
						//	modeOfTransport = transit;
						message.set_ModeOfTransport(modeOfTransport);
						//message.set_PickupLatitude(bodyTMX.get<double>("PickupLatitude", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLatitude\":([^,]+),")))
							message.set_PickupLatitude(stod(m[1]));
						//message.set_PickupLongitude(bodyTMX.get<double>("PickupLongitude", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLongitude\":([^,}]+),|\\}")))
							message.set_PickupLongitude(stod(m[1]));
						//message.set_PickupElevation(bodyTMX.get<double>("Elevation", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"Elevation\":([^,}]+),|\\}")))
							message.set_PickupElevation(stod(m[1]));
						//message.set_DestLatitude(bodyTMX.get<double>("DestLatitude", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLatitude\":([^,}]+),|\\}")))
							message.set_DestLatitude(stod(m[1]));
						//message.set_DestLongitude(bodyTMX.get<double>("DestLongitude", 0));
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLongitude\":([^}]+)\\}")))
							message.set_DestLongitude(stod(m[1]));
						//currently dont get DestElevation
						//message.set_DestElevation(bodyTMX.get<double>("DestElevation", 0));
						message.set_DestElevation(0.0);
						//set seat counts
						PLOG(logDEBUG) << "NextDestinationThread use cloud before set seat counts";
						message.erase_SeatsByTypes();
						seats.Type = 0;
						//seats.Count = bodyTMX.get<uint32_t>("RegularSeats", 0);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"RegularSeats\":([^,}]+),|\\}")))
							seats.Count = stoi(m[1]);
						message.add_to_SeatsByTypes(seats);
						seats.Type = 1;
						//seats.Count = bodyTMX.get<uint32_t>("HandicappedSeats", 0);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"HandicappedSeats\":([^,}]+)")))
							seats.Count = stoi(m[1]);
						message.add_to_SeatsByTypes(seats);
						PLOG(logDEBUG) << "Send Next Destination TMXPmm (for Cloud request)";
					}
					PLOG(logDEBUG) << "TMXPmm contents: " << message.to_string();
					//send message
					lastSendTime = currentTime;
					BroadcastMessage(message);
					PLOG(logDEBUG) << "Next Destination Thread sending TMX Pmm Message to TMX Core, sent on: " << currentTime;
				}
				catch (exception &ex)
				{
					PLOG(logERROR) << "Exception thrown in VeaRideRequestPlugin::NextDestinationThread: " << ex.what();
				}
			}
		}
		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}
}

void VeaRideRequestPlugin::ArrivedThread()
{
	uint64_t lastSendTime = 0;
	uint64_t currentTime;
	LocationMessage location;
	AcceptedPickupsStruct pickup;
	string groupId;
	bool haveDestination;
	LocationMessage locationCopy;
	uint64_t locationMsgTime;
	WGS84Point destinationLoc;
	WGS84Point pickupLoc;
	WGS84Point vehicleLoc;
	double distanceToDestination;
	double distanceToPickup;
	double vehicleSpeed;
	PersonalMobilityMessage *pmm;
	boost::smatch m;
	string pmmMsgCloudCopy;

	while (_plugin->state != IvpPluginState_error && !_stopThreads)
	{
		currentTime = GetMsTimeSinceEpoch();
		//get location message
		{
			lock_guard<mutex> lock(_locationLock);
			locationMsgTime = _locationMsgTime;
			locationCopy = _locationMsg;
		}
		if (_newConfigValues && _arrivedFrequency > 0 && (currentTime - lastSendTime) > _arrivedFrequency &&
				currentTime - locationMsgTime < _locationMsgExpireMs)
		{
			haveDestination = false;
			//check queue
			{
				lock_guard<mutex> lock(_acceptedPickupsLock);
				while (!_acceptedPickupsOrder.empty() && !haveDestination)
				{
					groupId = _acceptedPickupsOrder.front();
					if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
					{
						//have next destination
						pickup = _acceptedPickups[groupId];
						pmmMsgCloudCopy = pickup.pmmMsgCloud;
						haveDestination = true;
					}
					else
					{
						//cant find destination, remove from order list
						_acceptedPickupsOrder.erase(_acceptedPickupsOrder.begin());
					}
				}
			}

			//if have pickup or destination compare location with PMM location
			if (haveDestination)
			{
				vehicleLoc.Latitude = locationCopy.get_Latitude();
				vehicleLoc.Longitude = locationCopy.get_Longitude();
				vehicleSpeed = locationCopy.get_Speed();
				if (pmmMsgCloudCopy.empty())
				{
					//use saved DSRC
					pmm = pickup.pmmMsgDSRC.get_j2735_data();
					if (pmm == NULL)
					{
						PLOG(logERROR) << "Send Arrived PMM (for DSRC request) failed, jget_2735_data is NULL";
					}
					else
					{
						destinationLoc.Latitude = pmm->destination->lat / 10000000.0;
						destinationLoc.Longitude = pmm->destination->lon / 10000000.0;
						distanceToDestination = GeoVector::DistanceInMeters(vehicleLoc, destinationLoc);
						//check if at destination first
						if (distanceToDestination <= _arrivedRadius && vehicleSpeed == 0.0)
						{
							//we have arrived at destination, remove request
							lock_guard<mutex> lock(_acceptedPickupsLock);
							if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
							{
								_acceptedPickups.erase(groupId);
							}
						}
						else
						{
							//check if at pickup
							pickupLoc.Latitude = pmm->position.lat / 10000000.0;
							pickupLoc.Longitude = pmm->position.Long / 10000000.0;
							distanceToPickup = GeoVector::DistanceInMeters(vehicleLoc, pickupLoc);
							//we have arrived at pickup, send message
							if (distanceToPickup <= _arrivedRadius)
							{
								lastSendTime = currentTime;
								SendPmmMessage(groupId, pickup.requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival,
										_vehicleDescription, pickup.pmmMsgDSRC);
							}
						}
					}
				}
				else
				{
					//use saved Cloud
					//parse json
					//tmx::message bodyTMX;
					//bodyTMX.clear();
					//{
					//	lock_guard<mutex> lock(_setContentsLock);
					//	bodyTMX.set_contents(pickup.pmmMsgCloud);
					//}

					//destinationLoc.Latitude = bodyTMX.get<double>("DestLatitude", 0);
					//destinationLoc.Longitude = bodyTMX.get<double>("DestLongitude", 0);
					if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLatitude\":([^,}]+),|\\}")))
						destinationLoc.Latitude = stod(m[1]);
					if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"DestLongitude\":([^}]+)\\}")))
						destinationLoc.Longitude = stod(m[1]);
					distanceToDestination = GeoVector::DistanceInMeters(vehicleLoc, destinationLoc);
					//check if at destination first
					if (distanceToDestination <= _arrivedRadius)
					{
						//we have arrived at destination, remove request
						lock_guard<mutex> lock(_acceptedPickupsLock);
						if (_acceptedPickups.find(groupId) != _acceptedPickups.end())
						{
							_acceptedPickups.erase(groupId);
						}
					}
					else
					{
						//check if at pickup
						//pickupLoc.Latitude = bodyTMX.get<double>("PickupLatitude", 0);
						//pickupLoc.Longitude = bodyTMX.get<double>("PickupLongitude", 0);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLatitude\":([^,}]+),|\\}")))
							pickupLoc.Latitude = stod(m[1]);
						if (boost::regex_search(pmmMsgCloudCopy, m, boost::regex("\"PickupLongitude\":([^}]+)\\}")))
							pickupLoc.Longitude = stod(m[1]);
						distanceToPickup = GeoVector::DistanceInMeters(vehicleLoc, pickupLoc);
						//we have arrived at pickup, send message
						if (distanceToPickup <= _arrivedRadius)
						{
							lastSendTime = currentTime;
							SendPmmMessage(groupId, pickup.requestId, PersonalMobilityMessageStatusType::PersonalMobilityMessageStatusType_arrival,
									_vehicleDescription, pmmMsgCloudCopy);
						}
					}
				}
			}
		}

		this_thread::sleep_for(chrono::milliseconds(THREADSLEEPTIMEMS));
	}
}

} /* namespace VeaRideRequestPlugin */

int main(int argc, char *argv[])
{
	return run_plugin<VeaRideRequestPlugin::VeaRideRequestPlugin>("VeaRideRequestPlugin", argc, argv);
}
