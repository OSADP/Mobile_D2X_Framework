//============================================================================
// Name        : VeaPedestrianMonPlugin.cpp
// Author      : Battelle Memorial Institute - Ben Paselsky (paselsky@battelle.org)
// Version     :
// Copyright   : Copyright (c) 2014 Battelle Memorial Institute. All rights reserved.
// Description : Plugin that listens for PSMs from pedestrians on the road and notifies
//               the driver if the pedestrian has a threat to their safety from the
//               driver’s vehicle
//============================================================================

#include <iostream>
#include <mutex>
#include <queue>
#include <math.h>

#include <PluginClient.h>
#include <LocationMessage.h>
#include <MapSupport.h>
#include <ApplicationMessage.h>
#include <tmx/j2735_messages/PersonalSafetyMessage.hpp>
#include <GeoVector.h>
#include <GeoDisplay.h>

using namespace std;
using namespace tmx;
using namespace tmx::utils;
using namespace tmx::messages;
using namespace boost;

namespace VeaPedestrianMonPlugin
{

#define STATUS_DISTANCE "Distance"
#define STATUS_PEDESTRIANLAT "Pedestrian Lat."
#define STATUS_PEDESTRIANLONG "Pedestrian Long."
#define STATUS_VEHICLELAT "Vehicle Lat."
#define STATUS_VEHICLELONG "Vehicle Long."

/*
 * Structure for holding PSM messages and the time they were received, used for FIFO queue
 */
struct PsmMsgQueueStruct
{
	uint64_t psmMsgTime;
	PsmMessage psmMsg;
};

/**
 * This plugin listens for PSMs from pedestrians on the road and notifies
 * the driver if the pedestrian has a threat to their safety from the
 * driver’s vehicle
 */
class VeaPedestrianMonPlugin: public PluginClient
{
public:
	VeaPedestrianMonPlugin(std::string);
	virtual ~VeaPedestrianMonPlugin();
	int Main();
protected:
	void UpdateConfigSettings();

	// Virtual method overrides.
	void OnConfigChanged(const char *key, const char *value);
	void OnStateChange(IvpPluginState state);

	void HandlePsmMessage(PsmMessage &msg, routeable_message &routeableMsg);
	void HandleLocationMessage(LocationMessage &msg, routeable_message &routeableMsg);

private:
	// locks
	mutex _psmLock;
	mutex _locationLock;
	//const char *_displayAddress = "10.63.46.89";  // the address display messages will be sent to
	const uint32_t _displayPort = 22001;

	// Config
	std::atomic<uint64_t> _psmMsgExpireMs; // = 5000
	std::atomic<uint64_t> _locationMsgExpireMs; // = 5000
	std::atomic<uint64_t> _sleepUs; // = 10000, sleep in microseconds
	std::atomic<uint64_t> _defaultClusterRadius; // = 10, in meters
	string  _geoDisplayAddress = "";
	mutex _geoDisplayAddressLock;

	std::queue<PsmMsgQueueStruct> _psmMsgQueue;
	std::atomic<bool> _gotPsmUpdateSinceRun; //= false

	LocationMessage _locationMsg;
	uint64_t _mostRecentLocationMsgTime; // = 0
	LocationMessage _previousLocationMsg;
	uint64_t _previousLocationMsgTime; // = 0

	std::atomic<bool> _gotConfigdata; //= false

	// track number of messages sent
	uint64_t _warningsIssued = 0;
	uint64_t _alertsIssued = 0;
	uint64_t _advisoriesIssued = 0;
	uint64_t _totalMessagesSent = 0;


	uint64_t GetMsTimeSinceEpoch();
	std::string GetMessageTime();
	void SendApplicationMessage(appmessage::EventCodeTypes eventCode, std::string customText);
	void EvaluatePedestrianSafety();
	void GenerateSafetyWarning();
	void GenerateSafetyAlert();
	void GenerateSafetyAdvisory();
	bool LocationsAreTheSame(WGS84Point location1, WGS84Point location2);

};

/**
 * Construct a new VeaPedestrianMonPlugin with the given name.
 *
 * @param name The name to give the plugin for identification purposes
 */
VeaPedestrianMonPlugin::VeaPedestrianMonPlugin(string name) : PluginClient(name), _psmMsgExpireMs(5000),
		_locationMsgExpireMs(5000),_sleepUs(10000), _defaultClusterRadius(10), _gotPsmUpdateSinceRun(false),
		_mostRecentLocationMsgTime(0), _previousLocationMsgTime(0), _gotConfigdata(false)
{

	// Add a message filter and handler for each message this plugin wants to receive.
	AddMessageFilter<LocationMessage>(this, &VeaPedestrianMonPlugin::HandleLocationMessage);
	AddMessageFilter<PsmMessage>(this, &VeaPedestrianMonPlugin::HandlePsmMessage);

	//Enable or disable GeoDisplay
	GeoDisplay::Disable();

	// Subscribe to all messages specified by the filters above.
	SubscribeToMessages();
}

VeaPedestrianMonPlugin::~VeaPedestrianMonPlugin()
{

}

void VeaPedestrianMonPlugin::UpdateConfigSettings()
{
	string geoDisplayAddress = "";
	PLOG(logDEBUG) << "Updating config data.";
	GetConfigValue<uint64_t>("PsmMsgExpiration", _psmMsgExpireMs);
	GetConfigValue<uint64_t>("LocationMsgExpiration", _locationMsgExpireMs);
	GetConfigValue<uint64_t>("Sleep", _sleepUs);
	GetConfigValue<uint64_t>("DefaultClusterRadius", _defaultClusterRadius);

	{
		lock_guard<mutex> lock(_geoDisplayAddressLock);
		GetConfigValue("GeoDisplayAddress", _geoDisplayAddress);
		if (!_geoDisplayAddress.empty())
		{
			GeoDisplay::Enable();
		}
		geoDisplayAddress = _geoDisplayAddress;
	}
	PLOG(logDEBUG) << "    Config data - P, L, S, D, G: " << _psmMsgExpireMs << ", " << _locationMsgExpireMs << ", " << _sleepUs << ", " << _defaultClusterRadius << ", " << geoDisplayAddress;
	_gotConfigdata = true;
}

void VeaPedestrianMonPlugin::OnConfigChanged(const char *key, const char *value)
{
	PluginClient::OnConfigChanged(key, value);
	UpdateConfigSettings();
}


void VeaPedestrianMonPlugin::OnStateChange(IvpPluginState state)
{
	PluginClient::OnStateChange(state);

	if (state == IvpPluginState_registered)
	{
		UpdateConfigSettings();
	}
}

int VeaPedestrianMonPlugin::Main()
{
	PLOG(logINFO) << "Starting plugin VeaPedestrianMonPlugin.";

	while (_plugin->state != IvpPluginState_error)
	{
		//evaluate data only if have something in the PSM queue
		if (_gotConfigdata && _gotPsmUpdateSinceRun)
		{
			EvaluatePedestrianSafety();
		}
		usleep(_sleepUs);
	}

	return EXIT_SUCCESS;
}

void VeaPedestrianMonPlugin::HandlePsmMessage(PsmMessage &msg, routeable_message &routeableMsg)
{
	PsmMsgQueueStruct psmQeueItem;

	// Must be in the registered state in order to know the parameter values
	if (_plugin->state != IvpPluginState_registered)
		return;

	if (msg.get_j2735_data()->position.lat == 0 && msg.get_j2735_data()->position.Long == 0)
		return;

	//Save to queue for later use.
	{
		lock_guard<mutex> lock(_psmLock);
		//Save the timestamp of this message.
		psmQeueItem.psmMsgTime = routeableMsg.get_timestamp();
		psmQeueItem.psmMsg = msg;
		_psmMsgQueue.push(psmQeueItem);
		//Set flag to allow Check for pedestrians to run.
		_gotPsmUpdateSinceRun = true;
	}
	PLOG(logDEBUG) << "HandlePsmMessage receiving DSRC PsmMessage from TMX Core, received on: " << GetMsTimeSinceEpoch() << " - PSM Fields: " << msg.to_string();
}


void VeaPedestrianMonPlugin::HandleLocationMessage(LocationMessage &msg, routeable_message &routeableMsg)
{
	WGS84Point oldLoc;
	WGS84Point newLoc;
	// Must be in the registered state in order to know the parameter values
	if (_plugin->state != IvpPluginState_registered)
		return;

	if (msg.get_Latitude() == 0 && msg.get_Longitude() == 0)
		return;

	//PLOG(logDEBUG) << "Got LocationMsg. Latitude:" << msg.get_Latitude() << " Longitude:" << msg.get_Longitude();

	//Save to member variable for later use.
	{
		lock_guard<mutex> lock(_locationLock);
		//save previous location only if it is different from the new one because we cant calculate
		//a bearing with two of the same point
		oldLoc = { _locationMsg.get_Latitude(),
				_locationMsg.get_Longitude() };
		newLoc = { msg.get_Latitude(),
				msg.get_Longitude() };
		WGS84Point vehicleLoc;
		if (!LocationsAreTheSame(oldLoc, newLoc))
		{
			_previousLocationMsgTime = _mostRecentLocationMsgTime;
			_previousLocationMsg = _locationMsg;
		}
		_mostRecentLocationMsgTime = routeableMsg.get_timestamp();
		_locationMsg = msg;
	}
}

uint64_t VeaPedestrianMonPlugin::GetMsTimeSinceEpoch()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return (uint64_t) ((double) (tv.tv_sec) * 1000
			+ (double) (tv.tv_usec) / 1000);
}

void VeaPedestrianMonPlugin::EvaluatePedestrianSafety()
{
	PsmMessage psmCopy;
	LocationMessage locationCopy;
	LocationMessage previousLocationCopy;
	WGS84Point pedestrianLoc;
	WGS84Point vehicleLoc;
	WGS84Point previousVehicleLoc;
	double pedestrianToVehicleDistanceInMeters;
	double pedestrianToVehicleDistanceInMetersUsingVector;
	double vehicleVelocity;
	double warningDistanceInMeters;
	double alertDistanceInMeters;
	double advisoryDistanceInMeters;
	double psmLatitude;
	double psmLongitude;
	double psmSpeedInMetersPerSecond;
	double psmHeadingInDegrees;
	double psmRadiusOfProtectionInMeters;
	uint64_t currentPsmMessageTime;
	uint64_t currentTime;
	uint64_t mostRecentLocationMsgTime, previousLocationMsgTime;
	double crossTrackDistance;
	double crossTrackDistanceUsingBearing;
	double pathToPedestrianAngle;
	double pathToPedestrianAngleUsingBearing;
	WGS84Point intersectionOfPaths;
	double distanceToIntersect;
	double timeOfIntersect;
	double pedestrianDistanceTraveled;
	WGS84Point pedestrianLocAtIntersect;
	double pedestrianDistanceToVehicleAtIntersect;
	bool pedestrianInPath;
	bool pedestrianInFrontOfVehicle;
	bool predictedPedestrianInPath;
	bool havePsmData;
	string outputString;
	ostringstream oss;

	{
		//check PSM queue
		lock_guard<mutex> lock(_psmLock);
		havePsmData = !_psmMsgQueue.empty();
	}
	while (havePsmData)
	{
		//get PSM message OFF QUEUE
		{
			lock_guard<mutex> lock(_psmLock);
			PLOG(logDEBUG) << "Have PSM data, queue length: " << _psmMsgQueue.size();
			currentPsmMessageTime = _psmMsgQueue.front().psmMsgTime;
			psmCopy = _psmMsgQueue.front().psmMsg;
			_psmMsgQueue.pop();
			_gotPsmUpdateSinceRun = false;
		}

		//get location message
		{
			lock_guard<mutex> lock(_locationLock);
			previousLocationMsgTime = _previousLocationMsgTime;
			mostRecentLocationMsgTime = _mostRecentLocationMsgTime;
			previousLocationCopy = _previousLocationMsg;
			locationCopy = _locationMsg;
		}

		currentTime = GetMsTimeSinceEpoch();

		//check for expired messages
		if ((currentTime - mostRecentLocationMsgTime < _locationMsgExpireMs) &&
				(currentTime - currentPsmMessageTime < _psmMsgExpireMs))
		{
			//convert PSM integer lat and long to double by dividing by 10 million
			psmLatitude = psmCopy.get_j2735_data()->position.lat / 10000000.0;
			psmLongitude = psmCopy.get_j2735_data()->position.Long / 10000000.0;
			psmSpeedInMetersPerSecond = psmCopy.get_j2735_data()->speed * .02;
			psmHeadingInDegrees = psmCopy.get_j2735_data()->heading * .0125;
			if (psmCopy.get_j2735_data()->clusterRadius == NULL)
			{
				psmRadiusOfProtectionInMeters = _defaultClusterRadius;
			}
			else
			{
				psmRadiusOfProtectionInMeters = *(psmCopy.get_j2735_data()->clusterRadius);
				if (psmRadiusOfProtectionInMeters == 0)
				{
					psmRadiusOfProtectionInMeters = _defaultClusterRadius;
				}
			}

			//get locations
			pedestrianLoc = { psmLatitude,
					psmLongitude};
			vehicleLoc = { locationCopy.get_Latitude(),
					locationCopy.get_Longitude() };
			if (currentTime - previousLocationMsgTime < _locationMsgExpireMs)
			{
				//calculate only if have valid previous location
				previousVehicleLoc = { previousLocationCopy.get_Latitude(),
						previousLocationCopy.get_Longitude() };
			}

			//get speed in meters per second using vehicle speed of kilometers per hour
			vehicleVelocity = locationCopy.get_Speed() * 1000.0 / 3600.0;

			//calculate cross track distance, this is the distance between vehicle path and the pedestrian
			//if distance is outside range dont issue messages
			if (currentTime - previousLocationMsgTime < _locationMsgExpireMs)
			{
				//calculate only if have valid previous location
				crossTrackDistance = GeoVector::CrossTrackDistanceInMeters(pedestrianLoc, previousVehicleLoc, vehicleLoc);
			}
			crossTrackDistanceUsingBearing = GeoVector::CrossTrackDistanceInMeters(pedestrianLoc, vehicleLoc, locationCopy.get_Heading());

			//check if path of vehicle is inside radius of protection
			if (crossTrackDistanceUsingBearing <= psmRadiusOfProtectionInMeters && crossTrackDistanceUsingBearing >= -psmRadiusOfProtectionInMeters)
				pedestrianInPath = true;
			else
				pedestrianInPath = false;

			//calculate angle between vehicle path and path from vehicle to pedestrian
			//if this angle is > 90 or < -90 vehicle is moving away from pedestrian
			if (currentTime - previousLocationMsgTime < _locationMsgExpireMs)
			{
				//calculate only if have valid previous location
				pathToPedestrianAngle = GeoVector::AngleBetweenPathsInDegrees(previousVehicleLoc, vehicleLoc, vehicleLoc, pedestrianLoc);
			}
			pathToPedestrianAngleUsingBearing = GeoVector::AngleBetweenPathsInDegrees(vehicleLoc, locationCopy.get_Heading(),
					vehicleLoc, pedestrianLoc);

			//check if pedestrian is in front of vehicle
			if (pathToPedestrianAngleUsingBearing <= 90.0 && pathToPedestrianAngleUsingBearing >= -90.0)
				pedestrianInFrontOfVehicle = true;
			else
				pedestrianInFrontOfVehicle = false;

			//calculate intersection of paths
			intersectionOfPaths = GeoVector::Intersection(vehicleLoc, locationCopy.get_Heading(), pedestrianLoc, psmHeadingInDegrees);

			//calculate distance pedestrian traveled when vehicle intersects pedestrians path
			distanceToIntersect = GeoVector::DistanceInMeters(vehicleLoc, intersectionOfPaths);
			timeOfIntersect = distanceToIntersect / vehicleVelocity; // in seconds
			pedestrianDistanceTraveled = psmSpeedInMetersPerSecond * timeOfIntersect;

			//for testing
			//PLOG(logDEBUG) << "DATA: " << setprecision(8) << distanceToIntersect << ", " << timeOfIntersect << ", " <<
			//		psmSpeedInMetersPerSecond << ", " << pedestrianDistanceTraveled << ", " << psmCopy.get_j2735_data()->speed;

			// calculate location of pedestrian when vehicle intersects pedestrians path
			pedestrianLocAtIntersect = GeoVector::DestinationPoint(pedestrianLoc, psmHeadingInDegrees, pedestrianDistanceTraveled);

			// calculate distance between pedestrian and vehicle when vehicle intersects pedestrians path
			pedestrianDistanceToVehicleAtIntersect = GeoVector::DistanceInMeters(pedestrianLocAtIntersect, intersectionOfPaths);

			//check if vehicle is in radius of protection when vehicle intersects pedestrian path
			if (pedestrianDistanceToVehicleAtIntersect <= psmRadiusOfProtectionInMeters && pedestrianDistanceToVehicleAtIntersect >= -psmRadiusOfProtectionInMeters)
				predictedPedestrianInPath = true;
			else
				predictedPedestrianInPath = false;

			if (currentTime - previousLocationMsgTime < _locationMsgExpireMs)
			{
				//when historical data is available
				PLOG(logDEBUG) << "Cross track distanceH/distanceB: " << setprecision(8) << crossTrackDistance << "/" << crossTrackDistanceUsingBearing <<
						" meters, AngleH/AngleB to pedestrian: " << pathToPedestrianAngle << "/" << pathToPedestrianAngleUsingBearing << " degrees";
			}
			else
			{
				//when historical data is NOT available
				PLOG(logDEBUG) << "Cross track distanceH/distanceB: NA/" << crossTrackDistanceUsingBearing <<
						" meters, AngleH/AngleB to pedestrian: NA/" << pathToPedestrianAngleUsingBearing << " degrees";
			}

			PLOG(logDEBUG) << "Path intersection. Latitude: " << setprecision(8) << intersectionOfPaths.Latitude <<
					"  Longitude: " << intersectionOfPaths.Longitude;

			PLOG(logDEBUG) << "Pedestrian location at time of intersection. Latitude: " << setprecision(8) <<
					pedestrianLocAtIntersect.Latitude << "  Longitude: " << pedestrianLocAtIntersect.Longitude;

			PLOG(logDEBUG) << "Pedestrian distance to vehicle at time of intersection: " << setprecision(8) <<
					pedestrianDistanceToVehicleAtIntersect << " meters" ;

			//calculate distance in meters using vectors
			pedestrianToVehicleDistanceInMetersUsingVector = GeoVector::DistanceInMeters(pedestrianLoc, vehicleLoc);

			//calculate distance in meters using conversion library
			pedestrianToVehicleDistanceInMeters = Conversions::DistanceMeters(pedestrianLoc, vehicleLoc);
			PLOG(logDEBUG) << "Pedestrian location. Latitude: " << setprecision(8) << psmLatitude << "  Longitude: " << psmLongitude;
			PLOG(logDEBUG) << "Vehicle location.  Latitude: " << setprecision(8) << locationCopy.get_Latitude() << "  Longitude: " << locationCopy.get_Longitude();
			PLOG(logDEBUG) << "Pedestrian to vehicle distanceC/distanceV: " << setprecision(8) << pedestrianToVehicleDistanceInMeters <<
					"/" << pedestrianToVehicleDistanceInMetersUsingVector << " meters";

			//display on PC
			GeoDisplay::SendDisplayClearScreen(_geoDisplayAddress.c_str(), _displayPort);
			GeoDisplay::SendDisplayLine(_geoDisplayAddress.c_str(), _displayPort, pedestrianLoc,
					GeoVector::DestinationPoint(pedestrianLoc, psmHeadingInDegrees, 2000.0), 4);
			GeoDisplay::SendDisplayLine(_geoDisplayAddress.c_str(), _displayPort, vehicleLoc,
					GeoVector::DestinationPoint(vehicleLoc, locationCopy.get_Heading(), 2000.0), 6);
			GeoDisplay::SendDisplayLine(_geoDisplayAddress.c_str(), _displayPort, vehicleLoc,
					GeoVector::DestinationPoint(vehicleLoc, GeoVector::BearingInDegrees(vehicleLoc, pedestrianLoc), 2000.0), 5);
			GeoDisplay::SendDisplayPoint(_geoDisplayAddress.c_str(), _displayPort, pedestrianLoc, 3, 4);
			GeoDisplay::SendDisplayCircle(_geoDisplayAddress.c_str(), _displayPort, pedestrianLoc, psmRadiusOfProtectionInMeters * 100, 4);
			GeoDisplay::SendDisplayPoint(_geoDisplayAddress.c_str(), _displayPort, vehicleLoc, 3, 6);
			GeoDisplay::SendDisplayPoint(_geoDisplayAddress.c_str(), _displayPort, intersectionOfPaths, 3, 3);
			GeoDisplay::SendDisplayPoint(_geoDisplayAddress.c_str(), _displayPort, pedestrianLocAtIntersect, 3, 9);
			GeoDisplay::SendDisplayCircle(_geoDisplayAddress.c_str(), _displayPort, pedestrianLocAtIntersect,
					psmRadiusOfProtectionInMeters * 100, 9);

			SetStatus(STATUS_PEDESTRIANLAT, psmLatitude);
			SetStatus(STATUS_PEDESTRIANLONG, psmLongitude);
			SetStatus(STATUS_VEHICLELAT, locationCopy.get_Latitude());
			SetStatus(STATUS_VEHICLELONG, locationCopy.get_Longitude());
			SetStatus(STATUS_DISTANCE, pedestrianToVehicleDistanceInMeters);

			PLOG(logDEBUG) << "Vehicle speed: " << setprecision(8) << locationCopy.get_Speed() << " km/hr, " <<
					(locationCopy.get_Speed() * .621371) << " miles/hr, " << vehicleVelocity << " meters/sec";
			oss << "VEHICLE VELOCITY: " << round((locationCopy.get_Speed() * .621371)) << " mph";

			GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 160, 1, 1, 110, oss.str().c_str());

			if (pedestrianInFrontOfVehicle)
				GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 60, 1, 1, 110, "IN FRONT");
			if (pedestrianInPath)
				GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 100, 1, 1, 110, "IN PATH");
			if (predictedPedestrianInPath)
				GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 120, 1, 1, 110, "IN PREDICTED PATH");


			//check for warning, calculation based on formulas in document FHWA-JPO-16-423, Appendix C
			warningDistanceInMeters = 1.1 * (((0.5 + 2.5) * vehicleVelocity) + ((vehicleVelocity * vehicleVelocity) / (2.0 * 5.6)));
			if (pedestrianToVehicleDistanceInMeters <= warningDistanceInMeters)
			{
				GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 80, 1, 1, 110, "IN WARNING DISTANCE");
				if (pedestrianInFrontOfVehicle && (pedestrianInPath || predictedPedestrianInPath))
				{
					PLOG(logDEBUG) << "Send WARNING, pedestrian distance " << pedestrianToVehicleDistanceInMeters << " is <= warning distance " << warningDistanceInMeters;
					GenerateSafetyWarning();
					_warningsIssued++;
					_totalMessagesSent++;
					GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 20, 3, 1, 116, "WARNING");
				}
			}
			else
			{
				//check for alert, calculation based on formulas in document FHWA-JPO-16-423, Appendix C
				alertDistanceInMeters = 1.1 * (((0.5 + 2.5) * vehicleVelocity) + ((vehicleVelocity * vehicleVelocity) / (2.0 * 3.4)));
				if (pedestrianToVehicleDistanceInMeters <= alertDistanceInMeters)
				{
					GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 80, 1, 1, 110, "IN ALERT DISTANCE");
					if (pedestrianInFrontOfVehicle && (pedestrianInPath || predictedPedestrianInPath))
					{
						PLOG(logDEBUG) << "Send ALERT, pedestrian distance " << pedestrianToVehicleDistanceInMeters << " is <= alert distance " << alertDistanceInMeters;
						GenerateSafetyAlert();
						_alertsIssued++;
						_totalMessagesSent++;
						GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 20, 8, 1, 116, "ALERT");
					}
				}
				else
				{
					//check for advisory, calculation based on formulas in document FHWA-JPO-16-423, Appendix C
					advisoryDistanceInMeters = vehicleVelocity * 9.0;
					if (pedestrianToVehicleDistanceInMeters <= advisoryDistanceInMeters)
					{
						GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 80, 1, 1, 110, "IN ADVISORY DISTANCE");
						if (pedestrianInFrontOfVehicle && (pedestrianInPath || predictedPedestrianInPath))
						{
							PLOG(logDEBUG) << "Send ADVISORY, pedestrian distance " << pedestrianToVehicleDistanceInMeters << " is <= advisory distance " << advisoryDistanceInMeters;
							GenerateSafetyAdvisory();
							_advisoriesIssued++;
							_totalMessagesSent++;
							GeoDisplay::SendDisplayString(_geoDisplayAddress.c_str(), _displayPort, 20, 20, 1, 1, 116, "ADVISORY");
						}
					}
				}
			}
			GeoDisplay::SendRender(_geoDisplayAddress.c_str(), _displayPort);
		}
		{
			//check PSM queue
			lock_guard<mutex> lock(_psmLock);
			havePsmData = !_psmMsgQueue.empty();
		}
	}
}

std::string VeaPedestrianMonPlugin::GetMessageTime()
{
	uint64_t time = GetMsTimeSinceEpoch();
	return std::to_string(time);
}

void VeaPedestrianMonPlugin::SendApplicationMessage(appmessage::EventCodeTypes eventCode, std::string customText)
{
	ApplicationMessage applicationMessage(NewGuid(),
			appmessage::ApplicationTypes::MD, "", GetMessageTime(), "",
			appmessage::Severity::Info, eventCode, "", customText);
	BroadcastMessage(applicationMessage);
	PLOG(logDEBUG) << "SendApplicationMessage sending Application Message to TMX Core, sent on: " << GetMsTimeSinceEpoch() << "Application Message Fields: " << applicationMessage.to_string();
}

void VeaPedestrianMonPlugin::GenerateSafetyWarning()
{
	SendApplicationMessage(appmessage::EventCodeTypes::MDWarning, "");
	_warningsIssued++;
	_totalMessagesSent++;
}

void VeaPedestrianMonPlugin::GenerateSafetyAlert()
{
	SendApplicationMessage(appmessage::EventCodeTypes::MDAlert, "");
	_alertsIssued++;
	_totalMessagesSent++;
}

void VeaPedestrianMonPlugin::GenerateSafetyAdvisory()
{
	SendApplicationMessage(appmessage::EventCodeTypes::MDAdvisory, "");
	_advisoriesIssued++;
	_totalMessagesSent++;
}

bool VeaPedestrianMonPlugin::LocationsAreTheSame(WGS84Point location1, WGS84Point location2)
{
	//test if points are the same
	if (location1.Latitude == location2.Latitude && location1.Longitude == location2.Longitude)
		return true;
	return false;
}


} /* namespace VeaPedestrianMonPlugin */


int main(int argc, char *argv[])
{
	return run_plugin<VeaPedestrianMonPlugin::VeaPedestrianMonPlugin>("VeaPedestrianMonPlugin", argc, argv);
}

